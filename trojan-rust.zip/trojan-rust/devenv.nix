{ pkgs, lib, ... }:

{
  # Matches the toolchain CI builds with (.github/workflows/ci.yml).
  # The MSRV job pins 1.90; everything else runs stable.
  languages.rust = {
    enable = true;
    channel = "stable";
    components = [
      "rustc"
      "cargo"
      "clippy"
      "rustfmt"
      "rust-src"
    ];
  };

  packages =
    with pkgs;
    [
      # aws-lc-sys (rustls' crypto backend) builds C sources via CMake, and
      # generates bindings with libclang on targets without prebuilt ones.
      cmake
      perl
      pkg-config
      # libsqlite3-sys, built by the sql-sqlite auth feature.
      sqlite
      # Reference implementation, for the interop tests in
      # trojan-server/tests/trojan_client_test.rs. Those tests look it up on
      # PATH and skip themselves when it is absent.
      trojan-go
    ]
    ++ lib.optionals stdenv.isDarwin [
      # aws-lc-sys reads `nm` while assembling its object list.
      darwin.cctools
    ];

  env.LIBCLANG_PATH = "${pkgs.libclang.lib}/lib";

  enterShell = ''
    # stderr, not stdout: `devenv shell -- cargo ... --message-format json`
    # otherwise emits this banner as the first "JSON" line.
    echo "trojan-rust dev shell — $(cargo --version)" >&2
  '';
}
