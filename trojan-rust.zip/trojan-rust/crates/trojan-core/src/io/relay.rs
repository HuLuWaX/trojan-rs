//! Bidirectional data relay with configurable metrics.
//!
//! This module provides a generic bidirectional relay that can be used by both
//! server and client implementations. Metrics recording is abstracted via the
//! `RelayMetrics` trait, allowing each implementation to provide its own
//! metrics backend.
//!
//! Each direction is driven as an independent poll-based state machine within
//! a single future, so back-pressure on one direction never stalls the other.
//! This prevents deadlocks in multi-hop relay chains.

use std::io;
use std::pin::Pin;
use std::task::{Context, Poll};
use std::time::Duration;

use tokio::io::{AsyncRead, AsyncWrite, AsyncWriteExt, ReadBuf};
use tokio::time::Instant as TokioInstant;

/// Trait for recording relay metrics.
///
/// The relay records bytes when a writer accepts them, before flush completes.
/// Cancellation and later I/O errors retain the accepted byte count.
/// The server implementation typically records to Prometheus,
/// while clients may use a no-op or custom implementation.
pub trait RelayMetrics {
    /// Record bytes received from inbound (client -> server direction).
    fn record_inbound(&self, bytes: u64);
    /// Record bytes sent to outbound (server -> target direction).
    fn record_outbound(&self, bytes: u64);
}

/// No-op metrics implementation for cases where metrics aren't needed.
#[derive(Debug, Clone, Copy, Default)]
pub struct NoOpMetrics;

impl RelayMetrics for NoOpMetrics {
    #[inline]
    fn record_inbound(&self, _bytes: u64) {}
    #[inline]
    fn record_outbound(&self, _bytes: u64) {}
}

/// State machine for one-directional copy with deferred flush.
///
/// Unlike a naive read→write→flush loop, this batches multiple read/write
/// cycles before flushing. A flush only happens when the reader returns
/// `Pending` (no more data immediately available) or on EOF. This mirrors
/// the strategy used by `tokio::io::copy` and avoids excessive flush
/// syscalls on buffered writers like TLS streams.
enum CopyState {
    Reading(usize),               // accumulated bytes since last flush
    Writing(usize, usize, usize), // (pos, len, accumulated)
    Flushing(usize, bool),        // (bytes awaiting flush, is_eof)
    ShuttingDown,
    Done,
}

/// Result of polling one copy direction.
enum CopyPoll {
    /// Data was flushed — contains the batch size for activity tracking.
    Flushed(usize),
    /// Direction finished (EOF + shutdown).
    Finished,
}

/// Poll-driven one-directional copy with deferred flush.
///
/// Reads and writes in a loop, only flushing when the reader has no more
/// data immediately available (`Pending`) or at EOF. This batches multiple
/// read/write cycles into a single flush, reducing syscall overhead on
/// buffered writers (e.g. TLS streams).
fn poll_copy_direction<R, W>(
    cx: &mut Context<'_>,
    reader: &mut R,
    writer: &mut W,
    buf: &mut [u8],
    state: &mut CopyState,
    mut record_write: impl FnMut(usize),
) -> Poll<io::Result<CopyPoll>>
where
    R: AsyncRead + Unpin + ?Sized,
    W: AsyncWrite + Unpin + ?Sized,
{
    loop {
        match state {
            CopyState::Reading(flushed) => {
                let mut read_buf = ReadBuf::new(buf);
                match Pin::new(&mut *reader).poll_read(cx, &mut read_buf) {
                    Poll::Ready(Ok(())) => {
                        let n = read_buf.filled().len();
                        if n == 0 {
                            // EOF — flush any accumulated bytes, then shut down.
                            if *flushed > 0 {
                                let total = *flushed;
                                *state = CopyState::Flushing(total, true);
                            } else {
                                *state = CopyState::ShuttingDown;
                            }
                        } else {
                            let acc = *flushed;
                            *state = CopyState::Writing(0, n, acc);
                        }
                    }
                    Poll::Ready(Err(e)) => return Poll::Ready(Err(e)),
                    Poll::Pending => {
                        // Reader has no more data — flush accumulated bytes.
                        if *flushed > 0 {
                            let total = *flushed;
                            *state = CopyState::Flushing(total, false);
                        } else {
                            return Poll::Pending;
                        }
                    }
                }
            }
            CopyState::Writing(pos, len, acc) => {
                match Pin::new(&mut *writer).poll_write(cx, &buf[*pos..*len]) {
                    Poll::Ready(Ok(0)) => {
                        return Poll::Ready(Err(io::ErrorKind::WriteZero.into()));
                    }
                    Poll::Ready(Ok(n)) => {
                        record_write(n);
                        *pos += n;
                        if *pos >= *len {
                            let total = *acc + *len;
                            // Don't flush yet — try to read more data first.
                            *state = CopyState::Reading(total);
                        }
                    }
                    Poll::Ready(Err(e)) => return Poll::Ready(Err(e)),
                    Poll::Pending => return Poll::Pending,
                }
            }
            CopyState::Flushing(bytes, is_eof) => {
                let bytes = *bytes;
                let eof = *is_eof;
                match Pin::new(&mut *writer).poll_flush(cx) {
                    Poll::Ready(Ok(())) => {
                        if eof {
                            *state = CopyState::ShuttingDown;
                        } else {
                            *state = CopyState::Reading(0);
                        }
                        return Poll::Ready(Ok(CopyPoll::Flushed(bytes)));
                    }
                    Poll::Ready(Err(e)) => return Poll::Ready(Err(e)),
                    Poll::Pending => return Poll::Pending,
                }
            }
            CopyState::ShuttingDown => match Pin::new(&mut *writer).poll_shutdown(cx) {
                Poll::Ready(_) => {
                    *state = CopyState::Done;
                    return Poll::Ready(Ok(CopyPoll::Finished));
                }
                Poll::Pending => return Poll::Pending,
            },
            CopyState::Done => return Poll::Ready(Ok(CopyPoll::Finished)),
        }
    }
}

/// Bytes transferred in each direction during a relay session.
#[derive(Debug, Clone, Copy, Default)]
pub struct RelayStats {
    /// Bytes from inbound to outbound (client → target).
    pub inbound: u64,
    /// Bytes from outbound to inbound (target → client).
    pub outbound: u64,
}

impl RelayStats {
    /// Total bytes transferred in both directions.
    #[inline]
    pub fn total(self) -> u64 {
        self.inbound + self.outbound
    }
}

/// Bidirectional relay with proper half-close handling.
///
/// Both directions run concurrently within a single task using poll-based
/// I/O, so back-pressure on one direction cannot stall the other. An
/// idle-timeout fires when **neither** direction has transferred data
/// within `idle_timeout`.
///
/// # Arguments
///
/// * `inbound` - The inbound stream (e.g., client connection)
/// * `outbound` - The outbound stream (e.g., target server connection)
/// * `idle_timeout` - Maximum time without data transfer before closing
/// * `buffer_size` - Size of the read buffers
/// * `metrics` - Metrics recorder for tracking bytes transferred
pub async fn relay_bidirectional<A, B, M>(
    mut inbound: A,
    mut outbound: B,
    idle_timeout: Duration,
    buffer_size: usize,
    metrics: &M,
) -> io::Result<RelayStats>
where
    A: AsyncRead + AsyncWrite + Unpin,
    B: AsyncRead + AsyncWrite + Unpin,
    M: RelayMetrics,
{
    let mut buf_a = vec![0u8; buffer_size];
    let mut buf_b = vec![0u8; buffer_size];
    let mut state_a = CopyState::Reading(0);
    let mut state_b = CopyState::Reading(0);

    let idle_sleep = tokio::time::sleep(idle_timeout);
    tokio::pin!(idle_sleep);

    let mut a_done = false;
    let mut b_done = false;
    let mut total_inbound: u64 = 0;
    let mut total_outbound: u64 = 0;

    let bidi_result: io::Result<RelayStats> = loop {
        if a_done && b_done {
            break Ok(RelayStats {
                inbound: total_inbound,
                outbound: total_outbound,
            });
        }

        // Build a future that polls both directions concurrently.
        // Each direction registers its own waker so either can make progress
        // independently — one blocked write cannot stall the other direction.
        let both = std::future::poll_fn(|cx| {
            let mut any_ready = false;
            let mut activity = false;
            let mut error: Option<io::Error> = None;

            if !a_done {
                match poll_copy_direction(
                    cx,
                    &mut inbound,
                    &mut outbound,
                    &mut buf_a,
                    &mut state_a,
                    |n| {
                        metrics.record_inbound(n as u64);
                        total_inbound += n as u64;
                        activity = true;
                    },
                ) {
                    Poll::Ready(Ok(CopyPoll::Flushed(n))) => {
                        activity |= n > 0;
                        any_ready = true;
                    }
                    Poll::Ready(Ok(CopyPoll::Finished)) => {
                        a_done = true;
                        any_ready = true;
                    }
                    Poll::Ready(Err(e)) => {
                        error = Some(e);
                        any_ready = true;
                    }
                    Poll::Pending => {}
                }
            }

            if !b_done {
                match poll_copy_direction(
                    cx,
                    &mut outbound,
                    &mut inbound,
                    &mut buf_b,
                    &mut state_b,
                    |n| {
                        metrics.record_outbound(n as u64);
                        total_outbound += n as u64;
                        activity = true;
                    },
                ) {
                    Poll::Ready(Ok(CopyPoll::Flushed(n))) => {
                        activity |= n > 0;
                        any_ready = true;
                    }
                    Poll::Ready(Ok(CopyPoll::Finished)) => {
                        b_done = true;
                        any_ready = true;
                    }
                    Poll::Ready(Err(e)) => {
                        error = Some(e);
                        any_ready = true;
                    }
                    Poll::Pending => {}
                }
            }

            if let Some(e) = error {
                return Poll::Ready(Err(e));
            }

            if any_ready || activity {
                Poll::Ready(Ok(activity))
            } else {
                Poll::Pending
            }
        });

        tokio::select! {
            result = both => {
                match result {
                    Ok(activity) => {
                        if activity {
                            idle_sleep.as_mut().reset(TokioInstant::now() + idle_timeout);
                        }
                    }
                    Err(e) => break Err(e),
                }
            }
            _ = &mut idle_sleep => {
                break Ok(RelayStats {
                    inbound: total_inbound,
                    outbound: total_outbound,
                });
            }
        }
    };

    // Run a final shutdown on each stream. Critical
    // for TLS streams: when the bidi loop errors out (e.g. target sent RST,
    // or one direction's reader closed before the per-direction shutdown
    // could complete), the underlying TCP socket would otherwise be dropped
    // without a TLS alert and peers would see `UnexpectedEof` instead of a
    // clean `Ok(0)`. Best-effort — ignore shutdown errors so they don't mask
    // the original loop error.
    let _ = inbound.shutdown().await;
    let _ = outbound.shutdown().await;

    bidi_result
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::VecDeque;
    use std::future::Future;
    use std::sync::atomic::{AtomicU64, Ordering};
    use tokio::io::{AsyncReadExt, AsyncWriteExt, duplex};

    struct TestMetrics {
        inbound: AtomicU64,
        outbound: AtomicU64,
    }

    impl TestMetrics {
        fn new() -> Self {
            Self {
                inbound: AtomicU64::new(0),
                outbound: AtomicU64::new(0),
            }
        }
    }

    impl RelayMetrics for TestMetrics {
        fn record_inbound(&self, bytes: u64) {
            self.inbound.fetch_add(bytes, Ordering::Relaxed);
        }
        fn record_outbound(&self, bytes: u64) {
            self.outbound.fetch_add(bytes, Ordering::Relaxed);
        }
    }

    #[tokio::test]
    async fn test_relay_basic() {
        let (client, server_side) = duplex(1024);
        let (target_side, target) = duplex(1024);

        let metrics = TestMetrics::new();

        // Spawn relay
        let relay_handle = tokio::spawn(async move {
            relay_bidirectional(
                server_side,
                target_side,
                Duration::from_secs(5),
                1024,
                &metrics,
            )
            .await
        });

        // Client sends data
        let (mut client_r, mut client_w) = tokio::io::split(client);
        let (mut target_r, mut target_w) = tokio::io::split(target);

        client_w.write_all(b"hello").await.unwrap();
        drop(client_w); // Close write side

        let mut buf = vec![0u8; 1024];
        let n = target_r.read(&mut buf).await.unwrap();
        assert_eq!(&buf[..n], b"hello");

        // Target sends response
        target_w.write_all(b"world").await.unwrap();
        drop(target_w);

        let n = client_r.read(&mut buf).await.unwrap();
        assert_eq!(&buf[..n], b"world");

        // Relay should complete
        relay_handle.await.unwrap().unwrap();
    }

    #[tokio::test]
    async fn test_relay_idle_timeout() {
        let (client, server_side) = duplex(1024);
        let (target_side, _target) = duplex(1024);

        let start = TokioInstant::now();
        let result = relay_bidirectional(
            server_side,
            target_side,
            Duration::from_millis(50),
            1024,
            &NoOpMetrics,
        )
        .await;

        result.unwrap();
        assert!(start.elapsed() >= Duration::from_millis(50));

        drop(client); // cleanup
    }

    #[tokio::test]
    async fn relay_preserves_both_directions_under_backpressure_and_half_close() {
        async fn exchange(stream: tokio::io::DuplexStream, sent: &[u8], expected: &[u8]) {
            let (mut reader, mut writer) = tokio::io::split(stream);
            let send = async {
                writer.write_all(sent).await?;
                writer.shutdown().await
            };
            let receive = async {
                let mut received = Vec::new();
                reader.read_to_end(&mut received).await?;
                assert_eq!(received, expected);
                Ok::<_, io::Error>(())
            };
            tokio::try_join!(send, receive).unwrap();
        }

        let (client, inbound) = duplex(32);
        let (outbound, target) = duplex(32);
        let upload = vec![0x21; 4096];
        let download = vec![0xde; 65536];
        let metrics = TestMetrics::new();
        let (_, _, result) = tokio::time::timeout(Duration::from_secs(10), async {
            tokio::join!(
                exchange(client, &upload, &download),
                exchange(target, &download, &upload),
                relay_bidirectional(inbound, outbound, Duration::from_secs(60), 16, &metrics,),
            )
        })
        .await
        .expect("both relay directions must make progress");

        let stats = result.unwrap();
        assert_eq!(stats.inbound, upload.len() as u64);
        assert_eq!(stats.outbound, download.len() as u64);
        assert_eq!(metrics.inbound.load(Ordering::Relaxed), stats.inbound);
        assert_eq!(metrics.outbound.load(Ordering::Relaxed), stats.outbound);
    }

    #[tokio::test]
    async fn partial_write_is_counted_before_cancellation() {
        let (mut client, inbound) = duplex(8);
        let (outbound, mut target) = duplex(1);
        client.write_all(b"ab").await.unwrap();
        let metrics = TestMetrics::new();
        let mut relay = Box::pin(relay_bidirectional(
            inbound,
            outbound,
            Duration::from_secs(60),
            8,
            &metrics,
        ));

        let mut cx = Context::from_waker(std::task::Waker::noop());
        assert!(relay.as_mut().poll(&mut cx).is_pending());
        assert_eq!(metrics.inbound.load(Ordering::Relaxed), 1);
        drop(relay);

        let mut received = Vec::new();
        target.read_to_end(&mut received).await.unwrap();
        assert_eq!(received, b"a");
        assert_eq!(metrics.inbound.load(Ordering::Relaxed), 1);
    }

    #[tokio::test]
    async fn partial_write_remains_counted_after_write_error() {
        let (mut client, inbound) = duplex(8);
        let (outbound, target) = duplex(1);
        client.write_all(b"ab").await.unwrap();
        let metrics = TestMetrics::new();
        let mut relay = Box::pin(relay_bidirectional(
            inbound,
            outbound,
            Duration::from_secs(60),
            8,
            &metrics,
        ));

        let mut cx = Context::from_waker(std::task::Waker::noop());
        assert!(relay.as_mut().poll(&mut cx).is_pending());
        assert_eq!(metrics.inbound.load(Ordering::Relaxed), 1);
        drop(target);

        assert_eq!(relay.await.unwrap_err().kind(), io::ErrorKind::BrokenPipe);
        assert_eq!(metrics.inbound.load(Ordering::Relaxed), 1);
    }

    #[tokio::test]
    async fn accepted_bytes_are_counted_while_flush_is_pending() {
        let (mut client, inbound) = duplex(8);
        let (outbound, mut target) = duplex(1);
        let outbound = tokio::io::BufWriter::with_capacity(8, outbound);
        client.write_all(b"ab").await.unwrap();
        let metrics = TestMetrics::new();
        let mut relay = Box::pin(relay_bidirectional(
            inbound,
            outbound,
            Duration::from_secs(60),
            8,
            &metrics,
        ));

        let mut cx = Context::from_waker(std::task::Waker::noop());
        assert!(relay.as_mut().poll(&mut cx).is_pending());
        assert_eq!(metrics.inbound.load(Ordering::Relaxed), 2);
        drop(relay);

        let mut received = Vec::new();
        target.read_to_end(&mut received).await.unwrap();
        assert_eq!(received, b"a");
        assert_eq!(metrics.inbound.load(Ordering::Relaxed), 2);
    }

    #[test]
    fn zero_byte_write_returns_write_zero_without_spinning() {
        struct ZeroWriter(bool);

        impl AsyncWrite for ZeroWriter {
            fn poll_write(
                mut self: Pin<&mut Self>,
                _cx: &mut Context<'_>,
                _buf: &[u8],
            ) -> Poll<io::Result<usize>> {
                assert!(!self.0, "a zero-byte write must not be polled again");
                self.0 = true;
                Poll::Ready(Ok(0))
            }

            fn poll_flush(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<io::Result<()>> {
                panic!("a failed write must not reach flush");
            }

            fn poll_shutdown(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<io::Result<()>> {
                Poll::Ready(Ok(()))
            }
        }

        let mut reader = &b"payload"[..];
        let mut writer = ZeroWriter(false);
        let mut buffer = [0; 32];
        let mut state = CopyState::Reading(0);
        let mut cx = Context::from_waker(std::task::Waker::noop());
        match poll_copy_direction(
            &mut cx,
            &mut reader,
            &mut writer,
            &mut buffer,
            &mut state,
            |_| {},
        ) {
            Poll::Ready(Err(error)) => assert_eq!(error.kind(), io::ErrorKind::WriteZero),
            _ => panic!("a zero-byte write must return WriteZero"),
        }
    }

    // ── Flush-batching tests ──

    /// A mock reader that yields chunks from a queue.
    /// Returns `Pending` (with waker notification) between groups separated
    /// by `None` entries, simulating data arriving in bursts.
    struct MockReader {
        /// `Some(data)` = a read returning data, `None` = return Pending once.
        chunks: VecDeque<Option<Vec<u8>>>,
        pending_waker: Option<std::task::Waker>,
    }

    impl MockReader {
        fn new(chunks: Vec<Option<Vec<u8>>>) -> Self {
            Self {
                chunks: chunks.into(),
                pending_waker: None,
            }
        }
    }

    impl AsyncRead for MockReader {
        fn poll_read(
            mut self: Pin<&mut Self>,
            cx: &mut Context<'_>,
            buf: &mut ReadBuf<'_>,
        ) -> Poll<io::Result<()>> {
            match self.chunks.front() {
                Some(Some(_)) => {
                    let data = self.chunks.pop_front().unwrap().unwrap();
                    buf.put_slice(&data);
                    Poll::Ready(Ok(()))
                }
                Some(None) => {
                    // Consume the Pending marker, wake immediately so the
                    // next poll will return the next chunk.
                    self.chunks.pop_front();
                    self.pending_waker = Some(cx.waker().clone());
                    // Schedule a wake so the state machine advances.
                    cx.waker().wake_by_ref();
                    Poll::Pending
                }
                None => {
                    // EOF
                    Poll::Ready(Ok(()))
                }
            }
        }
    }

    /// A writer that counts flush calls and records written data.
    struct FlushCountingWriter {
        written: Vec<u8>,
        flush_count: usize,
    }

    impl FlushCountingWriter {
        fn new() -> Self {
            Self {
                written: Vec::new(),
                flush_count: 0,
            }
        }
    }

    impl AsyncWrite for FlushCountingWriter {
        fn poll_write(
            mut self: Pin<&mut Self>,
            _cx: &mut Context<'_>,
            buf: &[u8],
        ) -> Poll<io::Result<usize>> {
            self.written.extend_from_slice(buf);
            Poll::Ready(Ok(buf.len()))
        }

        fn poll_flush(mut self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<io::Result<()>> {
            self.flush_count += 1;
            Poll::Ready(Ok(()))
        }

        fn poll_shutdown(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<io::Result<()>> {
            Poll::Ready(Ok(()))
        }
    }

    #[tokio::test]
    async fn test_flush_batching_consecutive_reads() {
        // Simulate 3 chunks arriving in a burst (no Pending between them),
        // followed by EOF. The state machine should batch all 3 writes into
        // a single flush (the EOF flush).
        let mut reader = MockReader::new(vec![
            Some(b"aaa".to_vec()),
            Some(b"bbb".to_vec()),
            Some(b"ccc".to_vec()),
            // EOF follows (empty queue)
        ]);
        let mut writer = FlushCountingWriter::new();
        let mut buf = vec![0u8; 64];
        let mut state = CopyState::Reading(0);

        let mut total_bytes = 0;
        loop {
            let result = std::future::poll_fn(|cx| {
                poll_copy_direction(cx, &mut reader, &mut writer, &mut buf, &mut state, |_| {})
            })
            .await
            .unwrap();
            match result {
                CopyPoll::Flushed(n) => total_bytes += n,
                CopyPoll::Finished => break,
            }
        }

        assert_eq!(writer.written, b"aaabbbccc");
        assert_eq!(total_bytes, 9);
        // All 3 chunks were available consecutively — should batch into 1 flush
        // (the EOF-triggered flush), not 3 separate flushes.
        assert_eq!(
            writer.flush_count, 1,
            "consecutive reads should batch flushes"
        );
    }

    #[tokio::test]
    async fn test_flush_on_pending() {
        // Simulate: chunk1, Pending, chunk2, Pending, EOF.
        // Should flush after each Pending (2 flushes) plus EOF flush (but
        // EOF after Pending with 0 accumulated goes straight to shutdown).
        // Actually: chunk1 → write → Reading(3) → Pending → Flushing(3) → flush#1
        //           chunk2 → write → Reading(3) → Pending → but no accumulated → Pending
        //           Wait, after flush#1 we reset to Reading(0), then read chunk2...
        // Let me trace: chunk1 → write → Reading(3) → Pending → Flush(3, false) → flush#1
        //               Reading(0) → chunk2 → write → Reading(3) → Pending → Flush(3, false) → flush#2
        //               Reading(0) → EOF → ShuttingDown → Finished
        let mut reader = MockReader::new(vec![
            Some(b"aaa".to_vec()),
            None, // Pending
            Some(b"bbb".to_vec()),
            None, // Pending
                  // EOF
        ]);
        let mut writer = FlushCountingWriter::new();
        let mut buf = vec![0u8; 64];
        let mut state = CopyState::Reading(0);

        let mut total_bytes = 0;
        loop {
            let result = std::future::poll_fn(|cx| {
                poll_copy_direction(cx, &mut reader, &mut writer, &mut buf, &mut state, |_| {})
            })
            .await
            .unwrap();
            match result {
                CopyPoll::Flushed(n) => total_bytes += n,
                CopyPoll::Finished => break,
            }
        }

        assert_eq!(writer.written, b"aaabbb");
        assert_eq!(total_bytes, 6);
        // 2 flushes: one after each Pending gap.
        assert_eq!(writer.flush_count, 2, "should flush once per Pending gap");
    }

    #[tokio::test]
    async fn test_flush_batching_burst_then_pending() {
        // 3 chunks in a burst, then Pending, then 1 more chunk, then EOF.
        // Should produce 2 flushes: one for the burst (at Pending), one at EOF.
        let mut reader = MockReader::new(vec![
            Some(b"a".to_vec()),
            Some(b"b".to_vec()),
            Some(b"c".to_vec()),
            None, // Pending — triggers flush of accumulated 3 bytes
            Some(b"d".to_vec()),
            // EOF — triggers flush of 1 byte
        ]);
        let mut writer = FlushCountingWriter::new();
        let mut buf = vec![0u8; 64];
        let mut state = CopyState::Reading(0);

        let mut total_bytes = 0;
        loop {
            let result = std::future::poll_fn(|cx| {
                poll_copy_direction(cx, &mut reader, &mut writer, &mut buf, &mut state, |_| {})
            })
            .await
            .unwrap();
            match result {
                CopyPoll::Flushed(n) => total_bytes += n,
                CopyPoll::Finished => break,
            }
        }

        assert_eq!(writer.written, b"abcd");
        assert_eq!(total_bytes, 4);
        assert_eq!(
            writer.flush_count, 2,
            "burst then pending then EOF = 2 flushes"
        );
    }
}
