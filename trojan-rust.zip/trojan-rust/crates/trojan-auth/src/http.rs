//! HTTP authentication backend.
//!
//! Delegates authentication to a remote dashboard worker (e.g. Cloudflare Worker)
//! over HTTP, with local stale-while-revalidate caching via [`StoreAuth`].
//!
//! # Example
//!
//! ```no_run
//! use trojan_auth::http::{HttpAuth, HttpAuthConfig, Codec};
//!
//! let config = HttpAuthConfig {
//!     base_url: "https://auth.example.workers.dev".into(),
//!     codec: Codec::Bincode,
//!     ..Default::default()
//! };
//! let auth = HttpAuth::new(config);
//! ```

use std::sync::Arc;
use std::time::Duration;

use async_trait::async_trait;
use reqwest::Client;
use serde::{Deserialize, Serialize};

use crate::protocol;
use crate::result::NodeQuota;
use crate::store::record::to_storage_i64;
use crate::store::{
    FlushFn, StoreAuth, StoreAuthConfig, TrafficRecorder, TrafficRecordingMode, UserRecord,
    UserStore,
};
use crate::{AuthBackend, AuthError, AuthResult};

// ── Codec ─────────────────────────────────────────────────────────

/// Serialization codec for the HTTP wire protocol.
#[derive(Debug, Clone, Copy, Default, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Codec {
    /// Bincode — compact binary format (default).
    #[default]
    Bincode,
    /// JSON — human-readable, easier to debug with curl.
    Json,
}

// ── HttpAuthConfig ────────────────────────────────────────────────

/// Configuration for the HTTP authentication backend.
#[derive(Debug, Clone)]
pub struct HttpAuthConfig {
    /// Auth-worker base URL (e.g. `https://auth.example.workers.dev`).
    pub base_url: String,
    /// Serialization codec for the wire protocol.
    pub codec: Codec,
    /// Bearer token for node authentication (from admin dashboard).
    pub node_token: Option<String>,
    /// Positive cache TTL (default: 300s = 5 min).
    pub cache_ttl: Duration,
    /// Stale-while-revalidate window (default: 600s = 10 min).
    ///
    /// Stale cache entries are served immediately while being
    /// revalidated in the background.
    pub stale_ttl: Duration,
    /// Negative cache TTL (default: 10s).
    ///
    /// Invalid hashes are cached for this duration to prevent flooding.
    pub neg_cache_ttl: Duration,
    /// Traffic batch flush interval (default: 30s).
    ///
    /// Traffic updates are accumulated in memory and flushed to the
    /// dashboard worker at this interval.
    pub batch_flush_interval: Duration,
}

impl Default for HttpAuthConfig {
    fn default() -> Self {
        Self {
            base_url: String::new(),
            codec: Codec::default(),
            node_token: None,
            cache_ttl: Duration::from_secs(300),
            stale_ttl: Duration::from_secs(600),
            neg_cache_ttl: Duration::from_secs(10),
            batch_flush_interval: Duration::from_secs(30),
        }
    }
}

impl HttpAuthConfig {
    /// Extract the generic [`StoreAuthConfig`] for constructing [`StoreAuth`].
    fn store_auth_config(&self) -> StoreAuthConfig {
        StoreAuthConfig {
            traffic_mode: TrafficRecordingMode::Batched,
            batch_flush_interval: self.batch_flush_interval,
            batch_max_pending: 1000,
            cache_enabled: self.cache_ttl > Duration::ZERO,
            cache_ttl: self.cache_ttl,
            stale_ttl: self.stale_ttl,
            neg_cache_ttl: self.neg_cache_ttl,
        }
    }
}

// ── HttpStore ─────────────────────────────────────────────────────

/// HTTP user store that delegates to a remote dashboard worker.
///
/// Implements [`UserStore`] by calling the dashboard worker's `/verify` and
/// `/traffic` endpoints.
///
/// Cloning is cheap — `reqwest::Client` is Arc-internal, the URLs/token are
/// owned but small. The flush_fn closure clones the store per-task so each
/// concurrent POST has its own handle.
#[derive(Debug, Clone)]
pub struct HttpStore {
    client: Client,
    verify_url: String,
    traffic_url: String,
    chain_traffic_url: String,
    codec: Codec,
    node_token: Option<String>,
}

impl HttpStore {
    /// Create a new HTTP store.
    fn new(base_url: &str, codec: Codec, node_token: Option<String>) -> Self {
        let base = base_url.trim_end_matches('/');
        Self {
            client: Client::new(),
            verify_url: format!("{base}/verify"),
            traffic_url: format!("{base}/traffic"),
            chain_traffic_url: format!("{base}/traffic/chain"),
            codec,
            node_token,
        }
    }

    /// Credit one relay hop with bytes it carried for a user.
    async fn add_chain_traffic(
        &self,
        user_id: &str,
        node_id: &str,
        bytes: u64,
    ) -> Result<(), AuthError> {
        let req = protocol::ChainTrafficRequest {
            user_id: user_id.to_owned(),
            node_id: node_id.to_owned(),
            bytes,
        };
        let result: Result<(), protocol::AuthError> =
            self.request(&self.chain_traffic_url, &req).await?;
        result.map_err(Into::into)
    }

    /// Send a request and decode the response.
    async fn request<Req: Serialize, Resp: for<'de> Deserialize<'de>>(
        &self,
        url: &str,
        body: &Req,
    ) -> Result<Resp, AuthError> {
        let resp = match self.codec {
            Codec::Bincode => {
                let bytes = bincode::serialize(body).map_err(AuthError::backend)?;
                let mut req = self
                    .client
                    .post(url)
                    .timeout(Duration::from_secs(10))
                    .header("Content-Type", "application/octet-stream");
                if let Some(ref token) = self.node_token {
                    req = req.header("Authorization", format!("Bearer {token}"));
                }
                req.body(bytes).send().await.map_err(AuthError::backend)?
            }
            Codec::Json => {
                let mut req = self.client.post(url).timeout(Duration::from_secs(10));
                if let Some(ref token) = self.node_token {
                    req = req.header("Authorization", format!("Bearer {token}"));
                }
                req.json(body).send().await.map_err(AuthError::backend)?
            }
        };

        if !resp.status().is_success() {
            return Err(AuthError::Backend(format!(
                "HTTP {}",
                resp.status().as_u16()
            )));
        }

        match self.codec {
            Codec::Bincode => {
                let bytes = resp.bytes().await.map_err(AuthError::backend)?;
                bincode::deserialize(&bytes).map_err(AuthError::backend)
            }
            Codec::Json => resp.json().await.map_err(AuthError::backend),
        }
    }
}

#[async_trait]
impl UserStore for HttpStore {
    async fn find_by_hash(&self, hash: &str) -> Result<Option<UserRecord>, AuthError> {
        let req = protocol::VerifyRequest {
            hash: hash.to_owned(),
        };
        let result: Result<protocol::AuthResult, protocol::AuthError> =
            self.request(&self.verify_url, &req).await?;
        match result {
            Ok(auth_result) => {
                let meta = auth_result.metadata.as_ref();
                Ok(Some(UserRecord {
                    user_id: auth_result.user_id,
                    traffic_limit: meta.map_or(0, |m| to_storage_i64(m.traffic_limit)),
                    traffic_used: meta.map_or(0, |m| to_storage_i64(m.traffic_used)),
                    expires_at: meta.map_or(0, |m| to_storage_i64(m.expires_at)),
                    enabled: meta.is_none_or(|m| m.enabled),
                    node_quotas: meta.map_or_else(Vec::new, |m| {
                        m.node_quotas
                            .iter()
                            .map(|q| NodeQuota {
                                node_id: q.node_id.clone(),
                                limit: q.limit,
                                used: q.used,
                            })
                            .collect()
                    }),
                }))
            }
            Err(protocol::AuthError::Invalid | protocol::AuthError::NotFound) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    async fn add_traffic(&self, user_id: &str, bytes: u64) -> Result<(), AuthError> {
        let req = protocol::TrafficRequest {
            user_id: user_id.to_owned(),
            bytes,
        };
        let result: Result<(), protocol::AuthError> = self.request(&self.traffic_url, &req).await?;
        result.map_err(Into::into)
    }
}

// ── HttpAuth ──────────────────────────────────────────────────────

/// HTTP authentication backend with stale-while-revalidate caching.
///
/// Wraps [`StoreAuth<HttpStore>`] to provide:
/// - Positive caching with configurable TTL
/// - Stale-while-revalidate: stale cache entries are served immediately
///   while being revalidated in the background
/// - Negative caching for invalid hashes
pub struct HttpAuth {
    inner: StoreAuth<HttpStore>,
    /// Batches the credit owed to relay hops, keyed per user and hop so bytes
    /// for one user across two chains are not merged into one.
    chain_recorder: Option<TrafficRecorder<ChainCredit>>,
}

/// One relay hop's share of a user's traffic, as a batch key.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct ChainCredit {
    user_id: String,
    node_id: String,
}

impl HttpAuth {
    /// Create a new HTTP auth backend from configuration.
    pub fn new(config: HttpAuthConfig) -> Self {
        let store_config = config.store_auth_config();
        let store = HttpStore::new(&config.base_url, config.codec, config.node_token.clone());

        let mut auth = StoreAuth::new(store, &store_config);

        // Set up batched traffic recording
        if store_config.traffic_mode == TrafficRecordingMode::Batched {
            // Reuse HttpStore::add_traffic for the actual POST. We clone the
            // store per-task so each concurrent POST has its own handle.
            let store_for_flush =
                HttpStore::new(&config.base_url, config.codec, config.node_token.clone());

            let flush_fn: FlushFn = Arc::new(move |batch| {
                let store = store_for_flush.clone();
                Box::pin(async move {
                    let mut tasks = tokio::task::JoinSet::new();
                    for (user_id, bytes) in batch {
                        if tasks.len() == 16 {
                            tasks
                                .join_next()
                                .await
                                .unwrap()
                                .map_err(AuthError::backend)?;
                        }
                        let store = store.clone();
                        tasks.spawn(async move {
                            if let Err(e) = store.add_traffic(&user_id, bytes).await {
                                tracing::warn!(
                                    user_id = %user_id,
                                    bytes = bytes,
                                    error = %e,
                                    "failed to flush traffic record"
                                );
                            }
                        });
                    }
                    while let Some(result) = tasks.join_next().await {
                        result.map_err(AuthError::backend)?;
                    }
                    Ok(())
                })
            });

            let recorder = TrafficRecorder::new(
                store_config.batch_flush_interval,
                store_config.batch_max_pending,
                flush_fn,
            );
            auth = auth.with_traffic_recorder(recorder);
        }

        // Chain credit is batched on its own schedule and never touches the
        // cache: it does not move anyone's quota, so a verify decision never
        // waits on it.
        let chain_store = HttpStore::new(&config.base_url, config.codec, config.node_token.clone());
        let chain_flush: FlushFn<ChainCredit> = Arc::new(move |batch| {
            let store = chain_store.clone();
            Box::pin(async move {
                let mut tasks = tokio::task::JoinSet::new();
                for (credit, bytes) in batch {
                    if tasks.len() == 16 {
                        tasks
                            .join_next()
                            .await
                            .unwrap()
                            .map_err(AuthError::backend)?;
                    }
                    let store = store.clone();
                    tasks.spawn(async move {
                        if let Err(e) = store
                            .add_chain_traffic(&credit.user_id, &credit.node_id, bytes)
                            .await
                        {
                            tracing::warn!(
                                user_id = %credit.user_id,
                                node_id = %credit.node_id,
                                bytes = bytes,
                                error = %e,
                                "failed to flush chain traffic record"
                            );
                        }
                    });
                }
                while let Some(result) = tasks.join_next().await {
                    result.map_err(AuthError::backend)?;
                }
                Ok(())
            })
        });

        Self {
            inner: auth,
            chain_recorder: Some(TrafficRecorder::new(
                store_config.batch_flush_interval,
                store_config.batch_max_pending,
                chain_flush,
            )),
        }
    }
}

#[async_trait]
impl AuthBackend for HttpAuth {
    async fn verify(&self, hash: &str) -> Result<AuthResult, AuthError> {
        self.inner.verify(hash).await
    }

    async fn record_traffic(&self, user_id: &str, bytes: u64) -> Result<(), AuthError> {
        self.inner.record_traffic(user_id, bytes).await
    }

    async fn record_chain_traffic(
        &self,
        user_id: &str,
        bytes: u64,
        nodes: &[String],
    ) -> Result<(), AuthError> {
        let Some(ref recorder) = self.chain_recorder else {
            return Ok(());
        };
        for node_id in nodes {
            recorder
                .record(
                    ChainCredit {
                        user_id: user_id.to_owned(),
                        node_id: node_id.clone(),
                    },
                    bytes,
                )
                .await?;
        }
        Ok(())
    }

    fn pending_chain_bytes(&self, user_id: &str, node_id: &str) -> u64 {
        self.chain_recorder.as_ref().map_or(0, |recorder| {
            recorder.pending_for(&ChainCredit {
                user_id: user_id.to_owned(),
                node_id: node_id.to_owned(),
            })
        })
    }

    async fn shutdown(&self) {
        self.inner.shutdown().await;
        if let Some(ref recorder) = self.chain_recorder {
            recorder.shutdown().await;
        }
    }
}

impl std::fmt::Debug for HttpAuth {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("HttpAuth")
            .field("inner", &self.inner)
            .finish()
    }
}

// ── Protocol ↔ core conversions ───────────────────────────────────────

impl From<protocol::AuthError> for AuthError {
    fn from(w: protocol::AuthError) -> Self {
        match w {
            protocol::AuthError::Invalid => Self::Invalid,
            protocol::AuthError::Backend(s) => Self::Backend(s),
            protocol::AuthError::NotFound => Self::NotFound,
            protocol::AuthError::TrafficExceeded => Self::TrafficExceeded,
            protocol::AuthError::Expired => Self::Expired,
            protocol::AuthError::Disabled => Self::Disabled,
        }
    }
}
