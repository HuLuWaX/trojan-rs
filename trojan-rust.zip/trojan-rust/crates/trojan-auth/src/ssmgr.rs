//! ssmgr-compatible authentication and management backed by Redis.
//!
//! Uses the same keys as `llc1123/ssmgr-trojan-client`: `user:<id>` contains
//! the SHA-224 password hash, and that hash is a Redis hash with `upload` and
//! `download` counters. This small RESP2 client avoids an extra Redis crate.

use std::{collections::HashMap, sync::{Arc, Mutex}, time::{SystemTime, UNIX_EPOCH}};

use async_trait::async_trait;
use md5::{Digest, Md5};
use serde::Deserialize;
use tokio::{
    io::{AsyncBufReadExt, AsyncReadExt, AsyncWriteExt, BufReader},
    net::{TcpListener, TcpStream},
    sync::RwLock,
};

use crate::{AuthBackend, AuthError, AuthMetadata, AuthResult};

#[derive(Debug, Clone)]
struct RedisConfig { address: String, password: Option<String>, database: u32 }

impl RedisConfig {
    fn parse(url: &str) -> Result<Self, AuthError> {
        let rest = url.strip_prefix("redis://")
            .ok_or_else(|| AuthError::backend("ssmgr Redis URL must start with redis://"))?;
        let (authority, path) = rest.split_once('/').unwrap_or((rest, "0"));
        let database = path.split('?').next().unwrap_or("0").parse::<u32>()
            .map_err(AuthError::backend)?;
        let (credentials, host) = authority.rsplit_once('@').map_or((None, authority), |(a, h)| (Some(a), h));
        let password = credentials.and_then(|c| c.rsplit_once(':').map(|(_, p)| p.to_owned()).or_else(|| Some(c.to_owned())));
        let address = if host.contains(':') { host.to_owned() } else { format!("{host}:6379") };
        if address.is_empty() { return Err(AuthError::backend("Redis URL has no host")); }
        Ok(Self { address, password, database })
    }

    async fn execute(&self, args: &[String]) -> Result<RespValue, AuthError> {
        let mut stream = TcpStream::connect(&self.address).await.map_err(AuthError::backend)?;
        if let Some(password) = &self.password {
            let reply = redis_command(&mut stream, &["AUTH".to_owned(), password.clone()]).await?;
            reply.into_result()?;
        }
        if self.database != 0 {
            let reply = redis_command(&mut stream, &["SELECT".to_owned(), self.database.to_string()]).await?;
            reply.into_result()?;
        }
        redis_command(&mut stream, args).await?.into_result()
    }
}

#[derive(Debug, Clone)]
enum RespValue { Simple(String), Error(String), Integer(i64), Bulk(Option<Vec<u8>>), Array(Vec<RespValue>) }

impl RespValue {
    fn into_result(self) -> Result<Self, AuthError> {
        match self { Self::Error(message) => Err(AuthError::backend(message)), value => Ok(value) }
    }
    fn text(self) -> Result<String, AuthError> {
        match self {
            Self::Simple(v) => Ok(v),
            Self::Bulk(Some(v)) => String::from_utf8(v).map_err(AuthError::backend),
            Self::Integer(v) => Ok(v.to_string()),
            other => Err(AuthError::backend(format!("unexpected Redis response: {other:?}"))),
        }
    }
    fn bytes(self) -> Result<Option<Vec<u8>>, AuthError> {
        match self { Self::Bulk(v) => Ok(v), Self::Simple(v) => Ok(Some(v.into_bytes())), other => Err(AuthError::backend(format!("unexpected Redis response: {other:?}"))) }
    }
    fn array(self) -> Result<Vec<Self>, AuthError> {
        match self { Self::Array(v) => Ok(v), other => Err(AuthError::backend(format!("unexpected Redis array: {other:?}"))) }
    }
}

async fn redis_command(stream: &mut TcpStream, args: &[String]) -> Result<RespValue, AuthError> {
    let mut request = format!("*{}\r\n", args.len()).into_bytes();
    for arg in args {
        request.extend_from_slice(format!("${}\r\n", arg.len()).as_bytes());
        request.extend_from_slice(arg.as_bytes());
        request.extend_from_slice(b"\r\n");
    }
    stream.write_all(&request).await.map_err(AuthError::backend)?;
    let mut reader = BufReader::new(stream);
    read_resp(&mut reader).await
}

async fn read_resp(reader: &mut BufReader<&mut TcpStream>) -> Result<RespValue, AuthError> {
    let mut prefix = [0; 1];
    reader.read_exact(&mut prefix).await.map_err(AuthError::backend)?;
    match prefix[0] {
        b'+' | b'-' | b':' => {
            let line = read_line(reader).await?;
            match prefix[0] {
                b'+' => Ok(RespValue::Simple(line)),
                b'-' => Ok(RespValue::Error(line)),
                _ => Ok(RespValue::Integer(line.parse().map_err(AuthError::backend)?)),
            }
        }
        b'$' => {
            let len: i64 = read_line(reader).await?.parse().map_err(AuthError::backend)?;
            if len < 0 { return Ok(RespValue::Bulk(None)); }
            let mut value = vec![0; len as usize];
            reader.read_exact(&mut value).await.map_err(AuthError::backend)?;
            let mut crlf = [0; 2];
            reader.read_exact(&mut crlf).await.map_err(AuthError::backend)?;
            Ok(RespValue::Bulk(Some(value)))
        }
        b'*' => {
            let len: i64 = read_line(reader).await?.parse().map_err(AuthError::backend)?;
            if len < 0 { return Ok(RespValue::Array(Vec::new())); }
            let mut values = Vec::with_capacity(len as usize);
            for _ in 0..len { values.push(Box::pin(read_resp(reader)).await?); }
            Ok(RespValue::Array(values))
        }
        byte => Err(AuthError::backend(format!("unsupported Redis RESP prefix: {byte}"))),
    }
}

async fn read_line(reader: &mut BufReader<&mut TcpStream>) -> Result<String, AuthError> {
    let mut line = Vec::new();
    reader.read_until(b'\n', &mut line).await.map_err(AuthError::backend)?;
    if line.len() < 2 || !line.ends_with(b"\r\n") { return Err(AuthError::backend("malformed Redis response")); }
    line.truncate(line.len() - 2);
    String::from_utf8(line).map_err(AuthError::backend)
}

/// Redis-backed ssmgr authentication and control protocol.
#[derive(Debug)]
pub struct SsmgrAuth {
    redis: RedisConfig,
    password_ids: Arc<RwLock<HashMap<String, String>>>,
    manager_task: Arc<Mutex<Option<tokio::task::JoinHandle<()>>>>,
}

impl SsmgrAuth {
    /// Connect to Redis and load the current `user:<id>` index.
    pub async fn connect(redis_url: &str) -> Result<Self, AuthError> {
        let redis = RedisConfig::parse(redis_url)?;
        let auth = Self { redis, password_ids: Arc::new(RwLock::new(HashMap::new())), manager_task: Arc::new(Mutex::new(None)) };
        auth.refresh_index().await?;
        Ok(auth)
    }

    async fn refresh_index(&self) -> Result<(), AuthError> {
        let mut cursor = "0".to_owned();
        let mut index = HashMap::new();
        loop {
            let response = self.redis.execute(&["SCAN".into(), cursor, "MATCH".into(), "user:*".into(), "COUNT".into(), "500".into()]).await?.array()?;
            cursor = response.first().ok_or_else(|| AuthError::backend("invalid Redis SCAN response"))?.clone().text()?;
            let keys = response.get(1).ok_or_else(|| AuthError::backend("invalid Redis SCAN keys"))?.clone().array()?;
            for key in keys {
                let key = key.text()?;
                if let Some(id) = key.strip_prefix("user:") {
                    let Some(hash) = self.redis.execute(&["GET".into(), key.clone()]).await?.bytes()? else { continue; };
                    if let Ok(hash) = String::from_utf8(hash) { index.insert(hash, id.to_owned()); }
                }
            }
            if cursor == "0" { break; }
        }
        *self.password_ids.write().await = index;
        Ok(())
    }

    /// Start the ssmgr management protocol listener.
    pub async fn serve_manager(&self, address: &str, key: String) -> std::io::Result<()> {
        let listener = TcpListener::bind(address).await?;
        let redis = self.redis.clone();
        let ids = self.password_ids.clone();
        let task = tokio::spawn(async move {
            loop {
                match listener.accept().await {
                    Ok((stream, _)) => {
                        let redis = redis.clone();
                        let ids = ids.clone();
                        let key = key.clone();
                        tokio::spawn(async move {
                            if let Err(error) = handle_manager_connection(stream, redis, ids, &key).await {
                                tracing::debug!(%error, "ssmgr management request failed");
                            }
                        });
                    }
                    Err(error) => tracing::error!(%error, "ssmgr listener accept failed"),
                }
            }
        });
        *self.manager_task.lock().expect("ssmgr task mutex poisoned") = Some(task);
        Ok(())
    }
}

impl Drop for SsmgrAuth {
    fn drop(&mut self) {
        if let Ok(task) = self.manager_task.lock() { if let Some(task) = task.as_ref() { task.abort(); } }
    }
}

#[async_trait]
impl AuthBackend for SsmgrAuth {
    async fn verify(&self, hash: &str) -> Result<AuthResult, AuthError> {
        let id = self.password_ids.read().await.get(hash).cloned();
        let Some(id) = id else { return Err(AuthError::Invalid); };
        let values = self.redis.execute(&["HMGET".into(), hash.into(), "upload".into(), "download".into()]).await?.array()?;
        if values.first().cloned().ok_or_else(|| AuthError::backend("invalid Redis HMGET"))?.bytes()?.is_none() { return Err(AuthError::Invalid); }
        let upload = number(values.first().cloned())?;
        let download = number(values.get(1).cloned())?;
        Ok(AuthResult { user_id: Some(id), metadata: Some(AuthMetadata {
            traffic_limit: 0, traffic_used: upload.saturating_add(download), expires_at: 0,
            enabled: true, node_quotas: Vec::new(),
        }) })
    }

    async fn record_traffic(&self, user_id: &str, bytes: u64) -> Result<(), AuthError> {
        let hash = self.password_ids.read().await.iter().find_map(|(hash, id)| (id == user_id).then(|| hash.clone()))
            .ok_or_else(|| AuthError::Invalid)?;
        self.redis.execute(&["HINCRBY".into(), hash, "upload".into(), bytes.to_string()]).await?;
        Ok(())
    }
}

fn number(value: Option<RespValue>) -> Result<u64, AuthError> {
    value.ok_or_else(|| AuthError::backend("missing Redis traffic counter"))?.text()?.parse().map_err(AuthError::backend)
}

#[derive(Deserialize)]
struct Request { command: String, #[serde(default)] port: u64, #[serde(default)] password: String }

async fn handle_manager_connection(mut stream: TcpStream, redis: RedisConfig, ids: Arc<RwLock<HashMap<String, String>>>, key: &str) -> std::io::Result<()> {
    loop {
        let mut head = [0u8; 2];
        if stream.read_exact(&mut head).await.is_err() { return Ok(()); }
        let length = u16::from_be_bytes(head) as usize;
        if !(14..=64 * 1024).contains(&length) { return Ok(()); }
        let mut payload = vec![0; length];
        stream.read_exact(&mut payload).await?;
        let data_len = length - 8;
        let data = &payload[..data_len];
        let supplied = &payload[data_len..];
        if data.len() < 7 { return Ok(()); }
        let timestamp = data[..6].iter().fold(0u64, |n, b| (n << 8) | u64::from(*b));
        let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_millis() as u64;
        let mut digest = Md5::new();
        digest.update(timestamp.to_string().as_bytes());
        digest.update(&data[6..]);
        digest.update(key.as_bytes());
        let expected = format!("{:x}", digest.finalize());
        let valid = now.abs_diff(timestamp) <= 10 * 60 * 1000 && supplied == &expected.as_bytes()[..8];
        let response = if !valid { serde_json::json!({"code":2}) } else {
            match serde_json::from_slice::<Request>(&data[6..]) {
                Ok(request) => match execute_manager_command(&redis, &ids, request).await {
                    Ok(data) => serde_json::json!({"code":0,"data":data}),
                    Err(_) => serde_json::json!({"code":-1}),
                },
                Err(_) => serde_json::json!({"code":1}),
            }
        };
        let body = serde_json::to_vec(&response).unwrap_or_else(|_| b"{\"code\":-1}".to_vec());
        stream.write_all(&(body.len() as u32).to_be_bytes()).await?;
        stream.write_all(&body).await?;
    }
}

async fn execute_manager_command(redis: &RedisConfig, ids: &Arc<RwLock<HashMap<String, String>>>, request: Request) -> Result<serde_json::Value, AuthError> {
    match request.command.as_str() {
        "list" => {
            let mut cursor = "0".to_owned();
            let mut users = Vec::new();
            loop {
                let response = redis.execute(&["SCAN".into(), cursor, "MATCH".into(), "user:*".into(), "COUNT".into(), "500".into()]).await?.array()?;
                cursor = response[0].clone().text()?;
                for key in response[1].clone().array()? {
                    let key = key.text()?;
                    if let Some(port) = key.strip_prefix("user:").and_then(|v| v.parse::<u64>().ok()) {
                        if let Some(hash) = redis.execute(&["GET".into(), key]).await?.bytes()? {
                            if let Ok(password) = String::from_utf8(hash) { users.push(serde_json::json!({"port":port,"password":password})); }
                        }
                    }
                }
                if cursor == "0" { break; }
            }
            Ok(serde_json::Value::Array(users))
        }
        "add" => {
            let port = request.port.to_string();
            let account_key = format!("user:{port}");
            let old = redis.execute(&["GET".into(), account_key.clone()]).await?.bytes()?.and_then(|v| String::from_utf8(v).ok());
            let script = "local old=redis.call('GET',KEYS[1]); if redis.call('EXISTS',ARGV[1])==1 and old~=ARGV[1] then return redis.error_reply('duplicate password') end; local v=redis.call('HMGET',old or '', 'upload','download'); redis.call('DEL',old or ''); redis.call('HSET',ARGV[1],'upload',v[1] or '0','download',v[2] or '0'); redis.call('SET',KEYS[1],ARGV[1]); return 1";
            redis.execute(&["EVAL".into(), script.into(), "1".into(), account_key, request.password.clone()]).await?;
            if let Some(old_hash) = &old { ids.write().await.remove(old_hash); }
            ids.write().await.insert(request.password.clone(), port.clone());
            Ok(serde_json::json!({"port":request.port}))
        }
        "del" => {
            let account_key = format!("user:{}", request.port);
            let hash = redis.execute(&["GET".into(), account_key.clone()]).await?.bytes()?.and_then(|v| String::from_utf8(v).ok());
            redis.execute(&["DEL".into(), account_key]).await?;
            if let Some(hash) = hash {
                redis.execute(&["DEL".into(), hash.clone()]).await?;
                ids.write().await.remove(&hash);
            }
            Ok(serde_json::json!({"port":request.port}))
        }
        "flow" => {
            let mut cursor = "0".to_owned();
            let mut flow = Vec::new();
            loop {
                let response = redis.execute(&["SCAN".into(), cursor, "MATCH".into(), "user:*".into(), "COUNT".into(), "500".into()]).await?.array()?;
                cursor = response[0].clone().text()?;
                for key in response[1].clone().array()? {
                    let key = key.text()?;
                    let Some(port) = key.strip_prefix("user:").and_then(|v| v.parse::<u64>().ok()) else { continue; };
                    let Some(hash) = redis.execute(&["GET".into(), key]).await?.bytes()?.and_then(|v| String::from_utf8(v).ok()) else { continue; };
                    let script = "local v=redis.call('HMGET',KEYS[1],'upload','download'); redis.call('HSET',KEYS[1],'upload','0','download','0'); return v";
                    let counters = redis.execute(&["EVAL".into(), script.into(), "1".into(), hash]).await?.array()?;
                    let amount = number(counters.first().cloned())?.saturating_add(number(counters.get(1).cloned())?);
                    if amount > 0 { flow.push(serde_json::json!({"port":port,"sumFlow":amount})); }
                }
                if cursor == "0" { break; }
            }
            Ok(serde_json::Value::Array(flow))
        }
        "version" => Ok(serde_json::json!({"version":"trojan-rust-ssmgr"})),
        _ => Err(AuthError::backend("unsupported ssmgr command")),
    }
}
