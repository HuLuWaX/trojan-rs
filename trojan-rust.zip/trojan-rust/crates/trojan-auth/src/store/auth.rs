//! Generic store-based authentication wrapper.
//!
//! [`StoreAuth<S>`] wraps any [`UserStore`] implementation and provides:
//! - Validation logic (enabled → expired → traffic check)
//! - Optional result caching via [`AuthCache`], with in-memory traffic deltas
//! - Stale-while-revalidate: stale cache entries are served immediately
//!   while being revalidated in the background
//! - Negative caching for invalid hashes (prevents DB flooding)
//! - Optional batched traffic recording via [`TrafficRecorder`]

use std::sync::Arc;
#[cfg(feature = "tokio-runtime")]
use std::time::Duration;
use std::time::{Instant, SystemTime, UNIX_EPOCH};

use async_trait::async_trait;

use crate::error::AuthError;
use crate::result::{AuthMetadata, AuthResult};
use crate::traits::AuthBackend;

use super::cache::{AuthCache, CacheLookup, CacheStats, CachedUser};
use super::config::{StoreAuthConfig, TrafficRecordingMode};
use super::record::UserRecord;
use super::traits::UserStore;

#[cfg(feature = "batched-traffic")]
use super::traffic::TrafficRecorder;

/// Generic authentication backend that wraps a [`UserStore`].
///
/// Provides shared validation, caching, and traffic batching logic.
/// New backends only need to implement [`UserStore`] (data access).
///
/// # Type parameter
///
/// - `S` — the underlying data store (e.g. `SqlStore`)
pub struct StoreAuth<S: UserStore> {
    store: Arc<S>,
    auth_cache: Option<Arc<AuthCache>>,
    #[cfg(feature = "batched-traffic")]
    traffic_recorder: Option<Arc<TrafficRecorder>>,
    traffic_mode: TrafficRecordingMode,
}

impl<S: UserStore> StoreAuth<S> {
    /// Create a new `StoreAuth` wrapping the given store.
    ///
    /// For backends that need batched traffic recording, use
    /// [`with_traffic_recorder`](Self::with_traffic_recorder) after construction.
    pub fn new(store: S, config: &StoreAuthConfig) -> Self {
        let auth_cache = if config.cache_enabled {
            Some(Arc::new(AuthCache::new(
                config.cache_ttl,
                config.stale_ttl,
                config.neg_cache_ttl,
            )))
        } else {
            None
        };

        Self {
            store: Arc::new(store),
            auth_cache,
            #[cfg(feature = "batched-traffic")]
            traffic_recorder: None,
            traffic_mode: config.traffic_mode,
        }
    }

    /// Attach a [`TrafficRecorder`] for batched traffic writes.
    #[cfg(feature = "batched-traffic")]
    pub fn with_traffic_recorder(mut self, recorder: TrafficRecorder) -> Self {
        self.traffic_recorder = Some(Arc::new(recorder));
        self
    }

    /// Bytes recorded for `user_id` that have not yet reached the backend.
    /// Returns 0 when batched traffic is disabled.
    #[cfg(feature = "batched-traffic")]
    fn pending_traffic_for(&self, user_id: &str) -> u64 {
        self.traffic_recorder
            .as_ref()
            .map(|r| r.pending_for(user_id))
            .unwrap_or(0)
    }

    #[cfg(not(feature = "batched-traffic"))]
    fn pending_traffic_for(&self, _user_id: &str) -> u64 {
        0
    }

    /// Get a reference to the underlying store.
    pub fn store(&self) -> &S {
        &self.store
    }

    /// Check if caching is enabled.
    pub fn cache_enabled(&self) -> bool {
        self.auth_cache.is_some()
    }

    /// Get cache statistics. Returns `None` if caching is disabled.
    pub fn cache_stats(&self) -> Option<CacheStats> {
        self.auth_cache.as_ref().map(|c| c.stats())
    }

    /// Invalidate cache entry by password hash.
    ///
    /// Also removes the hash from the negative cache so that a
    /// newly-added user is not blocked by a stale negative entry.
    pub fn cache_invalidate(&self, hash: &str) {
        if let Some(ref cache) = self.auth_cache {
            cache.remove(hash);
            cache.remove_negative(hash);
        }
    }

    /// Invalidate all cache entries for a user.
    pub fn cache_invalidate_user(&self, user_id: &str) {
        if let Some(ref cache) = self.auth_cache {
            cache.invalidate_user(user_id);
        }
    }

    /// Clear all cache entries.
    pub fn cache_clear(&self) {
        if let Some(ref cache) = self.auth_cache {
            cache.clear();
        }
    }

    /// Get current unix timestamp.
    ///
    /// Saturates rather than wrapping: a clock far enough past the epoch to
    /// overflow `i64` would otherwise wrap negative, and a negative "now"
    /// makes every `expires_at` comparison read as not-yet-expired.
    #[inline]
    fn now_unix() -> i64 {
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_or(0, |d| i64::try_from(d.as_secs()).unwrap_or(i64::MAX))
    }

    /// Validate a [`UserRecord`] against business rules.
    ///
    /// Checks: enabled → expired → traffic exceeded.
    fn validate_record(record: &UserRecord) -> Result<(), AuthError> {
        if !record.enabled {
            return Err(AuthError::Disabled);
        }

        let now = Self::now_unix();
        if record.expires_at > 0 && now >= record.expires_at {
            return Err(AuthError::Expired);
        }

        if record.traffic_limit > 0 && record.traffic_used >= record.traffic_limit {
            return Err(AuthError::TrafficExceeded);
        }

        Ok(())
    }

    /// Validate a cached entry with delta-adjusted traffic.
    ///
    /// Returns `Ok(AuthResult)` if valid, removes stale entries from cache
    /// and returns an error otherwise.
    fn validate_cached(
        cache: &AuthCache,
        hash: &str,
        cached: CachedUser,
    ) -> Result<AuthResult, AuthError> {
        let delta = cached
            .user_id
            .as_deref()
            .map(|uid| cache.get_traffic_delta(uid))
            .unwrap_or(0);

        let mut record = UserRecord::from(cached);
        record.traffic_used += delta;

        if let Err(e) = Self::validate_record(&record) {
            if matches!(e, AuthError::Expired) {
                cache.remove(hash);
            }
            return Err(e);
        }

        Ok(Self::record_to_result(&record))
    }

    /// Build an [`AuthResult`] from a validated [`UserRecord`].
    ///
    /// The record's counters are `i64` to match the DB columns, while the
    /// metadata exposes them as `u64`. Negative values clamp to 0 — the
    /// documented "unlimited"/"never expires" sentinel — instead of casting
    /// into an absurd number near `u64::MAX`.
    fn record_to_result(record: &UserRecord) -> AuthResult {
        let metadata = AuthMetadata {
            traffic_limit: u64::try_from(record.traffic_limit).unwrap_or(0),
            traffic_used: u64::try_from(record.traffic_used).unwrap_or(0),
            expires_at: u64::try_from(record.expires_at).unwrap_or(0),
            enabled: record.enabled,
            node_quotas: record.node_quotas.clone(),
        };

        AuthResult {
            user_id: record.user_id.clone(),
            metadata: Some(metadata),
        }
    }
}

/// Background revalidation for stale cache entries (requires tokio runtime).
#[cfg(feature = "tokio-runtime")]
impl<S: UserStore + 'static> StoreAuth<S> {
    /// Spawn a background task to revalidate a stale cache entry.
    fn spawn_revalidation(&self, cache: &Arc<AuthCache>, hash: &str) {
        // Single-flight: avoid spawning duplicate revalidation tasks per hash.
        if !cache.start_revalidation(hash) {
            return;
        }
        let store = Arc::clone(&self.store);
        let cache = Arc::clone(cache);
        let hash = hash.to_string();
        #[cfg(feature = "batched-traffic")]
        let recorder = self.traffic_recorder.clone();

        tokio::spawn(async move {
            match store.find_by_hash(&hash).await {
                Ok(Some(record)) => {
                    if let Some(ref uid) = record.user_id {
                        // Seed the delta with bytes already recorded but not
                        // yet flushed, so we don't briefly under-count traffic
                        // after revalidation.
                        #[cfg(feature = "batched-traffic")]
                        let pending = recorder.as_ref().map(|r| r.pending_for(uid)).unwrap_or(0);
                        #[cfg(not(feature = "batched-traffic"))]
                        let pending: u64 = 0;
                        cache.reset_traffic_delta(uid, pending);
                    }
                    // Drop any stale negative entry for this hash — without
                    // this, a hash that briefly looked invalid could stay
                    // blocked even though the user is now valid.
                    cache.remove_negative(&hash);
                    let cached_user = CachedUser {
                        user_id: record.user_id.clone(),
                        traffic_limit: record.traffic_limit,
                        traffic_used: record.traffic_used,
                        expires_at: record.expires_at,
                        enabled: record.enabled,
                        node_quotas: record.node_quotas.clone(),
                        cached_at: Instant::now(),
                    };
                    cache.insert(hash.clone(), cached_user);
                }
                Ok(None) => {
                    cache.remove(&hash);
                    cache.insert_negative(&hash);
                }
                Err(e) => {
                    // Keep the stale entry: SWR's whole point is that the
                    // local cache should ride out backend hiccups. Removing
                    // here turns a brief 5xx into a stampede the next time
                    // these hashes are queried. The entry will be retried on
                    // the next stale lookup.
                    tracing::warn!(
                        hash = %hash,
                        error = %e,
                        "background revalidation failed; keeping stale entry"
                    );
                }
            }
            cache.finish_revalidation(&hash);
        });
    }

    /// Start a background task that periodically removes expired cache entries.
    ///
    /// Call this after construction when a tokio runtime is available.
    /// Without this, expired entries are only lazily evicted on access.
    pub fn start_cache_cleanup(&self, interval: Duration) {
        if let Some(ref cache) = self.auth_cache {
            let cache = Arc::clone(cache);
            tokio::spawn(async move {
                let mut ticker = tokio::time::interval(interval);
                ticker.tick().await;
                loop {
                    ticker.tick().await;
                    cache.cleanup_expired();
                }
            });
        }
    }
}

impl<S: UserStore + 'static> StoreAuth<S> {
    fn cached_result(&self, hash: &str, count: bool) -> Option<Result<AuthResult, AuthError>> {
        if let Some(ref cache) = self.auth_cache {
            // 1. Negative cache — reject known-invalid hashes without store query
            if cache.is_negative(hash) {
                return Some(Err(AuthError::Invalid));
            }

            // 2. Cache lookup with stale-while-revalidate support
            match if count {
                cache.lookup(hash)
            } else {
                cache.peek(hash)
            } {
                CacheLookup::Fresh(cached) => {
                    return Some(Self::validate_cached(cache, hash, cached));
                }
                CacheLookup::Stale(cached) => {
                    let result = Self::validate_cached(cache, hash, cached);
                    // Spawn background revalidation for stale hits, including
                    // validation failures (e.g. disabled/traffic exceeded), so
                    // cache state can recover quickly when backend state changes.
                    #[cfg(feature = "tokio-runtime")]
                    self.spawn_revalidation(cache, hash);
                    return Some(result);
                }
                CacheLookup::Miss => { /* fall through to store query */ }
            }
        }
        None
    }

    async fn query_store(&self, hash: &str) -> Result<AuthResult, AuthError> {
        let record = match self.store.find_by_hash(hash).await? {
            Some(record) => record,
            None => {
                // Insert into negative cache
                if let Some(ref cache) = self.auth_cache {
                    cache.insert_negative(hash);
                }
                return Err(AuthError::Invalid);
            }
        };

        // Validate business rules
        Self::validate_record(&record)?;

        // Cache successful result and reseed traffic delta with bytes still
        // in the recorder pipeline (queued, pending, and in-flight).
        if let Some(ref cache) = self.auth_cache {
            if let Some(ref uid) = record.user_id {
                let pending = self.pending_traffic_for(uid);
                cache.reset_traffic_delta(uid, pending);
            }
            // Drop any stale negative entry — a user that just transitioned
            // from "not found" to "found" should not stay blocked by it.
            cache.remove_negative(hash);
            let cached_user = CachedUser {
                user_id: record.user_id.clone(),
                traffic_limit: record.traffic_limit,
                traffic_used: record.traffic_used,
                expires_at: record.expires_at,
                enabled: record.enabled,
                node_quotas: record.node_quotas.clone(),
                cached_at: Instant::now(),
            };
            cache.insert(hash.to_string(), cached_user);
        }

        Ok(Self::record_to_result(&record))
    }
}

#[async_trait]
impl<S: UserStore + 'static> AuthBackend for StoreAuth<S> {
    async fn verify(&self, hash: &str) -> Result<AuthResult, AuthError> {
        if let Some(result) = self.cached_result(hash, true) {
            return result;
        }
        #[cfg(feature = "tokio-runtime")]
        if let Some(cache) = &self.auth_cache {
            let query = cache.query_lock(hash);
            let _guard = query.lock().await;
            // A caller ahead of us may have populated either cache while we waited.
            if let Some(result) = self.cached_result(hash, false) {
                return result;
            }
            return self.query_store(hash).await;
        }
        self.query_store(hash).await
    }

    async fn record_traffic(&self, user_id: &str, bytes: u64) -> Result<(), AuthError> {
        #[cfg(feature = "batched-traffic")]
        if self.traffic_mode == TrafficRecordingMode::Batched
            && let Some(ref recorder) = self.traffic_recorder
        {
            recorder.record(user_id.to_string(), bytes).await?;
        }
        // Update in-memory traffic delta so cache hits reflect accumulated traffic
        if let Some(ref cache) = self.auth_cache {
            cache.add_traffic_delta(user_id, bytes);
        }

        // Persist to backend
        match self.traffic_mode {
            TrafficRecordingMode::Immediate => self.store.add_traffic(user_id, bytes).await,
            TrafficRecordingMode::Batched | TrafficRecordingMode::Disabled => Ok(()),
        }
    }

    async fn shutdown(&self) {
        #[cfg(feature = "batched-traffic")]
        if let Some(ref recorder) = self.traffic_recorder {
            recorder.shutdown().await;
        }
    }
}

impl<S: UserStore + std::fmt::Debug> std::fmt::Debug for StoreAuth<S> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("StoreAuth")
            .field("store", &self.store)
            .field("traffic_mode", &self.traffic_mode)
            .field("cache_enabled", &self.auth_cache.is_some())
            .finish_non_exhaustive()
    }
}

#[cfg(test)]
mod tests {
    use super::{StoreAuth, UserRecord, UserStore};
    use crate::AuthError;

    #[cfg(feature = "tokio-runtime")]
    #[tokio::test]
    async fn cold_queries_share_cached_results_without_serializing_other_hashes() {
        use crate::{AuthBackend, store::StoreAuthConfig};
        use std::sync::{
            Arc,
            atomic::{AtomicUsize, Ordering},
        };
        use std::time::Duration;

        struct GatedStore {
            calls: AtomicUsize,
            started: tokio::sync::mpsc::Sender<String>,
            gate: tokio::sync::Semaphore,
        }
        #[async_trait::async_trait]
        impl UserStore for GatedStore {
            async fn find_by_hash(&self, hash: &str) -> Result<Option<UserRecord>, AuthError> {
                self.calls.fetch_add(1, Ordering::SeqCst);
                self.started.send(hash.to_owned()).await.unwrap();
                self.gate.acquire().await.unwrap().forget();
                Ok((hash != "missing").then(|| UserRecord {
                    user_id: Some(hash.to_owned()),
                    enabled: true,
                    traffic_limit: 0,
                    traffic_used: 0,
                    expires_at: 0,
                    node_quotas: Vec::new(),
                }))
            }
            async fn add_traffic(&self, _user_id: &str, _bytes: u64) -> Result<(), AuthError> {
                unreachable!()
            }
        }
        let (started, mut queries) = tokio::sync::mpsc::channel(64);
        let auth = Arc::new(StoreAuth::new(
            GatedStore {
                calls: AtomicUsize::new(0),
                started,
                gate: tokio::sync::Semaphore::new(0),
            },
            &StoreAuthConfig {
                cache_enabled: true,
                ..Default::default()
            },
        ));
        let mut tasks = tokio::task::JoinSet::new();
        for hash in ["alice", "missing"] {
            for _ in 0..32 {
                let auth = auth.clone();
                tasks.spawn(async move { (hash, auth.verify(hash).await) });
            }
        }
        let mut started = Vec::new();
        for _ in 0..2 {
            started.push(
                tokio::time::timeout(Duration::from_secs(5), queries.recv())
                    .await
                    .unwrap()
                    .unwrap(),
            );
        }
        started.sort();
        assert_eq!(started, ["alice", "missing"]);
        auth.store.gate.add_permits(2);
        tokio::time::timeout(Duration::from_secs(5), async {
            while let Some(result) = tasks.join_next().await {
                let (hash, result) = result.unwrap();
                if hash == "missing" {
                    assert!(matches!(result, Err(AuthError::Invalid)));
                } else {
                    assert_eq!(result.unwrap().user_id.as_deref(), Some(hash));
                }
            }
        })
        .await
        .unwrap();
        assert_eq!(auth.store.calls.load(Ordering::SeqCst), 2);

        let pending = {
            let auth = auth.clone();
            tokio::spawn(async move { auth.verify("cancelled").await })
        };
        assert_eq!(queries.recv().await.unwrap(), "cancelled");
        pending.abort();
        assert!(pending.await.unwrap_err().is_cancelled());
        auth.store.gate.add_permits(1);
        let result = tokio::time::timeout(Duration::from_secs(5), auth.verify("cancelled"))
            .await
            .unwrap()
            .unwrap();
        assert_eq!(result.user_id.as_deref(), Some("cancelled"));
    }

    #[derive(Debug)]
    struct UnusedStore;

    #[async_trait::async_trait]
    impl UserStore for UnusedStore {
        async fn find_by_hash(&self, _hash: &str) -> Result<Option<UserRecord>, AuthError> {
            unreachable!("record_to_result does not touch the store")
        }
        async fn add_traffic(&self, _user_id: &str, _bytes: u64) -> Result<(), AuthError> {
            unreachable!("record_to_result does not touch the store")
        }
    }

    /// A panel that writes -1 for "unlimited" used to surface as a limit of
    /// `u64::MAX` bytes; it must read as the documented 0 sentinel instead.
    #[test]
    fn negative_counters_clamp_to_the_zero_sentinel() {
        let record = UserRecord {
            node_quotas: Vec::new(),
            user_id: Some("u1".to_owned()),
            traffic_limit: -1,
            traffic_used: -1,
            expires_at: -1,
            enabled: true,
        };

        let meta = StoreAuth::<UnusedStore>::record_to_result(&record)
            .metadata
            .expect("record_to_result always attaches metadata");

        assert_eq!(meta.traffic_limit, 0);
        assert_eq!(meta.traffic_used, 0);
        assert_eq!(meta.expires_at, 0);
    }

    #[test]
    fn non_negative_counters_pass_through() {
        let record = UserRecord {
            node_quotas: Vec::new(),
            user_id: Some("u1".to_owned()),
            traffic_limit: 1024,
            traffic_used: 512,
            expires_at: 1_700_000_000,
            enabled: true,
        };

        let meta = StoreAuth::<UnusedStore>::record_to_result(&record)
            .metadata
            .expect("record_to_result always attaches metadata");

        assert_eq!(meta.traffic_limit, 1024);
        assert_eq!(meta.traffic_used, 512);
        assert_eq!(meta.expires_at, 1_700_000_000);
    }
}
