//! Integration tests for trojan-server.
//!
//! These tests verify the complete server flow including:
//! - TLS handshake
//! - Trojan protocol parsing
//! - Authentication
//! - CONNECT relay
//! - Fallback behavior
#![expect(
    clippy::tests_outside_test_module,
    reason = "integration tests are their own crate, where every #[test] is \
              necessarily a free item; the lint targets unit tests that \
              escaped a #[cfg(test)] mod"
)]

use std::{
    fs,
    io::{Read, Write},
    net::{SocketAddr, TcpListener},
    sync::Arc,
    thread,
    time::Duration,
};

use bytes::BytesMut;
use rustls::{
    ClientConfig, RootCertStore,
    pki_types::{CertificateDer, ServerName},
};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio_rustls::TlsConnector;
use trojan_auth::{MemoryAuth, sha224_hex};
use trojan_config::{
    AuthConfig, Config, LoggingConfig, MetricsConfig, ServerConfig, TcpConfig, TlsConfig,
    TlsVersion, WebSocketConfig,
};
use trojan_proto::{
    AddressRef, CMD_CONNECT, CMD_UDP_ASSOCIATE, HostRef, write_request_header, write_udp_packet,
};

// ============================================================================
// Crypto Provider Setup
// ============================================================================

/// Install the aws-lc-rs crypto provider once at process startup.
///
/// When the `rules` feature is enabled, `reqwest`'s `rustls-tls` pulls in the
/// `ring` provider alongside `aws-lc-rs`, preventing rustls from auto-detecting
/// which one to use.
#[ctor::ctor]
fn init_crypto() {
    rustls::crypto::aws_lc_rs::default_provider()
        .install_default()
        .expect("Failed to install aws-lc-rs crypto provider");
}

// ============================================================================
// Test Certificates (self-signed for testing)
// ============================================================================

/// Generate a self-signed certificate for testing.
/// Returns (cert_pem, key_pem).
fn generate_test_certs() -> (String, String) {
    use rcgen::{CertificateParams, KeyPair, PKCS_ECDSA_P256_SHA256};

    // Use ECDSA P-256 for cross-platform compatibility with aws-lc-rs
    let key_pair = KeyPair::generate_for(&PKCS_ECDSA_P256_SHA256).unwrap();
    let mut params = CertificateParams::default();
    params.subject_alt_names = vec![
        rcgen::SanType::DnsName("localhost".try_into().unwrap()),
        rcgen::SanType::IpAddress(std::net::IpAddr::V4(std::net::Ipv4Addr::new(127, 0, 0, 1))),
    ];
    let cert = params.self_signed(&key_pair).unwrap();

    (cert.pem(), key_pair.serialize_pem())
}

// ============================================================================
// Test Helper: Mock Echo Server
// ============================================================================

/// A simple TCP server that echoes back whatever it receives.
struct MockEchoServer {
    addr: SocketAddr,
    _handle: thread::JoinHandle<()>,
}

impl MockEchoServer {
    fn start() -> Self {
        Self::start_on("127.0.0.1:0")
    }

    fn start_on<A: std::net::ToSocketAddrs>(bind: A) -> Self {
        let listener = TcpListener::bind(bind).unwrap();
        let addr = listener.local_addr().unwrap();

        let handle = thread::spawn(move || {
            for mut stream in listener.incoming().flatten() {
                thread::spawn(move || {
                    let mut buf = [0u8; 4096];
                    loop {
                        match stream.read(&mut buf) {
                            Ok(0) => break,
                            Ok(n) => {
                                if stream.write_all(&buf[..n]).is_err() {
                                    break;
                                }
                            }
                            Err(_) => break,
                        }
                    }
                });
            }
        });

        Self {
            addr,
            _handle: handle,
        }
    }
}

/// A simple TCP server that responds with a fixed message.
struct MockHttpServer {
    addr: SocketAddr,
    _handle: thread::JoinHandle<()>,
}

impl MockHttpServer {
    fn start(response: &'static str) -> Self {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap();

        let handle = thread::spawn(move || {
            for mut stream in listener.incoming().flatten() {
                let response = response.to_string();
                thread::spawn(move || {
                    let mut buf = [0u8; 4096];
                    // Read request (we don't care about it)
                    let _ = stream.read(&mut buf);
                    // Send response
                    let _ = stream.write_all(response.as_bytes());
                    // Shutdown write side to signal end of response
                    let _ = stream.shutdown(std::net::Shutdown::Write);
                });
            }
        });

        Self {
            addr,
            _handle: handle,
        }
    }
}

// ============================================================================
// Test Helper: Trojan Server
// ============================================================================

struct TestServer {
    addr: SocketAddr,
    password: String,
    tls_connector: TlsConnector,
    _temp_dir: tempfile::TempDir,
}

impl TestServer {
    async fn start(fallback_addr: SocketAddr) -> Self {
        use trojan_auth::MemoryAuth;
        use trojan_config::{
            AuthConfig, Config, LoggingConfig, MetricsConfig, ServerConfig, TlsConfig, TlsVersion,
        };

        let password = "test_password_123".to_string();
        let (cert_pem, key_pem) = generate_test_certs();

        // Write certs to a unique temp directory to avoid collisions in parallel tests.
        let temp_dir = tempfile::Builder::new()
            .prefix("trojan-test-")
            .tempdir()
            .unwrap();
        let cert_path = temp_dir.path().join("cert.pem");
        let key_path = temp_dir.path().join("key.pem");

        fs::write(&cert_path, &cert_pem).unwrap();
        fs::write(&key_path, &key_pem).unwrap();

        // Parse cert for client verification
        let cert_der = rustls_pemfile::certs(&mut cert_pem.as_bytes())
            .next()
            .unwrap()
            .unwrap()
            .to_vec();

        // Build TLS connector for client
        let mut root_store = RootCertStore::empty();
        root_store.add(CertificateDer::from(cert_der)).unwrap();
        let client_config = ClientConfig::builder()
            .with_root_certificates(root_store)
            .with_no_client_auth();
        let tls_connector = TlsConnector::from(Arc::new(client_config));

        // Find available port
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        drop(listener);

        let config = Config {
            server: ServerConfig {
                listen: addr.to_string(),
                fallback: fallback_addr.to_string(),
                tcp_idle_timeout_secs: 30,
                udp_timeout_secs: 30,
                max_udp_payload: 8192,
                max_udp_buffer_bytes: 65536,
                max_header_bytes: 8192,
                max_connections: None,
                rate_limit: None,
                fallback_pool: None,
                resource_limits: None,
                tcp: TcpConfig::default(),
                outbounds: Default::default(),
                rule_providers: Default::default(),
                rules: Default::default(),
                geoip: None,
                proxy_protocol: Default::default(),
            },
            tls: TlsConfig {
                cert: cert_path.to_string_lossy().to_string(),
                key: key_path.to_string_lossy().to_string(),
                alpn: vec![],
                min_version: TlsVersion::Tls12,
                max_version: TlsVersion::Tls13,
                client_ca: None,
                cipher_suites: vec![],
            },
            auth: AuthConfig {
                passwords: vec![password.clone()],
                users: vec![],
                ..Default::default()
            },
            websocket: WebSocketConfig::default(),
            metrics: MetricsConfig {
                listen: None,
                ..Default::default()
            },
            analytics: Default::default(),
            logging: LoggingConfig {
                level: Some("warn".to_string()),
                ..Default::default()
            },
            dns: Default::default(),
            ddns: Default::default(),
        };

        let auth = MemoryAuth::from_passwords(&config.auth.passwords);

        // Spawn server in background
        let config_clone = config.clone();
        tokio::spawn(async move {
            let _ = trojan_server::run(config_clone, auth).await;
        });

        // Wait for server to start (longer on Windows CI)
        tokio::time::sleep(Duration::from_millis(500)).await;

        Self {
            addr,
            password,
            tls_connector,
            _temp_dir: temp_dir,
        }
    }

    fn hash(&self) -> String {
        sha224_hex(&self.password)
    }
}

// ============================================================================
// Tests
// ============================================================================

/// Test that valid Trojan authentication succeeds and CONNECT relay works.
#[tokio::test]
async fn test_connect_relay() {
    // Start echo server (target)
    let echo_server = MockEchoServer::start();

    // Start fallback server
    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

    // Start trojan server
    let server = TestServer::start(fallback.addr).await;

    // Connect via TLS
    let tcp_stream = tokio::net::TcpStream::connect(server.addr).await.unwrap();
    let server_name = ServerName::try_from("localhost").unwrap();
    let mut tls_stream = server
        .tls_connector
        .connect(server_name, tcp_stream)
        .await
        .unwrap();

    // Build Trojan request header
    let hash = server.hash();
    let ip_addr: std::net::Ipv4Addr = match echo_server.addr.ip() {
        std::net::IpAddr::V4(v4) => v4,
        _ => panic!("Expected IPv4 address"),
    };
    let target_addr = AddressRef {
        host: HostRef::Ipv4(ip_addr.octets()),
        port: echo_server.addr.port(),
    };

    let mut header = BytesMut::new();
    write_request_header(&mut header, hash.as_bytes(), CMD_CONNECT, &target_addr).unwrap();
    header.extend_from_slice(b"Hello, Trojan!");

    // Send request
    tls_stream.write_all(&header).await.unwrap();
    tls_stream.flush().await.unwrap();

    // Read response (echo server should echo back)
    let mut response = vec![0u8; 1024];
    let n = tokio::time::timeout(Duration::from_secs(5), tls_stream.read(&mut response))
        .await
        .expect("read timeout")
        .unwrap();

    assert_eq!(&response[..n], b"Hello, Trojan!");
}

/// Test that invalid password triggers fallback.
#[tokio::test]
async fn test_fallback_on_invalid_password() {
    // Start fallback server with recognizable response
    let fallback = MockHttpServer::start("FALLBACK_RESPONSE");

    // Start trojan server
    let server = TestServer::start(fallback.addr).await;

    // Connect via TLS
    let tcp_stream = tokio::net::TcpStream::connect(server.addr).await.unwrap();
    let server_name = ServerName::try_from("localhost").unwrap();
    let mut tls_stream = server
        .tls_connector
        .connect(server_name, tcp_stream)
        .await
        .unwrap();

    // Build Trojan request with WRONG password
    let wrong_hash = sha224_hex("wrong_password");
    let target_addr = AddressRef {
        host: HostRef::Ipv4([127, 0, 0, 1]),
        port: 80,
    };

    let mut header = BytesMut::new();
    write_request_header(
        &mut header,
        wrong_hash.as_bytes(),
        CMD_CONNECT,
        &target_addr,
    )
    .unwrap();

    // Send request
    tls_stream.write_all(&header).await.unwrap();
    tls_stream.flush().await.unwrap();

    // Read response (should get fallback response)
    let mut response = vec![0u8; 1024];
    let n = tokio::time::timeout(Duration::from_secs(5), tls_stream.read(&mut response))
        .await
        .expect("read timeout")
        .unwrap();

    assert!(String::from_utf8_lossy(&response[..n]).contains("FALLBACK"));
}

/// Test that non-Trojan traffic (e.g., plain HTTP) triggers fallback.
#[tokio::test]
async fn test_fallback_on_non_trojan_traffic() {
    // Start fallback server
    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback OK");

    // Start trojan server
    let server = TestServer::start(fallback.addr).await;

    // Connect via TLS
    let tcp_stream = tokio::net::TcpStream::connect(server.addr).await.unwrap();
    let server_name = ServerName::try_from("localhost").unwrap();
    let mut tls_stream = server
        .tls_connector
        .connect(server_name, tcp_stream)
        .await
        .unwrap();

    // Send plain HTTP request (not Trojan protocol)
    // Must be at least 56 bytes for server to detect invalid hash format
    let http_request =
        b"GET /this-is-a-long-path-to-make-the-request-longer HTTP/1.1\r\nHost: localhost\r\n\r\n";
    tls_stream.write_all(http_request).await.unwrap();
    tls_stream.flush().await.unwrap();

    // Read response (should get fallback HTTP response)
    let mut response = vec![0u8; 1024];
    let n = tokio::time::timeout(Duration::from_secs(5), tls_stream.read(&mut response))
        .await
        .expect("read timeout")
        .unwrap();

    let response_str = String::from_utf8_lossy(&response[..n]);
    assert!(response_str.contains("200 OK") || response_str.contains("Fallback"));
}

/// Test graceful shutdown: server stops accepting new connections and waits for existing ones.
#[tokio::test]
async fn test_graceful_shutdown() {
    use trojan_auth::MemoryAuth;
    use trojan_config::{
        AuthConfig, Config, LoggingConfig, MetricsConfig, ServerConfig, TlsConfig, TlsVersion,
    };
    use trojan_server::{CancellationToken, run_with_shutdown};

    let password = "test_password_123".to_string();
    let (cert_pem, key_pem) = generate_test_certs();

    let temp_dir = std::env::temp_dir().join(format!(
        "trojan-shutdown-test-{}",
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));
    fs::create_dir_all(&temp_dir).unwrap();

    let cert_path = temp_dir.join("cert.pem");
    let key_path = temp_dir.join("key.pem");
    fs::write(&cert_path, &cert_pem).unwrap();
    fs::write(&key_path, &key_pem).unwrap();

    // Parse cert for client
    let cert_der = rustls_pemfile::certs(&mut cert_pem.as_bytes())
        .next()
        .unwrap()
        .unwrap()
        .to_vec();
    let mut root_store = RootCertStore::empty();
    root_store.add(CertificateDer::from(cert_der)).unwrap();
    let client_config = ClientConfig::builder()
        .with_root_certificates(root_store)
        .with_no_client_auth();
    let tls_connector = TlsConnector::from(Arc::new(client_config));

    // Start fallback and echo servers
    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
    let echo_server = MockEchoServer::start();

    // Find available port
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let addr = listener.local_addr().unwrap();
    drop(listener);

    let config = Config {
        server: ServerConfig {
            listen: addr.to_string(),
            fallback: fallback.addr.to_string(),
            tcp_idle_timeout_secs: 30,
            udp_timeout_secs: 30,
            max_udp_payload: 8192,
            max_udp_buffer_bytes: 65536,
            max_header_bytes: 8192,
            max_connections: None,
            rate_limit: None,
            fallback_pool: None,
            resource_limits: None,
            tcp: TcpConfig::default(),
            outbounds: Default::default(),
            rule_providers: Default::default(),
            rules: Default::default(),
            geoip: None,
            proxy_protocol: Default::default(),
        },
        tls: TlsConfig {
            cert: cert_path.to_string_lossy().to_string(),
            key: key_path.to_string_lossy().to_string(),
            alpn: vec![],
            min_version: TlsVersion::Tls12,
            max_version: TlsVersion::Tls13,
            client_ca: None,
            cipher_suites: vec![],
        },
        auth: AuthConfig {
            passwords: vec![password.clone()],
            users: vec![],
            ..Default::default()
        },
        websocket: WebSocketConfig::default(),
        metrics: MetricsConfig {
            listen: None,
            ..Default::default()
        },
        analytics: Default::default(),
        logging: LoggingConfig {
            level: Some("warn".to_string()),
            ..Default::default()
        },
        dns: Default::default(),
        ddns: Default::default(),
    };

    let auth = MemoryAuth::from_passwords(&config.auth.passwords);
    let shutdown = CancellationToken::new();
    let shutdown_trigger = shutdown.clone();

    // Spawn server with shutdown token
    let server_handle =
        tokio::spawn(async move { run_with_shutdown(config, auth, shutdown).await });

    // Wait for server to start
    tokio::time::sleep(Duration::from_millis(500)).await;

    // Establish a connection before shutdown
    let tcp_stream = tokio::net::TcpStream::connect(addr).await.unwrap();
    let server_name = ServerName::try_from("localhost").unwrap();
    let mut tls_stream = tls_connector
        .connect(server_name, tcp_stream)
        .await
        .unwrap();

    // Send a trojan request to establish relay
    let hash = sha224_hex(&password);
    let ip_addr: std::net::Ipv4Addr = match echo_server.addr.ip() {
        std::net::IpAddr::V4(v4) => v4,
        _ => panic!("Expected IPv4 address"),
    };
    let target_addr = AddressRef {
        host: HostRef::Ipv4(ip_addr.octets()),
        port: echo_server.addr.port(),
    };
    let mut header = BytesMut::new();
    write_request_header(&mut header, hash.as_bytes(), CMD_CONNECT, &target_addr).unwrap();
    tls_stream.write_all(&header).await.unwrap();

    // Trigger shutdown
    shutdown_trigger.cancel();

    // Try to connect after shutdown signal - should fail eventually
    tokio::time::sleep(Duration::from_millis(100)).await;
    let connect_result =
        tokio::time::timeout(Duration::from_secs(1), tokio::net::TcpStream::connect(addr)).await;
    // Connection might succeed if quick enough, but server won't accept more after loop exits
    // The key test is that server eventually stops

    // The existing connection should still work (drain period)
    let message = b"Hello during shutdown!";
    tls_stream.write_all(message).await.unwrap();
    tls_stream.flush().await.unwrap();

    let mut response = vec![0u8; 1024];
    let n = tokio::time::timeout(Duration::from_secs(5), tls_stream.read(&mut response))
        .await
        .expect("read timeout during shutdown drain")
        .unwrap();
    assert_eq!(
        &response[..n],
        message,
        "existing connection should continue working"
    );

    // Close the connection
    drop(tls_stream);

    // Wait for server to stop
    let result = tokio::time::timeout(Duration::from_secs(5), server_handle)
        .await
        .expect("server should stop within timeout");

    assert!(result.is_ok(), "server should exit cleanly");
    let _ = connect_result; // silence unused warning
}

/// Test that max_connections limits concurrent connections.
#[tokio::test]
async fn test_max_connections_limit() {
    use trojan_auth::MemoryAuth;
    use trojan_config::{
        AuthConfig, Config, LoggingConfig, MetricsConfig, ServerConfig, TlsConfig, TlsVersion,
    };
    use trojan_server::{CancellationToken, run_with_shutdown};

    let password = "test_password_123".to_string();
    let (cert_pem, key_pem) = generate_test_certs();

    let temp_dir = std::env::temp_dir().join(format!(
        "trojan-maxconn-test-{}",
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));
    fs::create_dir_all(&temp_dir).unwrap();

    let cert_path = temp_dir.join("cert.pem");
    let key_path = temp_dir.join("key.pem");
    fs::write(&cert_path, &cert_pem).unwrap();
    fs::write(&key_path, &key_pem).unwrap();

    // Parse cert for client
    let cert_der = rustls_pemfile::certs(&mut cert_pem.as_bytes())
        .next()
        .unwrap()
        .unwrap()
        .to_vec();
    let mut root_store = RootCertStore::empty();
    root_store.add(CertificateDer::from(cert_der)).unwrap();
    let client_config = ClientConfig::builder()
        .with_root_certificates(root_store)
        .with_no_client_auth();
    let tls_connector = TlsConnector::from(Arc::new(client_config));

    // Start fallback
    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

    // Find available port
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let addr = listener.local_addr().unwrap();
    drop(listener);

    // Configure with max_connections = 2
    let config = Config {
        server: ServerConfig {
            listen: addr.to_string(),
            fallback: fallback.addr.to_string(),
            tcp_idle_timeout_secs: 30,
            udp_timeout_secs: 30,
            max_udp_payload: 8192,
            max_udp_buffer_bytes: 65536,
            max_header_bytes: 8192,
            max_connections: Some(2),
            rate_limit: None,
            fallback_pool: None,
            resource_limits: None,
            tcp: TcpConfig::default(),
            outbounds: Default::default(),
            rule_providers: Default::default(),
            rules: Default::default(),
            geoip: None,
            proxy_protocol: Default::default(),
        },
        tls: TlsConfig {
            cert: cert_path.to_string_lossy().to_string(),
            key: key_path.to_string_lossy().to_string(),
            alpn: vec![],
            min_version: TlsVersion::Tls12,
            max_version: TlsVersion::Tls13,
            client_ca: None,
            cipher_suites: vec![],
        },
        auth: AuthConfig {
            passwords: vec![password.clone()],
            users: vec![],
            ..Default::default()
        },
        websocket: WebSocketConfig::default(),
        metrics: MetricsConfig {
            listen: None,
            ..Default::default()
        },
        analytics: Default::default(),
        logging: LoggingConfig {
            level: Some("warn".to_string()),
            ..Default::default()
        },
        dns: Default::default(),
        ddns: Default::default(),
    };

    let auth = MemoryAuth::from_passwords(&config.auth.passwords);
    let shutdown = CancellationToken::new();
    let shutdown_trigger = shutdown.clone();

    // Spawn server
    let _server_handle =
        tokio::spawn(async move { run_with_shutdown(config, auth, shutdown).await });

    // Wait for server to start
    tokio::time::sleep(Duration::from_millis(500)).await;

    // Establish 2 connections (should succeed)
    let conn1 = tokio::net::TcpStream::connect(addr).await.unwrap();
    let server_name = ServerName::try_from("localhost").unwrap();
    let tls1 = tls_connector
        .connect(server_name.clone(), conn1)
        .await
        .unwrap();

    let conn2 = tokio::net::TcpStream::connect(addr).await.unwrap();
    let tls2 = tls_connector
        .connect(server_name.clone(), conn2)
        .await
        .unwrap();

    // Give server time to register the connections
    tokio::time::sleep(Duration::from_millis(100)).await;

    // Third connection should be rejected (connection closed immediately)
    let conn3_result = tokio::net::TcpStream::connect(addr).await;
    if let Ok(conn3) = conn3_result {
        // Server accepted TCP but should close it before TLS handshake
        let tls3_result = tokio::time::timeout(
            Duration::from_secs(2),
            tls_connector.connect(server_name.clone(), conn3),
        )
        .await;
        // Either timeout or TLS error is expected
        assert!(
            tls3_result.is_err() || tls3_result.unwrap().is_err(),
            "third connection should fail"
        );
    }

    // Drop one connection
    drop(tls1);
    tokio::time::sleep(Duration::from_millis(100)).await;

    // Now a new connection should succeed
    let conn4 = tokio::net::TcpStream::connect(addr).await.unwrap();
    let tls4_result = tokio::time::timeout(
        Duration::from_secs(2),
        tls_connector.connect(server_name.clone(), conn4),
    )
    .await;
    assert!(
        tls4_result.is_ok() && tls4_result.unwrap().is_ok(),
        "fourth connection should succeed after one was closed"
    );

    // Cleanup
    drop(tls2);
    shutdown_trigger.cancel();
}

/// Test that rate limiting rejects connections when limit is exceeded.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_rate_limiting() {
    use trojan_auth::MemoryAuth;
    use trojan_config::{
        AuthConfig, Config, LoggingConfig, MetricsConfig, RateLimitConfig, ServerConfig, TlsConfig,
        TlsVersion,
    };
    use trojan_server::CancellationToken;

    let password = "test_password_123".to_string();
    let (cert_pem, key_pem) = generate_test_certs();

    let temp_dir = std::env::temp_dir().join(format!("trojan_test_rl_{}", std::process::id()));
    std::fs::create_dir_all(&temp_dir).unwrap();
    let cert_path = temp_dir.join("cert.pem");
    let key_path = temp_dir.join("key.pem");
    fs::write(&cert_path, &cert_pem).unwrap();
    fs::write(&key_path, &key_pem).unwrap();

    let cert_der = rustls_pemfile::certs(&mut cert_pem.as_bytes())
        .next()
        .unwrap()
        .unwrap()
        .to_vec();
    let mut root_store = RootCertStore::empty();
    root_store.add(CertificateDer::from(cert_der)).unwrap();
    let client_config = ClientConfig::builder()
        .with_root_certificates(root_store)
        .with_no_client_auth();
    let tls_connector = TlsConnector::from(Arc::new(client_config));

    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let addr = listener.local_addr().unwrap();
    drop(listener);

    // Configure rate limit: 2 connections per 60 seconds
    let config = Config {
        server: ServerConfig {
            listen: addr.to_string(),
            fallback: fallback.addr.to_string(),
            tcp_idle_timeout_secs: 30,
            udp_timeout_secs: 30,
            max_udp_payload: 8192,
            max_udp_buffer_bytes: 65536,
            max_header_bytes: 8192,
            max_connections: None,
            rate_limit: Some(RateLimitConfig {
                max_connections_per_ip: 2,
                window_secs: 60,
                cleanup_interval_secs: 300,
            }),
            fallback_pool: None,
            resource_limits: None,
            tcp: TcpConfig::default(),
            outbounds: Default::default(),
            rule_providers: Default::default(),
            rules: Default::default(),
            geoip: None,
            proxy_protocol: Default::default(),
        },
        tls: TlsConfig {
            cert: cert_path.to_string_lossy().to_string(),
            key: key_path.to_string_lossy().to_string(),
            alpn: vec![],
            min_version: TlsVersion::Tls12,
            max_version: TlsVersion::Tls13,
            client_ca: None,
            cipher_suites: vec![],
        },
        auth: AuthConfig {
            passwords: vec![password.clone()],
            users: vec![],
            ..Default::default()
        },
        websocket: WebSocketConfig::default(),
        metrics: MetricsConfig {
            listen: None,
            ..Default::default()
        },
        analytics: Default::default(),
        logging: LoggingConfig {
            level: Some("warn".to_string()),
            ..Default::default()
        },
        dns: Default::default(),
        ddns: Default::default(),
    };

    let auth = MemoryAuth::from_passwords(&config.auth.passwords);
    let shutdown_trigger = CancellationToken::new();
    let shutdown = shutdown_trigger.clone();
    let server_config = config.clone();

    tokio::spawn(async move {
        let _ = trojan_server::run_with_shutdown(server_config, auth, shutdown).await;
    });

    tokio::time::sleep(Duration::from_millis(100)).await;

    let server_name: ServerName<'_> = ServerName::try_from("localhost").unwrap();

    // First two connections should succeed
    let conn1 = tokio::net::TcpStream::connect(addr).await.unwrap();
    let tls1 = tls_connector
        .connect(server_name.clone(), conn1)
        .await
        .unwrap();

    let conn2 = tokio::net::TcpStream::connect(addr).await.unwrap();
    let tls2 = tls_connector
        .connect(server_name.clone(), conn2)
        .await
        .unwrap();

    // Third connection should be rate limited (connection refused or reset)
    let conn3_result = tokio::net::TcpStream::connect(addr).await;
    if let Ok(conn3) = conn3_result {
        // Connection might be accepted but then closed immediately
        let tls3_result = tokio::time::timeout(
            Duration::from_secs(2),
            tls_connector.connect(server_name.clone(), conn3),
        )
        .await;
        // Either timeout or TLS error is expected
        assert!(
            tls3_result.is_err() || tls3_result.unwrap().is_err(),
            "third connection should fail due to rate limiting"
        );
    }
    // If connect itself fails, that's also expected

    // Cleanup
    drop(tls1);
    drop(tls2);
    shutdown_trigger.cancel();
    let _ = fs::remove_dir_all(&temp_dir);
}

/// Test TLS 1.3 only mode works correctly.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_tls13_only() {
    use trojan_auth::MemoryAuth;
    use trojan_config::{
        AuthConfig, Config, LoggingConfig, MetricsConfig, ServerConfig, TlsConfig, TlsVersion,
        WebSocketConfig,
    };
    use trojan_server::CancellationToken;

    let password = "test_password_123".to_string();
    let (cert_pem, key_pem) = generate_test_certs();

    let temp_dir = std::env::temp_dir().join(format!("trojan_test_tls13_{}", std::process::id()));
    std::fs::create_dir_all(&temp_dir).unwrap();
    let cert_path = temp_dir.join("cert.pem");
    let key_path = temp_dir.join("key.pem");
    fs::write(&cert_path, &cert_pem).unwrap();
    fs::write(&key_path, &key_pem).unwrap();

    let cert_der = rustls_pemfile::certs(&mut cert_pem.as_bytes())
        .next()
        .unwrap()
        .unwrap()
        .to_vec();
    let mut root_store = RootCertStore::empty();
    root_store.add(CertificateDer::from(cert_der)).unwrap();

    // Configure client for TLS 1.3 only
    let client_config = ClientConfig::builder()
        .with_root_certificates(root_store)
        .with_no_client_auth();
    let tls_connector = TlsConnector::from(Arc::new(client_config));

    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let addr = listener.local_addr().unwrap();
    drop(listener);

    // Server configured for TLS 1.3 only
    let config = Config {
        server: ServerConfig {
            listen: addr.to_string(),
            fallback: fallback.addr.to_string(),
            tcp_idle_timeout_secs: 30,
            udp_timeout_secs: 30,
            max_udp_payload: 8192,
            max_udp_buffer_bytes: 65536,
            max_header_bytes: 8192,
            max_connections: None,
            rate_limit: None,
            fallback_pool: None,
            resource_limits: None,
            tcp: TcpConfig::default(),
            outbounds: Default::default(),
            rule_providers: Default::default(),
            rules: Default::default(),
            geoip: None,
            proxy_protocol: Default::default(),
        },
        tls: TlsConfig {
            cert: cert_path.to_string_lossy().to_string(),
            key: key_path.to_string_lossy().to_string(),
            alpn: vec![],
            min_version: TlsVersion::Tls13,
            max_version: TlsVersion::Tls13,
            client_ca: None,
            cipher_suites: vec![],
        },
        auth: AuthConfig {
            passwords: vec![password.clone()],
            users: vec![],
            ..Default::default()
        },
        websocket: WebSocketConfig::default(),
        metrics: MetricsConfig {
            listen: None,
            ..Default::default()
        },
        analytics: Default::default(),
        logging: LoggingConfig {
            level: Some("warn".to_string()),
            ..Default::default()
        },
        dns: Default::default(),
        ddns: Default::default(),
    };

    let auth = MemoryAuth::from_passwords(&config.auth.passwords);
    let shutdown_trigger = CancellationToken::new();
    let shutdown = shutdown_trigger.clone();
    let server_config = config.clone();

    tokio::spawn(async move {
        let _ = trojan_server::run_with_shutdown(server_config, auth, shutdown).await;
    });

    tokio::time::sleep(Duration::from_millis(100)).await;

    let server_name: ServerName<'_> = ServerName::try_from("localhost").unwrap();

    // Connection should succeed with TLS 1.3
    let conn = tokio::net::TcpStream::connect(addr).await.unwrap();
    let tls_result = tls_connector.connect(server_name.clone(), conn).await;
    assert!(tls_result.is_ok(), "TLS 1.3 connection should succeed");

    // Cleanup
    shutdown_trigger.cancel();
    let _ = fs::remove_dir_all(&temp_dir);
}

// ============================================================================
// UDP Relay Tests
// ============================================================================

/// A simple UDP server that echoes back whatever it receives.
struct MockUdpEchoServer {
    addr: SocketAddr,
    _handle: thread::JoinHandle<()>,
}

impl MockUdpEchoServer {
    fn start() -> Self {
        let socket = std::net::UdpSocket::bind("127.0.0.1:0").unwrap();
        let addr = socket.local_addr().unwrap();

        let handle = thread::spawn(move || {
            let mut buf = [0u8; 4096];
            while let Ok((n, src)) = socket.recv_from(&mut buf) {
                // Echo back with "ECHO:" prefix
                let mut response = Vec::from(b"ECHO:".as_slice());
                response.extend_from_slice(&buf[..n]);
                let _ = socket.send_to(&response, src);
            }
        });

        Self {
            addr,
            _handle: handle,
        }
    }
}

/// Test UDP relay functionality.
#[tokio::test]
async fn test_udp_relay() {
    // Start UDP echo server (target)
    let udp_echo = MockUdpEchoServer::start();

    // Start fallback server
    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

    // Start trojan server
    let server = TestServer::start(fallback.addr).await;

    // Connect via TLS
    let tcp_stream = tokio::net::TcpStream::connect(server.addr).await.unwrap();
    let server_name = ServerName::try_from("localhost").unwrap();
    let mut tls_stream = server
        .tls_connector
        .connect(server_name, tcp_stream)
        .await
        .unwrap();

    // Build Trojan UDP ASSOCIATE request header
    let hash = server.hash();
    let ip_addr: std::net::Ipv4Addr = match udp_echo.addr.ip() {
        std::net::IpAddr::V4(v4) => v4,
        _ => panic!("Expected IPv4 address"),
    };

    // The target address in UDP ASSOCIATE header specifies the initial target
    let target_addr = AddressRef {
        host: HostRef::Ipv4(ip_addr.octets()),
        port: udp_echo.addr.port(),
    };

    let mut header = BytesMut::new();
    write_request_header(
        &mut header,
        hash.as_bytes(),
        CMD_UDP_ASSOCIATE,
        &target_addr,
    )
    .unwrap();

    // Send the UDP ASSOCIATE header
    tls_stream.write_all(&header).await.unwrap();
    tls_stream.flush().await.unwrap();

    // Now send a UDP packet through the trojan UDP encapsulation
    let udp_target = AddressRef {
        host: HostRef::Ipv4(ip_addr.octets()),
        port: udp_echo.addr.port(),
    };
    let mut udp_packet = BytesMut::new();
    write_udp_packet(&mut udp_packet, &udp_target, b"Hello UDP!").unwrap();

    tls_stream.write_all(&udp_packet).await.unwrap();
    tls_stream.flush().await.unwrap();

    // Read UDP response (should be echoed back with "ECHO:" prefix)
    let mut response = vec![0u8; 1024];
    let n = tokio::time::timeout(Duration::from_secs(5), tls_stream.read(&mut response))
        .await
        .expect("read timeout")
        .unwrap();

    // The response is a trojan UDP packet, we need to parse it
    // Format: ATYP(1) + ADDR + PORT(2) + LENGTH(2) + CRLF(2) + PAYLOAD
    // For IPv4: 1 + 4 + 2 + 2 + 2 + payload_len
    assert!(n > 11, "Response too short: {} bytes", n);

    // Extract payload from the UDP packet
    // Skip ATYP(1) + IPv4(4) + PORT(2) + LENGTH(2) + CRLF(2) = 11 bytes for IPv4
    let payload = &response[11..n];
    assert_eq!(payload, b"ECHO:Hello UDP!", "UDP echo response mismatch");
}

/// Test UDP idle timeout behavior.
#[tokio::test]
async fn test_udp_idle_timeout() {
    // Start UDP echo server
    let udp_echo = MockUdpEchoServer::start();

    // Start fallback server
    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

    // Create server with short UDP timeout (1 second)
    let (cert_pem, key_pem) = generate_test_certs();
    let temp_dir = tempfile::tempdir().unwrap();
    let cert_path = temp_dir.path().join("cert.pem");
    let key_path = temp_dir.path().join("key.pem");
    fs::write(&cert_path, &cert_pem).unwrap();
    fs::write(&key_path, &key_pem).unwrap();

    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let addr = listener.local_addr().unwrap();
    drop(listener);

    let password = "test_password";

    let config = Config {
        server: ServerConfig {
            listen: addr.to_string(),
            fallback: fallback.addr.to_string(),
            tcp_idle_timeout_secs: 30,
            udp_timeout_secs: 1, // 1 second timeout
            max_udp_payload: 8192,
            max_udp_buffer_bytes: 65536,
            max_header_bytes: 8192,
            max_connections: None,
            rate_limit: None,
            fallback_pool: None,
            resource_limits: None,
            tcp: TcpConfig::default(),
            outbounds: Default::default(),
            rule_providers: Default::default(),
            rules: Default::default(),
            geoip: None,
            proxy_protocol: Default::default(),
        },
        tls: TlsConfig {
            cert: cert_path.to_string_lossy().to_string(),
            key: key_path.to_string_lossy().to_string(),
            alpn: vec![],
            min_version: TlsVersion::Tls12,
            max_version: TlsVersion::Tls13,
            client_ca: None,
            cipher_suites: vec![],
        },
        auth: AuthConfig {
            passwords: vec![password.to_string()],
            users: vec![],
            ..Default::default()
        },
        websocket: WebSocketConfig::default(),
        metrics: MetricsConfig {
            listen: None,
            ..Default::default()
        },
        analytics: Default::default(),
        logging: LoggingConfig {
            level: Some("warn".to_string()),
            ..Default::default()
        },
        dns: Default::default(),
        ddns: Default::default(),
    };

    let auth = MemoryAuth::from_passwords(&config.auth.passwords);
    tokio::spawn(async move {
        let _ = trojan_server::run(config, auth).await;
    });
    tokio::time::sleep(Duration::from_millis(500)).await;

    // Create TLS connector
    let mut root_store = RootCertStore::empty();
    let cert_der = CertificateDer::from(
        rustls_pemfile::certs(&mut std::io::BufReader::new(cert_pem.as_bytes()))
            .next()
            .unwrap()
            .unwrap()
            .to_vec(),
    );
    root_store.add(cert_der).unwrap();
    let client_config = ClientConfig::builder()
        .with_root_certificates(root_store)
        .with_no_client_auth();
    let tls_connector = TlsConnector::from(Arc::new(client_config));

    // Connect
    let tcp_stream = tokio::net::TcpStream::connect(addr).await.unwrap();
    let server_name = ServerName::try_from("localhost").unwrap();
    let mut tls_stream = tls_connector
        .connect(server_name, tcp_stream)
        .await
        .unwrap();

    // Send UDP ASSOCIATE request
    let hash = sha224_hex(password);
    let ip_addr: std::net::Ipv4Addr = match udp_echo.addr.ip() {
        std::net::IpAddr::V4(v4) => v4,
        _ => panic!("Expected IPv4"),
    };
    let target_addr = AddressRef {
        host: HostRef::Ipv4(ip_addr.octets()),
        port: udp_echo.addr.port(),
    };

    let mut header = BytesMut::new();
    write_request_header(
        &mut header,
        hash.as_bytes(),
        CMD_UDP_ASSOCIATE,
        &target_addr,
    )
    .unwrap();
    tls_stream.write_all(&header).await.unwrap();
    tls_stream.flush().await.unwrap();

    // Send one packet
    let mut udp_packet = BytesMut::new();
    write_udp_packet(&mut udp_packet, &target_addr, b"test").unwrap();
    tls_stream.write_all(&udp_packet).await.unwrap();
    tls_stream.flush().await.unwrap();

    // Read response
    let mut response = vec![0u8; 1024];
    let _ = tokio::time::timeout(Duration::from_secs(2), tls_stream.read(&mut response))
        .await
        .unwrap();

    // Now wait for timeout (1 second + buffer)
    tokio::time::sleep(Duration::from_millis(1500)).await;

    // Try to send another packet - connection should be closed due to timeout
    let mut udp_packet2 = BytesMut::new();
    write_udp_packet(&mut udp_packet2, &target_addr, b"test2").unwrap();
    let write_result = tls_stream.write_all(&udp_packet2).await;

    // Either write fails or subsequent read returns 0 (connection closed)
    if write_result.is_ok() {
        tls_stream.flush().await.ok();
        let mut buf = vec![0u8; 1024];
        let read_result =
            tokio::time::timeout(Duration::from_secs(2), tls_stream.read(&mut buf)).await;
        match read_result {
            Ok(Ok(0)) => { /* Expected: connection closed */ }
            Ok(Ok(_)) => { /* Server might still have buffered response */ }
            Ok(Err(_)) => { /* Read error expected after timeout */ }
            Err(_) => { /* Timeout on read is also acceptable */ }
        }
    }
    // Test passes if we get here - timeout behavior is working
}

/// Test multiple UDP packets in sequence.
#[tokio::test]
async fn test_udp_relay_multiple_packets() {
    // Start UDP echo server
    let udp_echo = MockUdpEchoServer::start();

    // Start fallback server
    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

    // Start trojan server
    let server = TestServer::start(fallback.addr).await;

    // Connect via TLS
    let tcp_stream = tokio::net::TcpStream::connect(server.addr).await.unwrap();
    let server_name = ServerName::try_from("localhost").unwrap();
    let mut tls_stream = server
        .tls_connector
        .connect(server_name, tcp_stream)
        .await
        .unwrap();

    // Build Trojan UDP ASSOCIATE request
    let hash = server.hash();
    let ip_addr: std::net::Ipv4Addr = match udp_echo.addr.ip() {
        std::net::IpAddr::V4(v4) => v4,
        _ => panic!("Expected IPv4 address"),
    };

    let target_addr = AddressRef {
        host: HostRef::Ipv4(ip_addr.octets()),
        port: udp_echo.addr.port(),
    };

    let mut header = BytesMut::new();
    write_request_header(
        &mut header,
        hash.as_bytes(),
        CMD_UDP_ASSOCIATE,
        &target_addr,
    )
    .unwrap();
    tls_stream.write_all(&header).await.unwrap();
    tls_stream.flush().await.unwrap();

    // Send multiple UDP packets
    for i in 0..3 {
        let udp_target = AddressRef {
            host: HostRef::Ipv4(ip_addr.octets()),
            port: udp_echo.addr.port(),
        };
        let msg = format!("Packet {}", i);
        let mut udp_packet = BytesMut::new();
        write_udp_packet(&mut udp_packet, &udp_target, msg.as_bytes()).unwrap();

        tls_stream.write_all(&udp_packet).await.unwrap();
        tls_stream.flush().await.unwrap();

        // Read response
        let mut response = vec![0u8; 1024];
        let n = tokio::time::timeout(Duration::from_secs(5), tls_stream.read(&mut response))
            .await
            .expect("read timeout")
            .unwrap();

        assert!(n > 11, "Response too short for packet {}", i);
        let payload = &response[11..n];
        let expected = format!("ECHO:Packet {}", i);
        assert_eq!(
            std::str::from_utf8(payload).unwrap(),
            expected,
            "UDP echo response mismatch for packet {}",
            i
        );
    }
}

// ============================================================================
// Load and Timeout Tests
// ============================================================================

/// Test TCP idle timeout behavior.
#[tokio::test]
async fn test_tcp_idle_timeout() {
    // Start echo server (that doesn't respond)
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let echo_addr = listener.local_addr().unwrap();

    // Echo server that delays response indefinitely
    thread::spawn(move || {
        for _stream in listener.incoming().flatten() {
            // Just hold the connection, don't read or write
            thread::sleep(Duration::from_secs(60));
        }
    });

    // Start fallback server
    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

    // Create server with short TCP timeout (1 second)
    let (cert_pem, key_pem) = generate_test_certs();
    let temp_dir = tempfile::tempdir().unwrap();
    let cert_path = temp_dir.path().join("cert.pem");
    let key_path = temp_dir.path().join("key.pem");
    fs::write(&cert_path, &cert_pem).unwrap();
    fs::write(&key_path, &key_pem).unwrap();

    let tcp_listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let addr = tcp_listener.local_addr().unwrap();
    drop(tcp_listener);

    let password = "test_password";

    let config = Config {
        server: ServerConfig {
            listen: addr.to_string(),
            fallback: fallback.addr.to_string(),
            tcp_idle_timeout_secs: 1, // 1 second timeout
            udp_timeout_secs: 30,
            max_udp_payload: 8192,
            max_udp_buffer_bytes: 65536,
            max_header_bytes: 8192,
            max_connections: None,
            rate_limit: None,
            fallback_pool: None,
            resource_limits: None,
            tcp: TcpConfig::default(),
            outbounds: Default::default(),
            rule_providers: Default::default(),
            rules: Default::default(),
            geoip: None,
            proxy_protocol: Default::default(),
        },
        tls: TlsConfig {
            cert: cert_path.to_string_lossy().to_string(),
            key: key_path.to_string_lossy().to_string(),
            alpn: vec![],
            min_version: TlsVersion::Tls12,
            max_version: TlsVersion::Tls13,
            client_ca: None,
            cipher_suites: vec![],
        },
        auth: AuthConfig {
            passwords: vec![password.to_string()],
            users: vec![],
            ..Default::default()
        },
        websocket: WebSocketConfig::default(),
        metrics: MetricsConfig {
            listen: None,
            ..Default::default()
        },
        analytics: Default::default(),
        logging: LoggingConfig {
            level: Some("warn".to_string()),
            ..Default::default()
        },
        dns: Default::default(),
        ddns: Default::default(),
    };

    let auth = MemoryAuth::from_passwords(&config.auth.passwords);
    tokio::spawn(async move {
        let _ = trojan_server::run(config, auth).await;
    });
    tokio::time::sleep(Duration::from_millis(500)).await;

    // Create TLS connector
    let mut root_store = RootCertStore::empty();
    let cert_der = CertificateDer::from(
        rustls_pemfile::certs(&mut std::io::BufReader::new(cert_pem.as_bytes()))
            .next()
            .unwrap()
            .unwrap()
            .to_vec(),
    );
    root_store.add(cert_der).unwrap();
    let client_config = ClientConfig::builder()
        .with_root_certificates(root_store)
        .with_no_client_auth();
    let tls_connector = TlsConnector::from(Arc::new(client_config));

    // Connect
    let tcp_stream = tokio::net::TcpStream::connect(addr).await.unwrap();
    let server_name = ServerName::try_from("localhost").unwrap();
    let mut tls_stream = tls_connector
        .connect(server_name, tcp_stream)
        .await
        .unwrap();

    // Send CONNECT request to the slow echo server
    let hash = sha224_hex(password);
    let ip_addr: std::net::Ipv4Addr = match echo_addr.ip() {
        std::net::IpAddr::V4(v4) => v4,
        _ => panic!("Expected IPv4"),
    };
    let target_addr = AddressRef {
        host: HostRef::Ipv4(ip_addr.octets()),
        port: echo_addr.port(),
    };

    let mut header = BytesMut::new();
    write_request_header(&mut header, hash.as_bytes(), CMD_CONNECT, &target_addr).unwrap();
    header.extend_from_slice(b"Hello");

    tls_stream.write_all(&header).await.unwrap();
    tls_stream.flush().await.unwrap();

    // Wait for idle timeout + buffer
    let start = std::time::Instant::now();
    let mut buf = vec![0u8; 1024];

    // Read should return 0 (closed) or timeout after the idle period
    let read_result = tokio::time::timeout(Duration::from_secs(5), tls_stream.read(&mut buf)).await;

    let elapsed = start.elapsed();

    match read_result {
        Ok(Ok(0)) => {
            // Connection closed due to idle timeout
            assert!(
                elapsed >= Duration::from_millis(900),
                "Connection closed too early: {:?}",
                elapsed
            );
        }
        Ok(Ok(_)) => {
            // Got some data (unexpected from our slow server, but might be TLS close)
        }
        Ok(Err(_)) => {
            // Read error is acceptable after timeout
        }
        Err(_) => {
            // Timeout on read (shouldn't happen with 5s timeout and 1s idle)
            panic!("Read timeout - idle timeout may not be working");
        }
    }
}

/// Test concurrent connections load.
#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn test_concurrent_connections() {
    // Start echo server
    let echo_server = MockEchoServer::start();

    // Start fallback server
    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

    // Start trojan server
    let server = TestServer::start(fallback.addr).await;

    let num_connections = 20;
    let mut handles = Vec::with_capacity(num_connections);

    for i in 0..num_connections {
        let server_addr = server.addr;
        let tls_connector = server.tls_connector.clone();
        let hash = server.hash();
        let echo_addr = echo_server.addr;

        handles.push(tokio::spawn(async move {
            // Connect via TLS
            let tcp_stream = tokio::net::TcpStream::connect(server_addr).await?;
            let server_name = ServerName::try_from("localhost").unwrap();
            let mut tls_stream = tls_connector.connect(server_name, tcp_stream).await?;

            // Build Trojan request
            let ip_addr: std::net::Ipv4Addr = match echo_addr.ip() {
                std::net::IpAddr::V4(v4) => v4,
                _ => panic!("Expected IPv4"),
            };
            let target_addr = AddressRef {
                host: HostRef::Ipv4(ip_addr.octets()),
                port: echo_addr.port(),
            };

            let msg = format!("Connection {}", i);
            let mut header = BytesMut::new();
            write_request_header(&mut header, hash.as_bytes(), CMD_CONNECT, &target_addr).unwrap();
            header.extend_from_slice(msg.as_bytes());

            tls_stream.write_all(&header).await?;
            tls_stream.flush().await?;

            // Read response
            let mut response = vec![0u8; 1024];
            let n = tokio::time::timeout(Duration::from_secs(10), tls_stream.read(&mut response))
                .await
                .map_err(|_| std::io::Error::new(std::io::ErrorKind::TimedOut, "read timeout"))??;

            assert_eq!(&response[..n], msg.as_bytes());
            Ok::<_, std::io::Error>(())
        }));
    }

    // Wait for all connections
    let mut success_count = 0;
    for handle in handles {
        if handle.await.unwrap().is_ok() {
            success_count += 1;
        }
    }

    assert_eq!(
        success_count, num_connections,
        "Not all connections succeeded"
    );
}

// ============================================================================
// Intranet Access Tests
//
// Verify server behavior when used as an exit node for internal targets:
// domain ATYPs resolving to loopback, targets that close immediately, and
// unresolvable domains. The latter two reproduce the failure modes that
// surface as plain "EOF" on the client side.
// ============================================================================

/// A TCP server that accepts a connection and immediately closes it with RST.
/// Simulates an intranet target that completes the TCP handshake but rejects
/// the request (wrong protocol, source-IP ACL, etc.) — the most common cause
/// of "EOF on intranet" in the wild. `SO_LINGER=0` forces close to send RST
/// instead of FIN, making test timing deterministic regardless of whether
/// the client wrote payload before the drop.
struct MockSilentServer {
    addr: SocketAddr,
    _handle: thread::JoinHandle<()>,
}

impl MockSilentServer {
    fn start() -> Self {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap();

        let handle = thread::spawn(move || {
            for stream in listener.incoming().flatten() {
                let _ = socket2::SockRef::from(&stream).set_linger(Some(Duration::ZERO));
                drop(stream);
            }
        });

        Self {
            addr,
            _handle: handle,
        }
    }
}

/// CONNECT with a Domain ATYP that resolves to a loopback address — the
/// standard "internal hostname → private IP" intranet flow. In production
/// the exit node would resolve `gitlab.corp.local` via an internal resolver;
/// here `localhost` plays the same role.
#[tokio::test]
async fn test_intranet_domain_resolves_to_loopback() {
    use std::net::ToSocketAddrs;

    // Bind the echo server on whichever IP family `localhost` actually
    // resolves to on this host (system /etc/hosts may only have `::1` or
    // only `127.0.0.1`). With the connect-fallthrough fix the server will
    // try every resolved candidate, but on a host that returns only one
    // family this is the only family the server will be able to reach.
    let localhost_ip = ("localhost", 0u16)
        .to_socket_addrs()
        .unwrap()
        .next()
        .expect("localhost must resolve")
        .ip();
    let echo_server = MockEchoServer::start_on((localhost_ip, 0u16));
    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
    let server = TestServer::start(fallback.addr).await;

    let tcp_stream = tokio::net::TcpStream::connect(server.addr).await.unwrap();
    let server_name = ServerName::try_from("localhost").unwrap();
    let mut tls_stream = server
        .tls_connector
        .connect(server_name, tcp_stream)
        .await
        .unwrap();

    let hash = server.hash();
    let target_addr = AddressRef {
        host: HostRef::Domain(b"localhost"),
        port: echo_server.addr.port(),
    };

    let mut header = BytesMut::new();
    write_request_header(&mut header, hash.as_bytes(), CMD_CONNECT, &target_addr).unwrap();
    header.extend_from_slice(b"intranet ping");

    tls_stream.write_all(&header).await.unwrap();
    tls_stream.flush().await.unwrap();

    let mut response = vec![0u8; 1024];
    let n = tokio::time::timeout(Duration::from_secs(5), tls_stream.read(&mut response))
        .await
        .expect("read timeout")
        .unwrap();

    assert_eq!(&response[..n], b"intranet ping");
}

/// When an intranet target accepts the TCP connection then immediately
/// closes it (often with TCP RST, since dropping a socket with unread data
/// triggers RST on Linux), the relay reunites its split halves and runs an
/// explicit shutdown on the inbound TLS stream so the client sees a clean
/// `Ok(0)` close_notify rather than `UnexpectedEof`. Reproduces the most
/// common "EOF on intranet" failure mode (target reachable but rejects the
/// request post-handshake — wrong protocol, ACL, etc.).
#[tokio::test]
async fn test_intranet_target_immediate_close_yields_eof() {
    let silent = MockSilentServer::start();
    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
    let server = TestServer::start(fallback.addr).await;

    let tcp_stream = tokio::net::TcpStream::connect(server.addr).await.unwrap();
    let server_name = ServerName::try_from("localhost").unwrap();
    let mut tls_stream = server
        .tls_connector
        .connect(server_name, tcp_stream)
        .await
        .unwrap();

    let hash = server.hash();
    let ip_addr: std::net::Ipv4Addr = match silent.addr.ip() {
        std::net::IpAddr::V4(v4) => v4,
        _ => panic!("expected IPv4"),
    };
    let target_addr = AddressRef {
        host: HostRef::Ipv4(ip_addr.octets()),
        port: silent.addr.port(),
    };

    let mut header = BytesMut::new();
    write_request_header(&mut header, hash.as_bytes(), CMD_CONNECT, &target_addr).unwrap();
    header.extend_from_slice(b"hello");

    tls_stream.write_all(&header).await.unwrap();
    tls_stream.flush().await.unwrap();

    let mut response = vec![0u8; 1024];
    let n = tokio::time::timeout(Duration::from_secs(5), tls_stream.read(&mut response))
        .await
        .expect("read timeout")
        .expect("expected clean Ok(0) close_notify, not UnexpectedEof");

    assert_eq!(n, 0, "expected close_notify after target closes");
}

/// When the intranet domain fails to resolve, the server's CONNECT handler
/// calls TLS shutdown before returning the error so the client sees a clean
/// `Ok(0)` close_notify instead of `UnexpectedEof`. Uses `.invalid` (reserved
/// by RFC 2606) to guarantee NXDOMAIN without depending on external DNS.
#[tokio::test]
async fn test_intranet_unresolvable_domain_closes_cleanly() {
    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
    let server = TestServer::start(fallback.addr).await;

    let tcp_stream = tokio::net::TcpStream::connect(server.addr).await.unwrap();
    let server_name = ServerName::try_from("localhost").unwrap();
    let mut tls_stream = server
        .tls_connector
        .connect(server_name, tcp_stream)
        .await
        .unwrap();

    let hash = server.hash();
    let target_addr = AddressRef {
        host: HostRef::Domain(b"nonexistent.intranet.invalid"),
        port: 443,
    };

    let mut header = BytesMut::new();
    write_request_header(&mut header, hash.as_bytes(), CMD_CONNECT, &target_addr).unwrap();
    header.extend_from_slice(b"hello");

    tls_stream.write_all(&header).await.unwrap();
    tls_stream.flush().await.unwrap();

    let mut response = vec![0u8; 1024];
    let n = tokio::time::timeout(Duration::from_secs(15), tls_stream.read(&mut response))
        .await
        .expect("read timeout")
        .expect("expected clean Ok(0) close_notify, not UnexpectedEof");

    assert_eq!(n, 0, "expected close_notify after resolve failure");
}

// ============================================================================
// Stream Integrity Tests
// ============================================================================
//
// The relay is a buffered, poll-driven state machine, so its failure mode is
// not a wrong answer but a stall or a silently truncated stream — the class of
// bug seen in 0.8/0.9 (missing flushes leaving data in TLS buffers, and
// `read_handshake` dropping over-read bytes). The other tests here send a
// header and a small payload in one write, which never exercises a header
// split across reads or a transfer spanning many flushes.

/// Build a CONNECT header for an IPv4 target.
fn connect_header(hash: &str, target: SocketAddr) -> BytesMut {
    let ip = match target.ip() {
        std::net::IpAddr::V4(v4) => v4,
        other => panic!("expected IPv4 target, got {other}"),
    };
    let address = AddressRef {
        host: HostRef::Ipv4(ip.octets()),
        port: target.port(),
    };
    let mut header = BytesMut::new();
    write_request_header(&mut header, hash.as_bytes(), CMD_CONNECT, &address).unwrap();
    header
}

/// A TCP server that reads until EOF and only then replies.
///
/// Makes half-close observable: the reply can only arrive if the relay both
/// propagated the client's FIN to the target *and* kept the target→client
/// direction open afterwards.
struct MockDrainThenReplyServer {
    addr: SocketAddr,
    _handle: thread::JoinHandle<()>,
}

impl MockDrainThenReplyServer {
    fn start(reply: &'static [u8]) -> Self {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap();

        let handle = thread::spawn(move || {
            for mut stream in listener.incoming().flatten() {
                thread::spawn(move || {
                    // Drain to EOF: this only returns once the client's
                    // half-close has been relayed through as a FIN.
                    let mut sink = Vec::new();
                    if stream.read_to_end(&mut sink).is_err() {
                        return;
                    }
                    let _ = stream.write_all(reply);
                    let _ = stream.flush();
                    let _ = stream.shutdown(std::net::Shutdown::Write);
                });
            }
        });

        Self {
            addr,
            _handle: handle,
        }
    }
}

/// Index of the first differing byte, for asserting on large buffers without
/// dumping megabytes into the failure output.
fn first_difference(a: &[u8], b: &[u8]) -> Option<usize> {
    a.iter().zip(b).position(|(x, y)| x != y).or_else(|| {
        if a.len() == b.len() {
            None
        } else {
            Some(a.len().min(b.len()))
        }
    })
}

/// The header must still parse when it arrives a few bytes at a time.
///
/// The server accumulates into a `BytesMut` and re-parses on every read. A
/// `read_buf` is only offered the buffer's spare capacity, so the very first
/// read can land far below the 68-byte minimum header — a regression in the
/// incomplete-parse loop or the buffer sizing shows up here as a stall or an
/// unwanted fallback, not as a wrong byte.
#[tokio::test]
async fn test_header_fragmented_across_reads() {
    let echo_server = MockEchoServer::start();
    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
    let server = TestServer::start(fallback.addr).await;

    let tcp_stream = tokio::net::TcpStream::connect(server.addr).await.unwrap();
    let server_name = ServerName::try_from("localhost").unwrap();
    let mut tls_stream = server
        .tls_connector
        .connect(server_name, tcp_stream)
        .await
        .unwrap();

    let header = connect_header(&server.hash(), echo_server.addr);
    let payload = b"fragmented-header-payload";

    // 7 bytes per TLS record, each flushed separately, so the server sees a
    // partial header on several consecutive reads.
    for chunk in header.chunks(7) {
        tls_stream.write_all(chunk).await.unwrap();
        tls_stream.flush().await.unwrap();
        tokio::time::sleep(Duration::from_millis(2)).await;
    }
    tls_stream.write_all(payload).await.unwrap();
    tls_stream.flush().await.unwrap();

    let mut response = vec![0u8; payload.len()];
    tokio::time::timeout(
        Duration::from_secs(10),
        tls_stream.read_exact(&mut response),
    )
    .await
    .expect("timed out — a fragmented header stalled the request")
    .unwrap();

    assert_eq!(&response[..], payload);
}

/// A transfer far larger than one relay buffer must round-trip byte-exact.
///
/// 4 MiB against a 32 KiB relay buffer spans many read/write/flush cycles in
/// both directions, which is what exercises the deferred-flush state machine
/// and the per-write byte reporting. Reads run concurrently with writes so
/// the test cannot pass by accident on socket buffering alone.
#[tokio::test]
async fn test_large_transfer_round_trip() {
    const TRANSFER_BYTES: usize = 4 * 1024 * 1024;

    let echo_server = MockEchoServer::start();
    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
    let server = TestServer::start(fallback.addr).await;

    let tcp_stream = tokio::net::TcpStream::connect(server.addr).await.unwrap();
    let server_name = ServerName::try_from("localhost").unwrap();
    let tls_stream = server
        .tls_connector
        .connect(server_name, tcp_stream)
        .await
        .unwrap();

    let header = connect_header(&server.hash(), echo_server.addr);
    // Position-dependent bytes: a dropped or reordered chunk shifts the
    // pattern and is caught, which a constant fill would hide. The period is
    // coprime with every power-of-two buffer size in the path, so a whole
    // buffer going missing cannot realign the stream.
    let payload: Vec<u8> = (0..=250u8).cycle().take(TRANSFER_BYTES).collect();

    let (mut reader, mut writer) = tokio::io::split(tls_stream);
    let to_send = payload.clone();
    let writer_task = tokio::spawn(async move {
        writer.write_all(&header).await.unwrap();
        writer.write_all(&to_send).await.unwrap();
        writer.flush().await.unwrap();
    });

    let mut received = vec![0u8; TRANSFER_BYTES];
    tokio::time::timeout(Duration::from_secs(120), reader.read_exact(&mut received))
        .await
        .expect("timed out — relay stalled mid-transfer")
        .expect("stream truncated before the full payload arrived");

    writer_task.await.unwrap();

    assert_eq!(
        first_difference(&received, &payload),
        None,
        "payload corrupted in transit"
    );
}

/// A second connection reusing the client's session cache must resume.
///
/// Guards the server's resumption config as a whole: with no ticketer and no
/// session storage the second handshake silently falls back to a full one,
/// which costs a signature and a key exchange per connection but breaks
/// nothing visible.
///
/// TLS 1.3 sends NewSessionTicket after the handshake, so the first
/// connection has to actually read before the ticket reaches the client.
#[tokio::test]
async fn test_tls_session_resumption() {
    let echo_server = MockEchoServer::start();
    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
    let server = TestServer::start(fallback.addr).await;
    let server_name = ServerName::try_from("localhost").unwrap();

    let header = connect_header(&server.hash(), echo_server.addr);
    let payload = b"resume-me";

    // First connection: full handshake, then a round trip so the client
    // processes the NewSessionTicket that follows it.
    let tcp = tokio::net::TcpStream::connect(server.addr).await.unwrap();
    let mut first = server
        .tls_connector
        .connect(server_name.clone(), tcp)
        .await
        .unwrap();
    assert_eq!(
        first.get_ref().1.handshake_kind(),
        Some(rustls::HandshakeKind::Full),
        "first handshake should be full"
    );

    first.write_all(&header).await.unwrap();
    first.write_all(payload).await.unwrap();
    first.flush().await.unwrap();
    let mut echo = vec![0u8; payload.len()];
    tokio::time::timeout(Duration::from_secs(10), first.read_exact(&mut echo))
        .await
        .expect("read timeout")
        .unwrap();
    assert_eq!(&echo[..], payload);
    drop(first);

    // Second connection over the same client config, whose session cache now
    // holds the ticket.
    let tcp = tokio::net::TcpStream::connect(server.addr).await.unwrap();
    let second = server
        .tls_connector
        .connect(server_name, tcp)
        .await
        .unwrap();

    assert_eq!(
        second.get_ref().1.handshake_kind(),
        Some(rustls::HandshakeKind::Resumed),
        "second handshake should resume; the server is not offering resumable sessions"
    );
}

/// A client half-close must reach the target, and the return path must stay
/// open afterwards.
///
/// This is the shape of the 0.8 "stalling under back-pressure" bug: treating
/// either side's EOF as end-of-session drops data the target had not sent yet.
/// The relay drives each direction as an independent state machine precisely
/// so this works.
#[tokio::test]
async fn test_half_close_still_delivers_target_reply() {
    const REPLY: &[u8] = b"reply-after-eof";

    let target = MockDrainThenReplyServer::start(REPLY);
    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
    let server = TestServer::start(fallback.addr).await;

    let tcp_stream = tokio::net::TcpStream::connect(server.addr).await.unwrap();
    let server_name = ServerName::try_from("localhost").unwrap();
    let mut tls_stream = server
        .tls_connector
        .connect(server_name, tcp_stream)
        .await
        .unwrap();

    let mut header = connect_header(&server.hash(), target.addr);
    header.extend_from_slice(b"request-body");
    tls_stream.write_all(&header).await.unwrap();
    tls_stream.flush().await.unwrap();

    // Close only our write side. The target is blocked on read-to-EOF, so it
    // cannot reply until this FIN reaches it.
    tls_stream.shutdown().await.unwrap();

    let mut reply = Vec::new();
    tokio::time::timeout(Duration::from_secs(10), tls_stream.read_to_end(&mut reply))
        .await
        .expect("timed out — half-close was not relayed, or the return path was torn down")
        .unwrap();

    assert_eq!(reply, REPLY);
}

/// Read `count` trojan-framed UDP payloads, tolerating any split across reads.
async fn read_udp_payloads(
    tls: &mut tokio_rustls::client::TlsStream<tokio::net::TcpStream>,
    count: usize,
) -> Vec<Vec<u8>> {
    use bytes::Buf;
    use trojan_proto::{ParseResult, parse_udp_packet};

    let mut acc = BytesMut::new();
    let mut out = Vec::new();
    let mut chunk = vec![0u8; 4096];

    while out.len() < count {
        let n = tokio::time::timeout(Duration::from_secs(10), tls.read(&mut chunk))
            .await
            .expect("timed out waiting for UDP responses")
            .unwrap();
        assert_ne!(
            n,
            0,
            "stream closed after {} of {count} responses",
            out.len()
        );
        acc.extend_from_slice(&chunk[..n]);

        loop {
            match parse_udp_packet(&acc) {
                ParseResult::Complete(pkt) => {
                    let payload = pkt.payload.to_vec();
                    let consumed = pkt.packet_len;
                    out.push(payload);
                    acc.advance(consumed);
                }
                ParseResult::Incomplete(_) => break,
                ParseResult::Invalid(err) => panic!("server sent an invalid UDP frame: {err:?}"),
            }
        }
    }
    out
}

/// UDP framing must survive packets split across reads and packets coalesced
/// into one read.
///
/// The UDP path re-parses a growing buffer and advances past each complete
/// packet, which is the same framing problem behind the 0.9 over-read bug: get
/// the boundary wrong and the stream desyncs into garbage rather than failing
/// loudly.
#[tokio::test]
async fn test_udp_packets_split_and_coalesced() {
    let udp_echo = MockUdpEchoServer::start();
    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
    let server = TestServer::start(fallback.addr).await;

    let tcp_stream = tokio::net::TcpStream::connect(server.addr).await.unwrap();
    let server_name = ServerName::try_from("localhost").unwrap();
    let mut tls_stream = server
        .tls_connector
        .connect(server_name, tcp_stream)
        .await
        .unwrap();

    let ip = match udp_echo.addr.ip() {
        std::net::IpAddr::V4(v4) => v4,
        other => panic!("expected IPv4 echo server, got {other}"),
    };
    let target = AddressRef {
        host: HostRef::Ipv4(ip.octets()),
        port: udp_echo.addr.port(),
    };

    let mut header = BytesMut::new();
    write_request_header(
        &mut header,
        server.hash().as_bytes(),
        CMD_UDP_ASSOCIATE,
        &target,
    )
    .unwrap();
    tls_stream.write_all(&header).await.unwrap();
    tls_stream.flush().await.unwrap();

    let frame = |payload: &[u8]| {
        let mut buf = BytesMut::new();
        write_udp_packet(&mut buf, &target, payload).unwrap();
        buf
    };

    // First packet: dribbled out 3 bytes per TLS record, so the server parses
    // an incomplete frame several times before it completes.
    let split = frame(b"split-packet");
    for piece in split.chunks(3) {
        tls_stream.write_all(piece).await.unwrap();
        tls_stream.flush().await.unwrap();
        tokio::time::sleep(Duration::from_millis(2)).await;
    }

    // Then a burst concatenated into a single write. Individually they are
    // tiny, so many complete frames land in one read and the server has to
    // drain them all before awaiting more — enough of them that a server
    // handling one frame per read would stall instead of finishing.
    const BURST: usize = 16;
    let mut coalesced = BytesMut::new();
    for i in 0..BURST {
        coalesced.extend_from_slice(&frame(format!("burst-{i:02}").as_bytes()));
    }
    tls_stream.write_all(&coalesced).await.unwrap();
    tls_stream.flush().await.unwrap();

    // UDP has no ordering guarantee, so compare as a set.
    let received: std::collections::BTreeSet<Vec<u8>> =
        read_udp_payloads(&mut tls_stream, BURST + 1)
            .await
            .into_iter()
            .collect();

    let mut expected: std::collections::BTreeSet<Vec<u8>> =
        [b"ECHO:split-packet".to_vec()].into_iter().collect();
    for i in 0..BURST {
        expected.insert(format!("ECHO:burst-{i:02}").into_bytes());
    }

    assert_eq!(received, expected);
}

/// Concurrent connections must not interfere with each other.
///
/// Per-connection state was reshaped when relay metrics moved to per-session
/// handles; distinct payloads per connection would surface any cross-talk, and
/// a shared bottleneck would surface as a timeout.
#[tokio::test]
async fn test_concurrent_connections_stay_independent() {
    const CONNECTIONS: usize = 32;

    let echo_server = MockEchoServer::start();
    let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
    let server = TestServer::start(fallback.addr).await;
    let server_name = ServerName::try_from("localhost").unwrap();
    let hash = server.hash();

    let mut tasks = Vec::with_capacity(CONNECTIONS);
    for i in 0..CONNECTIONS {
        let connector = server.tls_connector.clone();
        let server_name = server_name.clone();
        let header = connect_header(&hash, echo_server.addr);
        let addr = server.addr;

        tasks.push(tokio::spawn(async move {
            // Distinct per connection, and long enough to span several reads.
            let payload = format!("connection-{i:04}-").repeat(512).into_bytes();

            let tcp = tokio::net::TcpStream::connect(addr).await.unwrap();
            let tls = connector.connect(server_name, tcp).await.unwrap();
            let (mut reader, mut writer) = tokio::io::split(tls);

            let to_send = payload.clone();
            let write_task = tokio::spawn(async move {
                writer.write_all(&header).await.unwrap();
                writer.write_all(&to_send).await.unwrap();
                writer.flush().await.unwrap();
            });

            let mut echoed = vec![0u8; payload.len()];
            reader.read_exact(&mut echoed).await.unwrap();
            write_task.await.unwrap();

            assert_eq!(
                first_difference(&echoed, &payload),
                None,
                "connection {i} received another connection's bytes"
            );
        }));
    }

    for (i, task) in tasks.into_iter().enumerate() {
        tokio::time::timeout(Duration::from_secs(60), task)
            .await
            .unwrap_or_else(|_| panic!("connection {i} timed out"))
            .unwrap_or_else(|e| panic!("connection {i} failed: {e}"));
    }
}

// ============================================================================
// Multi-Worker (SO_REUSEPORT) Tests
// ============================================================================
//
// `server.tcp.reuse_port` is how this server scales past a single process:
// several processes bind the same port and the kernel hands each of them
// connections. Nothing exercised that shape, and it interacts with TLS
// session resumption — ticket keys are generated per process, so a resuming
// client can land on a worker that cannot decrypt its ticket.

mod multi_worker_tests {
    use super::*;
    use trojan_server::{CancellationToken, run_with_shutdown};

    const PASSWORD: &str = "test_password_123";

    /// A self-signed certificate shared by every worker.
    ///
    /// Workers behind one port have to be interchangeable to the client, which
    /// means presenting the same certificate — in production they read the same
    /// cert files, which is what this models.
    struct SharedPki {
        cert_path: std::path::PathBuf,
        key_path: std::path::PathBuf,
        cert_der: Vec<u8>,
        _temp_dir: tempfile::TempDir,
    }

    impl SharedPki {
        fn generate() -> Self {
            let (cert_pem, key_pem) = generate_test_certs();
            let temp_dir = tempfile::Builder::new()
                .prefix("trojan-multiworker-")
                .tempdir()
                .unwrap();
            let cert_path = temp_dir.path().join("cert.pem");
            let key_path = temp_dir.path().join("key.pem");
            fs::write(&cert_path, &cert_pem).unwrap();
            fs::write(&key_path, &key_pem).unwrap();

            let cert_der = rustls_pemfile::certs(&mut cert_pem.as_bytes())
                .next()
                .unwrap()
                .unwrap()
                .to_vec();

            Self {
                cert_path,
                key_path,
                cert_der,
                _temp_dir: temp_dir,
            }
        }

        /// A connector with its own session cache. Clone the result to share
        /// resumption state across connections; call again for a fresh client.
        fn connector(&self) -> TlsConnector {
            let mut root_store = RootCertStore::empty();
            root_store
                .add(CertificateDer::from(self.cert_der.clone()))
                .unwrap();
            TlsConnector::from(Arc::new(
                ClientConfig::builder()
                    .with_root_certificates(root_store)
                    .with_no_client_auth(),
            ))
        }
    }

    /// One server process, as spawned in a multi-worker deployment.
    struct Worker {
        shutdown: CancellationToken,
        _handle: tokio::task::JoinHandle<()>,
    }

    impl Worker {
        async fn spawn(
            pki: &SharedPki,
            listen: SocketAddr,
            fallback_addr: SocketAddr,
            reuse_port: bool,
        ) -> Self {
            let config = Config {
                server: ServerConfig {
                    listen: listen.to_string(),
                    fallback: fallback_addr.to_string(),
                    tcp_idle_timeout_secs: 30,
                    udp_timeout_secs: 30,
                    max_udp_payload: 8192,
                    max_udp_buffer_bytes: 65536,
                    max_header_bytes: 8192,
                    max_connections: None,
                    rate_limit: None,
                    fallback_pool: None,
                    resource_limits: None,
                    tcp: TcpConfig {
                        reuse_port,
                        ..Default::default()
                    },
                    outbounds: Default::default(),
                    rule_providers: Default::default(),
                    rules: Default::default(),
                    geoip: None,
                    proxy_protocol: Default::default(),
                },
                tls: TlsConfig {
                    cert: pki.cert_path.to_string_lossy().into_owned(),
                    key: pki.key_path.to_string_lossy().into_owned(),
                    alpn: vec![],
                    min_version: TlsVersion::Tls12,
                    max_version: TlsVersion::Tls13,
                    client_ca: None,
                    cipher_suites: vec![],
                },
                auth: AuthConfig {
                    passwords: vec![PASSWORD.to_string()],
                    users: vec![],
                    ..Default::default()
                },
                websocket: WebSocketConfig::default(),
                metrics: MetricsConfig {
                    listen: None,
                    ..Default::default()
                },
                analytics: Default::default(),
                logging: LoggingConfig {
                    level: Some("warn".to_string()),
                    ..Default::default()
                },
                dns: Default::default(),
                ddns: Default::default(),
            };

            let auth = MemoryAuth::from_passwords(&config.auth.passwords);
            let shutdown = CancellationToken::new();
            let token = shutdown.clone();
            let handle = tokio::spawn(async move {
                let _ = run_with_shutdown(config, auth, token).await;
            });

            Self {
                shutdown,
                _handle: handle,
            }
        }
    }

    impl Drop for Worker {
        fn drop(&mut self) {
            self.shutdown.cancel();
        }
    }

    /// Reserve an address by binding and immediately releasing it.
    async fn free_addr() -> SocketAddr {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        drop(listener);
        addr
    }

    /// Connect, relay one payload through, and report how the handshake went.
    ///
    /// The round trip matters: TLS 1.3 sends its NewSessionTicket *after* the
    /// handshake, so the client only banks a ticket once it has read.
    async fn handshake_kind_after_round_trip(
        connector: &TlsConnector,
        server_name: &ServerName<'static>,
        addr: SocketAddr,
        header: &BytesMut,
    ) -> Option<rustls::HandshakeKind> {
        let payload = b"ticket-probe";
        let tcp = tokio::net::TcpStream::connect(addr).await.unwrap();
        let mut tls = connector.connect(server_name.clone(), tcp).await.unwrap();
        let kind = tls.get_ref().1.handshake_kind();

        tls.write_all(header).await.unwrap();
        tls.write_all(payload).await.unwrap();
        tls.flush().await.unwrap();

        let mut echoed = vec![0u8; payload.len()];
        tokio::time::timeout(Duration::from_secs(10), tls.read_exact(&mut echoed))
            .await
            .expect("echo timeout")
            .unwrap();
        assert_eq!(&echoed[..], payload);
        kind
    }

    /// Two workers must be able to share one port, and every connection must be
    /// served correctly whichever worker accepts it.
    ///
    /// Which worker gets a given connection is kernel policy and differs
    /// between Linux (load-balanced across listeners) and the BSDs, so this
    /// asserts that every connection is served — not how they are distributed.
    #[tokio::test]
    async fn test_reuse_port_workers_share_one_port() {
        let pki = SharedPki::generate();
        let listen = free_addr().await;

        // Distinct fallback bodies make the serving worker observable: a
        // non-trojan request is proxied to whichever fallback that worker owns.
        let fallback_a = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nworker-A");
        let fallback_b = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nworker-B");

        let _worker_a = Worker::spawn(&pki, listen, fallback_a.addr, true).await;
        let _worker_b = Worker::spawn(&pki, listen, fallback_b.addr, true).await;
        tokio::time::sleep(Duration::from_millis(500)).await;

        let connector = pki.connector();
        let server_name = ServerName::try_from("localhost").unwrap();

        // Padded past 56 bytes so the server can reject the hash and fall back
        // rather than waiting for more header.
        let request =
            b"GET /this-is-a-long-path-to-make-the-request-longer HTTP/1.1\r\nHost: localhost\r\n\r\n";

        let mut seen = std::collections::BTreeSet::new();
        for i in 0..12 {
            let tcp = tokio::net::TcpStream::connect(listen)
                .await
                .unwrap_or_else(|e| panic!("connection {i} refused: {e}"));
            let mut tls = connector
                .connect(server_name.clone(), tcp)
                .await
                .unwrap_or_else(|e| panic!("connection {i} handshake failed: {e}"));

            tls.write_all(request).await.unwrap();
            tls.flush().await.unwrap();

            let mut body = Vec::new();
            tokio::time::timeout(Duration::from_secs(10), tls.read_to_end(&mut body))
                .await
                .expect("fallback read timeout")
                .unwrap();

            let body = String::from_utf8_lossy(&body).into_owned();
            let worker = if body.contains("worker-A") {
                "A"
            } else if body.contains("worker-B") {
                "B"
            } else {
                panic!("connection {i} got an unexpected fallback body: {body:?}");
            };
            seen.insert(worker);
        }

        assert!(!seen.is_empty(), "no connection was served");
        eprintln!(
            "reuse_port: {}/2 workers observed over 12 connections ({:?})",
            seen.len(),
            seen
        );
    }

    /// A ticket issued by one worker does not resume on another.
    ///
    /// `Ticketer::new()` generates its key at process start, so every worker
    /// has its own, and rustls keys the client session cache by server name
    /// only. A client that reconnects therefore offers whatever ticket it holds
    /// to whichever worker answers, and pays for a full handshake when that is
    /// the wrong one.
    ///
    /// This pins the cost of `reuse_port` so it is visible rather than
    /// folklore. It will start failing if workers ever gain a shared ticket
    /// key — at which point the assertion, and the caveat in `load_tls_config`,
    /// should be inverted.
    #[tokio::test]
    async fn test_tls_tickets_do_not_resume_across_workers() {
        let pki = SharedPki::generate();
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
        let echo = MockEchoServer::start();

        // Two workers on separate ports, each with its own TLS config — the
        // same independence two processes behind one reuse_port socket have,
        // without depending on the kernel to steer connections.
        let addr_a = free_addr().await;
        let addr_b = free_addr().await;
        let _worker_a = Worker::spawn(&pki, addr_a, fallback.addr, false).await;
        let _worker_b = Worker::spawn(&pki, addr_b, fallback.addr, false).await;
        tokio::time::sleep(Duration::from_millis(500)).await;

        // One client config, so its session cache spans both workers: rustls
        // keys that cache by server name, and both answer to "localhost".
        let connector = pki.connector();
        let server_name = ServerName::try_from("localhost").unwrap();
        let header = connect_header(&sha224_hex(PASSWORD), echo.addr);

        let first =
            handshake_kind_after_round_trip(&connector, &server_name, addr_a, &header).await;
        assert_eq!(
            first,
            Some(rustls::HandshakeKind::Full),
            "the first handshake has nothing to resume from"
        );

        let same_worker =
            handshake_kind_after_round_trip(&connector, &server_name, addr_a, &header).await;
        assert_eq!(
            same_worker,
            Some(rustls::HandshakeKind::Resumed),
            "a worker must resume the ticket it issued itself"
        );

        let other_worker =
            handshake_kind_after_round_trip(&connector, &server_name, addr_b, &header).await;
        assert_eq!(
            other_worker,
            Some(rustls::HandshakeKind::Full),
            "a ticket from another worker must not resume — workers hold independent keys"
        );
    }
}

// ============================================================================
// Config Surface Tests
// ============================================================================
//
// Knobs that change how connections are accepted or bounded. Each is a
// documented option that a deployment can turn on and, until now, discover
// broken in production rather than in CI.

mod config_surface_tests {
    use super::*;
    use rustls::pki_types::{PrivateKeyDer, PrivatePkcs8KeyDer};
    use trojan_config::{FallbackPoolConfig, ResourceLimitsConfig, UserEntry};
    use trojan_server::{CancellationToken, run_with_shutdown};

    const PASSWORD: &str = "test_password_123";

    /// A server whose `Config` is adjusted by the caller before start, so each
    /// test exercises one knob without restating the whole thing.
    struct ConfiguredServer {
        addr: SocketAddr,
        cert_der: Vec<u8>,
        shutdown: CancellationToken,
        _handle: tokio::task::JoinHandle<()>,
        _temp_dir: tempfile::TempDir,
    }

    impl ConfiguredServer {
        /// `adjust` also receives the temp directory, for options that need a
        /// file on disk (a client CA, say).
        async fn start(
            fallback_addr: SocketAddr,
            adjust: impl FnOnce(&mut Config, &std::path::Path),
        ) -> Self {
            let (cert_pem, key_pem) = generate_test_certs();
            let temp_dir = tempfile::Builder::new()
                .prefix("trojan-config-test-")
                .tempdir()
                .unwrap();
            let cert_path = temp_dir.path().join("cert.pem");
            let key_path = temp_dir.path().join("key.pem");
            fs::write(&cert_path, &cert_pem).unwrap();
            fs::write(&key_path, &key_pem).unwrap();

            let cert_der = rustls_pemfile::certs(&mut cert_pem.as_bytes())
                .next()
                .unwrap()
                .unwrap()
                .to_vec();

            let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
            let addr = listener.local_addr().unwrap();
            drop(listener);

            let mut config = Config {
                server: ServerConfig {
                    listen: addr.to_string(),
                    fallback: fallback_addr.to_string(),
                    tcp_idle_timeout_secs: 30,
                    udp_timeout_secs: 30,
                    max_udp_payload: 8192,
                    max_udp_buffer_bytes: 65536,
                    max_header_bytes: 8192,
                    max_connections: None,
                    rate_limit: None,
                    fallback_pool: None,
                    resource_limits: None,
                    tcp: TcpConfig::default(),
                    outbounds: Default::default(),
                    rule_providers: Default::default(),
                    rules: Default::default(),
                    geoip: None,
                    proxy_protocol: Default::default(),
                },
                tls: TlsConfig {
                    cert: cert_path.to_string_lossy().into_owned(),
                    key: key_path.to_string_lossy().into_owned(),
                    alpn: vec![],
                    min_version: TlsVersion::Tls12,
                    max_version: TlsVersion::Tls13,
                    client_ca: None,
                    cipher_suites: vec![],
                },
                auth: AuthConfig {
                    passwords: vec![PASSWORD.to_string()],
                    users: vec![],
                    ..Default::default()
                },
                websocket: WebSocketConfig::default(),
                metrics: MetricsConfig {
                    listen: None,
                    ..Default::default()
                },
                analytics: Default::default(),
                logging: LoggingConfig {
                    level: Some("warn".to_string()),
                    ..Default::default()
                },
                dns: Default::default(),
                ddns: Default::default(),
            };
            adjust(&mut config, temp_dir.path());

            let mut passwords = config.auth.passwords.clone();
            passwords.extend(config.auth.users.iter().map(|u| u.password.clone()));
            let auth = MemoryAuth::from_passwords(&passwords);

            let shutdown = CancellationToken::new();
            let token = shutdown.clone();
            let handle = tokio::spawn(async move {
                let _ = run_with_shutdown(config, auth, token).await;
            });
            tokio::time::sleep(Duration::from_millis(500)).await;

            Self {
                addr,
                cert_der,
                shutdown,
                _handle: handle,
                _temp_dir: temp_dir,
            }
        }

        fn root_store(&self) -> RootCertStore {
            let mut store = RootCertStore::empty();
            store
                .add(CertificateDer::from(self.cert_der.clone()))
                .unwrap();
            store
        }

        fn connector(&self) -> TlsConnector {
            TlsConnector::from(Arc::new(
                ClientConfig::builder()
                    .with_root_certificates(self.root_store())
                    .with_no_client_auth(),
            ))
        }

        async fn tcp(&self) -> tokio::net::TcpStream {
            tokio::net::TcpStream::connect(self.addr).await.unwrap()
        }

        async fn tls(&self) -> tokio_rustls::client::TlsStream<tokio::net::TcpStream> {
            let name = ServerName::try_from("localhost").unwrap();
            self.connector()
                .connect(name, self.tcp().await)
                .await
                .unwrap()
        }
    }

    impl Drop for ConfiguredServer {
        fn drop(&mut self) {
            self.shutdown.cancel();
        }
    }

    /// Relay a payload and assert it comes back, to prove a connection is fully
    /// usable and not merely established.
    async fn assert_relay_works<S>(stream: &mut S, hash: &str, target: SocketAddr)
    where
        S: tokio::io::AsyncRead + tokio::io::AsyncWrite + Unpin,
    {
        let payload = b"config-surface-probe";
        let mut header = connect_header(hash, target);
        header.extend_from_slice(payload);
        stream.write_all(&header).await.unwrap();
        stream.flush().await.unwrap();

        let mut echoed = vec![0u8; payload.len()];
        tokio::time::timeout(Duration::from_secs(10), stream.read_exact(&mut echoed))
            .await
            .expect("relay timeout")
            .unwrap();
        assert_eq!(&echoed[..], payload);
    }

    // ── mTLS ──

    struct ClientPki {
        ca_pem: String,
        chain: Vec<CertificateDer<'static>>,
        key: PrivateKeyDer<'static>,
    }

    /// A CA plus a client certificate it signed.
    fn generate_client_pki() -> ClientPki {
        use rcgen::{
            BasicConstraints, CertificateParams, IsCa, Issuer, KeyPair, KeyUsagePurpose,
            PKCS_ECDSA_P256_SHA256,
        };

        let ca_key = KeyPair::generate_for(&PKCS_ECDSA_P256_SHA256).unwrap();
        let mut ca_params = CertificateParams::default();
        ca_params.is_ca = IsCa::Ca(BasicConstraints::Unconstrained);
        ca_params.key_usages = vec![KeyUsagePurpose::KeyCertSign, KeyUsagePurpose::CrlSign];
        let ca_cert = ca_params.self_signed(&ca_key).unwrap();

        let client_key = KeyPair::generate_for(&PKCS_ECDSA_P256_SHA256).unwrap();
        let mut client_params = CertificateParams::default();
        client_params.subject_alt_names =
            vec![rcgen::SanType::DnsName("test-client".try_into().unwrap())];
        let issuer = Issuer::from_params(&ca_params, &ca_key);
        let client_cert = client_params.signed_by(&client_key, &issuer).unwrap();

        ClientPki {
            ca_pem: ca_cert.pem(),
            chain: vec![CertificateDer::from(client_cert.der().to_vec())],
            key: PrivateKeyDer::Pkcs8(PrivatePkcs8KeyDer::from(client_key.serialize_der())),
        }
    }

    /// With `tls.client_ca` set, a client holding a certificate from that CA is
    /// admitted and can relay.
    #[tokio::test]
    async fn test_mtls_accepts_certificate_from_configured_ca() {
        let echo = MockEchoServer::start();
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
        let pki = generate_client_pki();
        let ca_pem = pki.ca_pem.clone();

        let server = ConfiguredServer::start(fallback.addr, move |config, dir| {
            let ca_path = dir.join("client-ca.pem");
            fs::write(&ca_path, &ca_pem).unwrap();
            config.tls.client_ca = Some(ca_path.to_string_lossy().into_owned());
        })
        .await;

        let client_config = ClientConfig::builder()
            .with_root_certificates(server.root_store())
            .with_client_auth_cert(pki.chain, pki.key)
            .unwrap();
        let connector = TlsConnector::from(Arc::new(client_config));
        let name = ServerName::try_from("localhost").unwrap();
        let mut tls = connector.connect(name, server.tcp().await).await.unwrap();

        assert_relay_works(&mut tls, &sha224_hex(PASSWORD), echo.addr).await;
    }

    /// The same server must turn away a client that presents no certificate —
    /// otherwise `client_ca` is decorative.
    #[tokio::test]
    async fn test_mtls_rejects_client_without_certificate() {
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
        let pki = generate_client_pki();
        let ca_pem = pki.ca_pem.clone();

        let server = ConfiguredServer::start(fallback.addr, move |config, dir| {
            let ca_path = dir.join("client-ca.pem");
            fs::write(&ca_path, &ca_pem).unwrap();
            config.tls.client_ca = Some(ca_path.to_string_lossy().into_owned());
        })
        .await;

        // A TLS 1.3 client finishes its side before the server validates, so
        // the rejection can surface either at handshake or on first use. The
        // outer timeout matters: if the server were to accept the connection,
        // the read would simply block, and without it this would hang rather
        // than fail.
        let name = ServerName::try_from("localhost").unwrap();
        let outcome = tokio::time::timeout(Duration::from_secs(10), async {
            let mut tls = server
                .connector()
                .connect(name, server.tcp().await)
                .await
                .map_err(|e| e.to_string())?;
            tls.write_all(b"x").await.map_err(|e| e.to_string())?;
            tls.flush().await.map_err(|e| e.to_string())?;
            let mut buf = [0u8; 1];
            tls.read_exact(&mut buf).await.map_err(|e| e.to_string())?;
            Ok::<(), String>(())
        })
        .await
        .expect("a client with no certificate was served instead of rejected");

        outcome.expect_err("a client with no certificate must not be served");
    }

    // ── TLS negotiation knobs ──

    /// Configured ALPN protocols are offered and negotiated.
    #[tokio::test]
    async fn test_alpn_protocol_is_negotiated() {
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
        let server = ConfiguredServer::start(fallback.addr, |config, _dir| {
            config.tls.alpn = vec!["h2".to_string(), "http/1.1".to_string()];
        })
        .await;

        let mut client_config = ClientConfig::builder()
            .with_root_certificates(server.root_store())
            .with_no_client_auth();
        client_config.alpn_protocols = vec![b"http/1.1".to_vec()];

        let connector = TlsConnector::from(Arc::new(client_config));
        let name = ServerName::try_from("localhost").unwrap();
        let tls = connector.connect(name, server.tcp().await).await.unwrap();

        assert_eq!(
            tls.get_ref().1.alpn_protocol(),
            Some(b"http/1.1".as_slice()),
            "server did not negotiate the ALPN protocol it advertises"
        );
    }

    /// `tls.cipher_suites` restricts the handshake to what it names.
    ///
    /// Deliberately picks ChaCha20, which sits *third* in rustls' default
    /// preference order: were the setting ignored, AES-256 would win and this
    /// would fail. Asserting the default-first suite would prove nothing.
    #[tokio::test]
    async fn test_cipher_suite_restriction_is_honoured() {
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
        let server = ConfiguredServer::start(fallback.addr, |config, _dir| {
            config.tls.min_version = TlsVersion::Tls13;
            config.tls.cipher_suites = vec!["TLS13_CHACHA20_POLY1305_SHA256".to_string()];
        })
        .await;

        let tls = server.tls().await;
        let suite = tls
            .get_ref()
            .1
            .negotiated_cipher_suite()
            .expect("a suite must be negotiated");

        assert_eq!(
            format!("{:?}", suite.suite()),
            "TLS13_CHACHA20_POLY1305_SHA256",
            "server negotiated a suite outside the configured list"
        );
    }

    // ── Bounds ──

    /// A header that keeps growing past `max_header_bytes` is handed to the
    /// fallback rather than buffered without limit.
    #[tokio::test]
    async fn test_header_over_max_falls_back() {
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback OK");
        let server = ConfiguredServer::start(fallback.addr, |config, _dir| {
            config.server.max_header_bytes = 200;
        })
        .await;

        let mut tls = server.tls().await;

        // Valid hex hash and CRLF, then a domain ATYP promising 255 bytes of
        // which only some arrive. The parse stays *Incomplete* — never
        // Invalid — so the only thing that can end this is the size limit.
        // Sending enough to complete or corrupt the header instead would make
        // this pass for the wrong reason.
        let mut header = Vec::new();
        header.extend_from_slice(sha224_hex(PASSWORD).as_bytes());
        header.extend_from_slice(b"\r\n");
        header.push(0x01); // CONNECT
        header.push(0x03); // domain
        header.push(0xFF); // promises 255 bytes
        header.extend_from_slice(&[b'a'; 150]); // ...only 150 arrive
        assert!(
            header.len() > 200,
            "the probe must exceed max_header_bytes to trigger the limit"
        );

        tls.write_all(&header).await.unwrap();
        tls.flush().await.unwrap();

        let mut body = Vec::new();
        tokio::time::timeout(Duration::from_secs(10), tls.read_to_end(&mut body))
            .await
            .expect("timed out — an oversized header was buffered instead of falling back")
            .unwrap();

        let body = String::from_utf8_lossy(&body);
        assert!(body.contains("Fallback OK"), "unexpected body: {body:?}");
    }

    /// A UDP frame claiming more than `max_udp_payload` ends the association
    /// instead of being relayed.
    #[tokio::test]
    async fn test_udp_payload_over_max_ends_association() {
        let udp_echo = MockUdpEchoServer::start();
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
        let server = ConfiguredServer::start(fallback.addr, |config, _dir| {
            config.server.max_udp_payload = 512;
        })
        .await;

        let mut tls = server.tls().await;
        let ip = match udp_echo.addr.ip() {
            std::net::IpAddr::V4(v4) => v4,
            other => panic!("expected IPv4, got {other}"),
        };
        let target = AddressRef {
            host: HostRef::Ipv4(ip.octets()),
            port: udp_echo.addr.port(),
        };

        let mut header = BytesMut::new();
        write_request_header(
            &mut header,
            sha224_hex(PASSWORD).as_bytes(),
            CMD_UDP_ASSOCIATE,
            &target,
        )
        .unwrap();
        tls.write_all(&header).await.unwrap();

        let mut oversized = BytesMut::new();
        write_udp_packet(&mut oversized, &target, &vec![0u8; 4096]).unwrap();
        tls.write_all(&oversized).await.unwrap();
        tls.flush().await.unwrap();

        let mut sink = Vec::new();
        let result = tokio::time::timeout(Duration::from_secs(10), tls.read_to_end(&mut sink))
            .await
            .expect("timed out — an oversized UDP payload was neither relayed nor refused");

        // Either a clean close or an abrupt one is acceptable; being echoed
        // back is not.
        match result {
            Ok(_) => assert!(
                sink.is_empty(),
                "oversized UDP payload should not be relayed, got {} bytes",
                sink.len()
            ),
            Err(_) => { /* connection torn down — also a refusal */ }
        }
    }

    /// Every TCP socket option enabled at once must still yield a working
    /// listener.
    ///
    /// None of these are observable from a client — they are `setsockopt`
    /// calls — so the only thing worth asserting is that turning them on does
    /// not break the server. `create_listener` propagates a failed
    /// `setsockopt` as an error, which would take the listener down; TCP Fast
    /// Open only warns. Without this, a platform where one of them is
    /// unsupported fails at startup with no test to catch it.
    #[tokio::test]
    async fn test_all_tcp_options_enabled_still_serves() {
        let echo = MockEchoServer::start();
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
        let server = ConfiguredServer::start(fallback.addr, |config, _dir| {
            config.server.tcp = TcpConfig {
                no_delay: true,
                keepalive_secs: 30,
                reuse_port: true,
                fast_open: true,
                fast_open_qlen: 16,
                ..Default::default()
            };
        })
        .await;

        let mut tls = server.tls().await;
        assert_relay_works(&mut tls, &sha224_hex(PASSWORD), echo.addr).await;
    }

    // ── DNS ──

    /// A minimal UDP nameserver that answers every A query with 127.0.0.1.
    ///
    /// Hand-rolled rather than pulled from hickory: the point is to prove the
    /// server actually talks to the configured nameserver over the wire, which
    /// a stub sharing the resolver's own code would not.
    struct MockDnsServer {
        addr: SocketAddr,
        queries: Arc<std::sync::atomic::AtomicUsize>,
        _handle: thread::JoinHandle<()>,
    }

    impl MockDnsServer {
        fn start() -> Self {
            let socket = std::net::UdpSocket::bind("127.0.0.1:0").unwrap();
            let addr = socket.local_addr().unwrap();
            let queries = Arc::new(std::sync::atomic::AtomicUsize::new(0));
            let counter = Arc::clone(&queries);

            let handle = thread::spawn(move || {
                let mut buf = [0u8; 512];
                while let Ok((n, src)) = socket.recv_from(&mut buf) {
                    if n < 12 {
                        continue;
                    }

                    // Walk the QNAME labels to find where the question ends.
                    // Echoing to `n` instead would drag in the EDNS0 OPT
                    // record hickory appends, corrupting the reply.
                    let mut pos = 12;
                    while pos < n && buf[pos] != 0 {
                        pos += 1 + buf[pos] as usize;
                    }
                    let question_end = pos + 1 + 4; // root label + QTYPE + QCLASS
                    if question_end > n {
                        continue;
                    }
                    counter.fetch_add(1, std::sync::atomic::Ordering::SeqCst);

                    let mut response = Vec::with_capacity(question_end + 16);
                    response.extend_from_slice(&buf[0..2]); // transaction id
                    response.extend_from_slice(&[0x81, 0x80]); // response, recursion available
                    response.extend_from_slice(&[0x00, 0x01]); // QDCOUNT
                    response.extend_from_slice(&[0x00, 0x01]); // ANCOUNT
                    response.extend_from_slice(&[0x00, 0x00]); // NSCOUNT
                    response.extend_from_slice(&[0x00, 0x00]); // ARCOUNT
                    response.extend_from_slice(&buf[12..question_end]);

                    response.extend_from_slice(&[0xC0, 0x0C]); // name: pointer to question
                    response.extend_from_slice(&[0x00, 0x01]); // type A
                    response.extend_from_slice(&[0x00, 0x01]); // class IN
                    response.extend_from_slice(&[0x00, 0x00, 0x00, 0x3C]); // TTL 60
                    response.extend_from_slice(&[0x00, 0x04]); // RDLENGTH
                    response.extend_from_slice(&[127, 0, 0, 1]); // RDATA

                    let _ = socket.send_to(&response, src);
                }
            });

            Self {
                addr,
                queries,
                _handle: handle,
            }
        }
    }

    /// With `dns.strategy = "custom"`, domain targets are resolved through the
    /// configured nameservers rather than the host's.
    ///
    /// Asserts the mock was actually queried, so a server that quietly fell
    /// back to the system resolver — which also resolves nothing useful for a
    /// made-up name, and would simply fail — cannot pass.
    #[tokio::test]
    async fn test_custom_dns_servers_are_used_for_resolution() {
        let echo = MockEchoServer::start();
        let dns = MockDnsServer::start();
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

        let dns_addr = dns.addr;
        let server = ConfiguredServer::start(fallback.addr, move |config, _dir| {
            config.dns.strategy = trojan_dns::DnsStrategy::Custom;
            config.dns.servers = vec![format!("udp://{dns_addr}")];
            config.dns.prefer_ipv4 = true;
        })
        .await;

        // Deliberately not a special-use TLD: hickory answers `.invalid` and
        // friends locally per RFC 6761 and never sends a query, which would
        // make this test pass or fail without involving the nameserver at all.
        // The mock answers 127.0.0.1 and the port comes from the request, so
        // this lands on the echo server.
        let mut tls = server.tls().await;
        let address = AddressRef {
            host: HostRef::Domain(b"resolved-by-mock.example.com"),
            port: echo.addr.port(),
        };
        let mut header = BytesMut::new();
        write_request_header(
            &mut header,
            sha224_hex(PASSWORD).as_bytes(),
            CMD_CONNECT,
            &address,
        )
        .unwrap();
        let payload = b"custom-dns-payload";
        header.extend_from_slice(payload);

        tls.write_all(&header).await.unwrap();
        tls.flush().await.unwrap();

        let mut echoed = vec![0u8; payload.len()];
        tokio::time::timeout(Duration::from_secs(10), tls.read_exact(&mut echoed))
            .await
            .expect("timed out — the custom nameserver was not used or did not answer")
            .unwrap();
        assert_eq!(&echoed[..], payload);

        assert!(
            dns.queries.load(std::sync::atomic::Ordering::SeqCst) > 0,
            "the configured nameserver was never queried"
        );
    }

    // ── Optional subsystems ──

    /// With a warm fallback pool configured, fallback traffic is still served
    /// correctly across enough connections to exhaust and refill the pool.
    #[tokio::test]
    async fn test_fallback_pool_serves_repeated_fallbacks() {
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nPooled Fallback");
        let server = ConfiguredServer::start(fallback.addr, |config, _dir| {
            config.server.fallback_pool = Some(FallbackPoolConfig {
                max_idle: 2,
                max_age_secs: 60,
                fill_batch: 2,
                fill_delay_ms: 0,
            });
        })
        .await;

        let request =
            b"GET /this-is-a-long-path-to-make-the-request-longer HTTP/1.1\r\nHost: localhost\r\n\r\n";

        for i in 0..5 {
            let mut tls = server.tls().await;
            tls.write_all(request).await.unwrap();
            tls.flush().await.unwrap();

            let mut body = Vec::new();
            tokio::time::timeout(Duration::from_secs(10), tls.read_to_end(&mut body))
                .await
                .unwrap_or_else(|_| panic!("fallback {i} timed out"))
                .unwrap();
            let body = String::from_utf8_lossy(&body);
            assert!(
                body.contains("Pooled Fallback"),
                "fallback {i} returned {body:?}"
            );
        }
    }

    /// A relay buffer far smaller than the payload must still move it intact.
    ///
    /// `resource_limits.relay_buffer_size` is tunable, and shrinking it changes
    /// how many read/write/flush cycles a transfer takes. A 1 KiB buffer turns
    /// a 512 KiB transfer into hundreds of cycles per direction, which is where
    /// an off-by-one in the copy state machine would show up.
    #[tokio::test]
    async fn test_small_relay_buffer_still_transfers_intact() {
        const TRANSFER_BYTES: usize = 512 * 1024;

        let echo = MockEchoServer::start();
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
        let server = ConfiguredServer::start(fallback.addr, |config, _dir| {
            config.server.resource_limits = Some(ResourceLimitsConfig {
                relay_buffer_size: 1024,
                tcp_send_buffer: 0,
                tcp_recv_buffer: 0,
                connection_backlog: 128,
            });
        })
        .await;

        let tls = server.tls().await;
        let header = connect_header(&sha224_hex(PASSWORD), echo.addr);
        let payload: Vec<u8> = (0..=250u8).cycle().take(TRANSFER_BYTES).collect();

        let (mut reader, mut writer) = tokio::io::split(tls);
        let to_send = payload.clone();
        let write_task = tokio::spawn(async move {
            writer.write_all(&header).await.unwrap();
            writer.write_all(&to_send).await.unwrap();
            writer.flush().await.unwrap();
        });

        let mut received = vec![0u8; TRANSFER_BYTES];
        tokio::time::timeout(Duration::from_secs(120), reader.read_exact(&mut received))
            .await
            .expect("timed out — a small relay buffer stalled the transfer")
            .expect("stream truncated");
        write_task.await.unwrap();

        assert_eq!(
            first_difference(&received, &payload),
            None,
            "payload corrupted with a 1 KiB relay buffer"
        );
    }

    /// Passwords declared under `auth.users` authenticate like plain ones —
    /// this is the path that carries a user id for traffic accounting.
    #[tokio::test]
    async fn test_auth_user_entry_password_is_accepted() {
        let echo = MockEchoServer::start();
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
        let server = ConfiguredServer::start(fallback.addr, |config, _dir| {
            config.auth.passwords.clear();
            config.auth.users = vec![UserEntry {
                id: "alice".to_string(),
                password: "alice-secret".to_string(),
            }];
        })
        .await;

        let mut tls = server.tls().await;
        assert_relay_works(&mut tls, &sha224_hex("alice-secret"), echo.addr).await;
    }
}

// ============================================================================
// WebSocket Transport Tests
// ============================================================================
//
// The server can carry trojan inside WebSocket frames, either sharing the TLS
// port with raw trojan ("mixed", where the first bytes decide) or on a
// dedicated port ("split"). Both go through a different read path than raw
// trojan — protocol sniffing, an HTTP upgrade, then frame-based I/O — and
// neither had any end-to-end coverage. The relay-crate ws tests exercise
// `trojan-transport`, which is a separate implementation.

#[cfg(feature = "ws")]
mod websocket_tests {
    use super::*;
    use tokio_tungstenite::tungstenite::client::IntoClientRequest;
    use trojan_config::WebSocketMode;
    use trojan_server::ws::WsIo;
    use trojan_server::{CancellationToken, run_with_shutdown};

    const PASSWORD: &str = "test_password_123";

    struct WsTestServer {
        addr: SocketAddr,
        ws_addr: SocketAddr,
        tls_connector: TlsConnector,
        shutdown: CancellationToken,
        _handle: tokio::task::JoinHandle<()>,
        _temp_dir: tempfile::TempDir,
    }

    impl WsTestServer {
        /// `ws` is applied verbatim, except that `listen` is filled in with a
        /// reserved port so split mode has somewhere to bind.
        async fn start(fallback_addr: SocketAddr, mut ws: WebSocketConfig) -> Self {
            let (cert_pem, key_pem) = generate_test_certs();
            let temp_dir = tempfile::Builder::new()
                .prefix("trojan-ws-test-")
                .tempdir()
                .unwrap();
            let cert_path = temp_dir.path().join("cert.pem");
            let key_path = temp_dir.path().join("key.pem");
            fs::write(&cert_path, &cert_pem).unwrap();
            fs::write(&key_path, &key_pem).unwrap();

            let cert_der = rustls_pemfile::certs(&mut cert_pem.as_bytes())
                .next()
                .unwrap()
                .unwrap()
                .to_vec();
            let mut root_store = RootCertStore::empty();
            root_store.add(CertificateDer::from(cert_der)).unwrap();
            let tls_connector = TlsConnector::from(Arc::new(
                ClientConfig::builder()
                    .with_root_certificates(root_store)
                    .with_no_client_auth(),
            ));

            // Reserve both ports before either is bound.
            let main_listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
            let addr = main_listener.local_addr().unwrap();
            let ws_listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
            let ws_addr = ws_listener.local_addr().unwrap();
            drop(main_listener);
            drop(ws_listener);
            ws.listen = Some(ws_addr.to_string());

            let config = Config {
                server: ServerConfig {
                    listen: addr.to_string(),
                    fallback: fallback_addr.to_string(),
                    tcp_idle_timeout_secs: 30,
                    udp_timeout_secs: 30,
                    max_udp_payload: 8192,
                    max_udp_buffer_bytes: 65536,
                    max_header_bytes: 8192,
                    max_connections: None,
                    rate_limit: None,
                    fallback_pool: None,
                    resource_limits: None,
                    tcp: TcpConfig::default(),
                    outbounds: Default::default(),
                    rule_providers: Default::default(),
                    rules: Default::default(),
                    geoip: None,
                    proxy_protocol: Default::default(),
                },
                tls: TlsConfig {
                    cert: cert_path.to_string_lossy().into_owned(),
                    key: key_path.to_string_lossy().into_owned(),
                    alpn: vec![],
                    min_version: TlsVersion::Tls12,
                    max_version: TlsVersion::Tls13,
                    client_ca: None,
                    cipher_suites: vec![],
                },
                auth: AuthConfig {
                    passwords: vec![PASSWORD.to_string()],
                    users: vec![],
                    ..Default::default()
                },
                websocket: ws,
                metrics: MetricsConfig {
                    listen: None,
                    ..Default::default()
                },
                analytics: Default::default(),
                logging: LoggingConfig {
                    level: Some("warn".to_string()),
                    ..Default::default()
                },
                dns: Default::default(),
                ddns: Default::default(),
            };

            let auth = MemoryAuth::from_passwords(&config.auth.passwords);
            let shutdown = CancellationToken::new();
            let token = shutdown.clone();
            let handle = tokio::spawn(async move {
                let _ = run_with_shutdown(config, auth, token).await;
            });
            tokio::time::sleep(Duration::from_millis(500)).await;

            Self {
                addr,
                ws_addr,
                tls_connector,
                shutdown,
                _handle: handle,
                _temp_dir: temp_dir,
            }
        }

        fn hash(&self) -> String {
            sha224_hex(PASSWORD)
        }

        async fn tls(
            &self,
            addr: SocketAddr,
        ) -> tokio_rustls::client::TlsStream<tokio::net::TcpStream> {
            let tcp = tokio::net::TcpStream::connect(addr).await.unwrap();
            let name = ServerName::try_from("localhost").unwrap();
            self.tls_connector.connect(name, tcp).await.unwrap()
        }
    }

    impl Drop for WsTestServer {
        fn drop(&mut self) {
            self.shutdown.cancel();
        }
    }

    fn ws_config(mode: WebSocketMode, path: &str) -> WebSocketConfig {
        WebSocketConfig {
            enabled: true,
            mode,
            path: path.to_string(),
            host: None,
            listen: None,
            max_frame_bytes: 1 << 20,
        }
    }

    /// Upgrade to WebSocket, then relay a payload through the tunnel and back.
    async fn relay_over_websocket(server: &WsTestServer, addr: SocketAddr, path: &str) {
        let echo = MockEchoServer::start();
        let tls = server.tls(addr).await;

        let request = format!("ws://localhost{path}")
            .into_client_request()
            .unwrap();
        let (ws_stream, _response) = tokio_tungstenite::client_async(request, tls)
            .await
            .expect("websocket upgrade rejected");

        let mut io = WsIo::new(ws_stream);
        let mut header = connect_header(&server.hash(), echo.addr);
        let payload = b"payload-over-websocket";
        header.extend_from_slice(payload);

        io.write_all(&header).await.unwrap();
        io.flush().await.unwrap();

        let mut echoed = vec![0u8; payload.len()];
        tokio::time::timeout(Duration::from_secs(10), io.read_exact(&mut echoed))
            .await
            .expect("timed out relaying over websocket")
            .unwrap();
        assert_eq!(&echoed[..], payload);
    }

    /// Mixed mode: a WebSocket upgrade on the main TLS port carries trojan.
    #[tokio::test]
    async fn test_ws_mixed_upgrade_relays_trojan() {
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
        let server = WsTestServer::start(fallback.addr, ws_config(WebSocketMode::Mixed, "/")).await;
        let addr = server.addr;
        relay_over_websocket(&server, addr, "/").await;
    }

    /// Mixed mode must still accept raw trojan on the same port — that is the
    /// whole point of sniffing rather than committing to one framing.
    #[tokio::test]
    async fn test_ws_mixed_raw_trojan_still_works() {
        let echo = MockEchoServer::start();
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
        let server = WsTestServer::start(fallback.addr, ws_config(WebSocketMode::Mixed, "/")).await;

        let mut tls = server.tls(server.addr).await;
        let mut header = connect_header(&server.hash(), echo.addr);
        let payload = b"raw-trojan-on-mixed-port";
        header.extend_from_slice(payload);

        tls.write_all(&header).await.unwrap();
        tls.flush().await.unwrap();

        let mut echoed = vec![0u8; payload.len()];
        tokio::time::timeout(Duration::from_secs(10), tls.read_exact(&mut echoed))
            .await
            .expect("timed out on raw trojan over a mixed-mode port")
            .unwrap();
        assert_eq!(&echoed[..], payload);
    }

    /// Plain HTTP that is not an upgrade is ordinary cover traffic and must
    /// reach the fallback, not be rejected.
    #[tokio::test]
    async fn test_ws_mixed_plain_http_falls_back() {
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback OK");
        let server = WsTestServer::start(fallback.addr, ws_config(WebSocketMode::Mixed, "/")).await;

        let mut tls = server.tls(server.addr).await;
        tls.write_all(b"GET /some/ordinary/page HTTP/1.1\r\nHost: localhost\r\n\r\n")
            .await
            .unwrap();
        tls.flush().await.unwrap();

        let mut body = Vec::new();
        tokio::time::timeout(Duration::from_secs(10), tls.read_to_end(&mut body))
            .await
            .expect("fallback read timeout")
            .unwrap();
        let body = String::from_utf8_lossy(&body);
        assert!(body.contains("Fallback OK"), "unexpected body: {body:?}");
    }

    /// An upgrade on the wrong path is rejected rather than tunnelled.
    #[tokio::test]
    async fn test_ws_mixed_wrong_path_rejected() {
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
        let server =
            WsTestServer::start(fallback.addr, ws_config(WebSocketMode::Mixed, "/secret")).await;

        let tls = server.tls(server.addr).await;
        let request = "ws://localhost/wrong-path".into_client_request().unwrap();
        let result = tokio_tungstenite::client_async(request, tls).await;

        assert!(
            result.is_err(),
            "an upgrade on an unconfigured path must not succeed"
        );
    }

    /// The configured path is what gets accepted, including with a query.
    #[tokio::test]
    async fn test_ws_mixed_configured_path_accepted() {
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
        let server =
            WsTestServer::start(fallback.addr, ws_config(WebSocketMode::Mixed, "/secret")).await;
        let addr = server.addr;
        // The query string is stripped before matching.
        relay_over_websocket(&server, addr, "/secret?token=abc").await;
    }

    /// Split mode: WebSocket lives on its own port and carries trojan there.
    #[tokio::test]
    async fn test_ws_split_upgrade_relays_trojan() {
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
        let server = WsTestServer::start(fallback.addr, ws_config(WebSocketMode::Split, "/")).await;
        let ws_addr = server.ws_addr;
        relay_over_websocket(&server, ws_addr, "/").await;
    }

    /// The split-mode port speaks WebSocket only; anything else is refused
    /// rather than falling back or being treated as raw trojan.
    #[tokio::test]
    async fn test_ws_split_rejects_non_websocket() {
        let echo = MockEchoServer::start();
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
        let server = WsTestServer::start(fallback.addr, ws_config(WebSocketMode::Split, "/")).await;

        let mut tls = server.tls(server.ws_addr).await;
        let header = connect_header(&server.hash(), echo.addr);
        tls.write_all(&header).await.unwrap();
        tls.flush().await.unwrap();

        let mut response = Vec::new();
        tokio::time::timeout(Duration::from_secs(10), tls.read_to_end(&mut response))
            .await
            .expect("read timeout on the websocket-only port")
            .unwrap();

        let response = String::from_utf8_lossy(&response);
        assert!(
            response.contains("400"),
            "expected a 400 on the websocket-only port, got {response:?}"
        );
    }

    /// Split mode leaves the main port speaking raw trojan.
    #[tokio::test]
    async fn test_ws_split_main_port_still_raw_trojan() {
        let echo = MockEchoServer::start();
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
        let server = WsTestServer::start(fallback.addr, ws_config(WebSocketMode::Split, "/")).await;

        let mut tls = server.tls(server.addr).await;
        let mut header = connect_header(&server.hash(), echo.addr);
        let payload = b"raw-trojan-on-split-main-port";
        header.extend_from_slice(payload);

        tls.write_all(&header).await.unwrap();
        tls.flush().await.unwrap();

        let mut echoed = vec![0u8; payload.len()];
        tokio::time::timeout(Duration::from_secs(10), tls.read_exact(&mut echoed))
            .await
            .expect("timed out on raw trojan over the split-mode main port")
            .unwrap();
        assert_eq!(&echoed[..], payload);
    }
}

// ============================================================================
// Rule-Based Routing Tests
// ============================================================================

#[cfg(feature = "rules")]
mod rules_tests {
    use super::*;
    use std::collections::HashMap;
    use trojan_config::{OutboundConfig, RouteRuleConfig, RuleProviderConfig};
    use trojan_server::{CancellationToken, run_with_shutdown};

    /// Assert that a TLS stream is closed (REJECT behavior).
    /// Accepts both clean EOF (n=0) and TLS close without close_notify.
    async fn assert_connection_rejected(
        tls_stream: &mut tokio_rustls::client::TlsStream<tokio::net::TcpStream>,
        msg: &str,
    ) {
        let mut buf = vec![0u8; 1024];
        let result = tokio::time::timeout(Duration::from_secs(5), tls_stream.read(&mut buf))
            .await
            .expect("read timeout");
        match result {
            Ok(0) => { /* clean EOF — expected for REJECT */ }
            Err(e) if e.kind() == std::io::ErrorKind::UnexpectedEof => {
                /* TLS close without close_notify — also expected for REJECT */
            }
            Ok(n) => panic!("{msg}: expected connection closed, got {n} bytes"),
            Err(e) => panic!("{msg}: unexpected error: {e}"),
        }
    }

    /// Helper to start a trojan server with custom rules config.
    struct RulesTestServer {
        addr: SocketAddr,
        password: String,
        tls_connector: TlsConnector,
        shutdown: CancellationToken,
        _handle: tokio::task::JoinHandle<()>,
        _temp_dir: tempfile::TempDir,
    }

    impl RulesTestServer {
        async fn start(
            fallback_addr: SocketAddr,
            outbounds: HashMap<String, OutboundConfig>,
            rules: Vec<RouteRuleConfig>,
            rule_providers: HashMap<String, RuleProviderConfig>,
        ) -> Self {
            let password = "test_password_123".to_string();
            let (cert_pem, key_pem) = generate_test_certs();

            let temp_dir = tempfile::Builder::new()
                .prefix("trojan-rules-test-")
                .tempdir()
                .unwrap();
            let cert_path = temp_dir.path().join("cert.pem");
            let key_path = temp_dir.path().join("key.pem");

            fs::write(&cert_path, &cert_pem).unwrap();
            fs::write(&key_path, &key_pem).unwrap();

            let cert_der = rustls_pemfile::certs(&mut cert_pem.as_bytes())
                .next()
                .unwrap()
                .unwrap()
                .to_vec();

            let mut root_store = RootCertStore::empty();
            root_store.add(CertificateDer::from(cert_der)).unwrap();
            let client_config = ClientConfig::builder()
                .with_root_certificates(root_store)
                .with_no_client_auth();
            let tls_connector = TlsConnector::from(Arc::new(client_config));

            let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
            let addr = listener.local_addr().unwrap();
            drop(listener);

            let config = Config {
                server: ServerConfig {
                    listen: addr.to_string(),
                    fallback: fallback_addr.to_string(),
                    tcp_idle_timeout_secs: 30,
                    udp_timeout_secs: 30,
                    max_udp_payload: 8192,
                    max_udp_buffer_bytes: 65536,
                    max_header_bytes: 8192,
                    max_connections: None,
                    rate_limit: None,
                    fallback_pool: None,
                    resource_limits: None,
                    tcp: TcpConfig::default(),
                    outbounds,
                    rule_providers,
                    rules,
                    geoip: None,
                    proxy_protocol: Default::default(),
                },
                tls: TlsConfig {
                    cert: cert_path.to_string_lossy().to_string(),
                    key: key_path.to_string_lossy().to_string(),
                    alpn: vec![],
                    min_version: TlsVersion::Tls12,
                    max_version: TlsVersion::Tls13,
                    client_ca: None,
                    cipher_suites: vec![],
                },
                auth: AuthConfig {
                    passwords: vec![password.clone()],
                    users: vec![],
                    ..Default::default()
                },
                websocket: WebSocketConfig::default(),
                metrics: MetricsConfig {
                    listen: None,
                    ..Default::default()
                },
                analytics: Default::default(),
                logging: LoggingConfig {
                    level: Some("debug".to_string()),
                    ..Default::default()
                },
                dns: Default::default(),
                ddns: Default::default(),
            };

            let auth = MemoryAuth::from_passwords(&config.auth.passwords);
            let shutdown = CancellationToken::new();
            let shutdown_task = shutdown.clone();

            let handle = tokio::spawn(async move {
                let _ = run_with_shutdown(config, auth, shutdown_task).await;
            });

            tokio::time::sleep(Duration::from_millis(500)).await;

            Self {
                addr,
                password,
                tls_connector,
                shutdown,
                _handle: handle,
                _temp_dir: temp_dir,
            }
        }

        fn hash(&self) -> String {
            sha224_hex(&self.password)
        }

        /// Connect a TLS stream and send a trojan CONNECT header targeting an IPv4 addr.
        async fn connect_to_ipv4(
            &self,
            target_addr: SocketAddr,
            payload: &[u8],
        ) -> tokio_rustls::client::TlsStream<tokio::net::TcpStream> {
            let tcp_stream = tokio::net::TcpStream::connect(self.addr).await.unwrap();
            let server_name = ServerName::try_from("localhost").unwrap();
            let mut tls_stream = self
                .tls_connector
                .connect(server_name, tcp_stream)
                .await
                .unwrap();

            let hash = self.hash();
            let ip: std::net::Ipv4Addr = match target_addr.ip() {
                std::net::IpAddr::V4(v4) => v4,
                _ => panic!("Expected IPv4"),
            };
            let addr = AddressRef {
                host: HostRef::Ipv4(ip.octets()),
                port: target_addr.port(),
            };

            let mut header = BytesMut::new();
            write_request_header(&mut header, hash.as_bytes(), CMD_CONNECT, &addr).unwrap();
            header.extend_from_slice(payload);

            tls_stream.write_all(&header).await.unwrap();
            tls_stream.flush().await.unwrap();
            tls_stream
        }

        /// Connect a TLS stream and send a trojan CONNECT header targeting a domain.
        async fn connect_to_domain(
            &self,
            domain: &str,
            port: u16,
            payload: &[u8],
        ) -> tokio_rustls::client::TlsStream<tokio::net::TcpStream> {
            let tcp_stream = tokio::net::TcpStream::connect(self.addr).await.unwrap();
            let server_name = ServerName::try_from("localhost").unwrap();
            let mut tls_stream = self
                .tls_connector
                .connect(server_name, tcp_stream)
                .await
                .unwrap();

            let hash = self.hash();
            let addr = AddressRef {
                host: HostRef::Domain(domain.as_bytes()),
                port,
            };

            let mut header = BytesMut::new();
            write_request_header(&mut header, hash.as_bytes(), CMD_CONNECT, &addr).unwrap();
            header.extend_from_slice(payload);

            tls_stream.write_all(&header).await.unwrap();
            tls_stream.flush().await.unwrap();
            tls_stream
        }

        async fn stop(self) {
            self.shutdown.cancel();
            let _ = self._handle.await;
        }
    }

    fn rule(rule_type: &str, value: Option<&str>, outbound: &str) -> RouteRuleConfig {
        RouteRuleConfig {
            rule_set: None,
            rule_type: Some(rule_type.to_string()),
            value: value.map(|v| v.to_string()),
            outbound: outbound.to_string(),
        }
    }

    fn rule_set_ref(name: &str, outbound: &str) -> RouteRuleConfig {
        RouteRuleConfig {
            rule_set: Some(name.to_string()),
            rule_type: None,
            value: None,
            outbound: outbound.to_string(),
        }
    }

    /// Test: REJECT rule blocks connection (domain match).
    #[tokio::test]
    async fn test_rules_reject_domain() {
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

        let rules = vec![
            rule("DOMAIN", Some("blocked.example.com"), "REJECT"),
            rule("FINAL", None, "DIRECT"),
        ];

        let server =
            RulesTestServer::start(fallback.addr, HashMap::new(), rules, HashMap::new()).await;

        let mut tls_stream = server
            .connect_to_domain("blocked.example.com", 443, b"")
            .await;

        assert_connection_rejected(&mut tls_stream, "REJECT rule should close connection").await;

        server.stop().await;
    }

    /// Test: IP-CIDR rule matches and routes to DIRECT.
    #[tokio::test]
    async fn test_rules_ip_cidr_direct() {
        let echo = MockEchoServer::start();
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

        let rules = vec![
            rule("IP-CIDR", Some("127.0.0.0/8"), "DIRECT"),
            rule("FINAL", None, "REJECT"),
        ];

        let server =
            RulesTestServer::start(fallback.addr, HashMap::new(), rules, HashMap::new()).await;

        let mut tls_stream = server.connect_to_ipv4(echo.addr, b"Hello Rules!").await;

        let mut buf = vec![0u8; 1024];
        let n = tokio::time::timeout(Duration::from_secs(5), tls_stream.read(&mut buf))
            .await
            .expect("read timeout")
            .unwrap();

        assert_eq!(
            &buf[..n],
            b"Hello Rules!",
            "IP-CIDR DIRECT should relay traffic"
        );

        server.stop().await;
    }

    /// Test: DST-PORT rule matches and routes to DIRECT.
    #[tokio::test]
    async fn test_rules_dst_port_direct() {
        let echo = MockEchoServer::start();
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

        let rules = vec![
            rule("DST-PORT", Some(&echo.addr.port().to_string()), "DIRECT"),
            rule("FINAL", None, "REJECT"),
        ];

        let server =
            RulesTestServer::start(fallback.addr, HashMap::new(), rules, HashMap::new()).await;

        let mut tls_stream = server.connect_to_ipv4(echo.addr, b"port match").await;

        let mut buf = vec![0u8; 1024];
        let n = tokio::time::timeout(Duration::from_secs(5), tls_stream.read(&mut buf))
            .await
            .expect("read timeout")
            .unwrap();

        assert_eq!(
            &buf[..n],
            b"port match",
            "DST-PORT DIRECT should relay traffic"
        );

        server.stop().await;
    }

    /// Test: FINAL rule as catch-all routes to DIRECT.
    #[tokio::test]
    async fn test_rules_final_catchall() {
        let echo = MockEchoServer::start();
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

        let rules = vec![rule("FINAL", None, "DIRECT")];

        let server =
            RulesTestServer::start(fallback.addr, HashMap::new(), rules, HashMap::new()).await;

        let mut tls_stream = server.connect_to_ipv4(echo.addr, b"final").await;

        let mut buf = vec![0u8; 1024];
        let n = tokio::time::timeout(Duration::from_secs(5), tls_stream.read(&mut buf))
            .await
            .expect("read timeout")
            .unwrap();

        assert_eq!(&buf[..n], b"final", "FINAL DIRECT should relay all traffic");

        server.stop().await;
    }

    /// Test: Named outbound with type "direct" routes traffic correctly.
    #[tokio::test]
    async fn test_rules_named_outbound_direct() {
        let echo = MockEchoServer::start();
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

        let mut outbounds = HashMap::new();
        outbounds.insert(
            "my-direct".to_string(),
            OutboundConfig {
                outbound_type: "direct".to_string(),
                addr: None,
                password: None,
                sni: None,
                bind: None,
            },
        );

        let rules = vec![
            rule("IP-CIDR", Some("127.0.0.0/8"), "my-direct"),
            rule("FINAL", None, "REJECT"),
        ];

        let server = RulesTestServer::start(fallback.addr, outbounds, rules, HashMap::new()).await;

        let mut tls_stream = server.connect_to_ipv4(echo.addr, b"outbound").await;

        let mut buf = vec![0u8; 1024];
        let n = tokio::time::timeout(Duration::from_secs(5), tls_stream.read(&mut buf))
            .await
            .expect("read timeout")
            .unwrap();

        assert_eq!(
            &buf[..n],
            b"outbound",
            "Named outbound 'direct' should relay traffic"
        );

        server.stop().await;
    }

    /// Test: Named outbound with type "reject" drops connection.
    #[tokio::test]
    async fn test_rules_named_outbound_reject() {
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

        let mut outbounds = HashMap::new();
        outbounds.insert(
            "block".to_string(),
            OutboundConfig {
                outbound_type: "reject".to_string(),
                addr: None,
                password: None,
                sni: None,
                bind: None,
            },
        );

        let rules = vec![
            rule("IP-CIDR", Some("127.0.0.0/8"), "block"),
            rule("FINAL", None, "DIRECT"),
        ];

        let server = RulesTestServer::start(fallback.addr, outbounds, rules, HashMap::new()).await;

        let echo = MockEchoServer::start();
        let mut tls_stream = server.connect_to_ipv4(echo.addr, b"should reject").await;

        assert_connection_rejected(
            &mut tls_stream,
            "Named reject outbound should close connection",
        )
        .await;

        server.stop().await;
    }

    /// A rule-set fetched over HTTP is applied the same as one read from disk.
    ///
    /// Only the file provider was covered, so the HTTP fetch — the mode a
    /// deployment actually uses to pull a shared blocklist — was never
    /// exercised. Serves the rule body from a mock and asserts the rule takes
    /// effect, which fails if the fetch, the parse, or the wiring breaks.
    #[tokio::test]
    async fn test_rules_http_provider() {
        let echo = MockEchoServer::start();
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");
        // Body is the rule-set itself, in Surge format.
        let ruleset =
            MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nDOMAIN,http-blocked.example.com\n");

        let mut rule_providers = HashMap::new();
        rule_providers.insert(
            "remote-set".to_string(),
            RuleProviderConfig {
                format: "surge".to_string(),
                behavior: Some("classical".to_string()),
                source: "http".to_string(),
                path: None,
                url: Some(format!("http://{}/blocklist.txt", ruleset.addr)),
                interval: Some(3600),
            },
        );

        let rules = vec![
            rule_set_ref("remote-set", "REJECT"),
            rule("IP-CIDR", Some("127.0.0.0/8"), "DIRECT"),
            rule("FINAL", None, "DIRECT"),
        ];

        let server =
            RulesTestServer::start(fallback.addr, HashMap::new(), rules, rule_providers).await;

        // The fetch happens in a background task at startup; give it a moment
        // to replace the empty cache-only rule-set.
        tokio::time::sleep(Duration::from_millis(500)).await;

        let mut rejected = server
            .connect_to_domain("http-blocked.example.com", 443, b"")
            .await;
        assert_connection_rejected(
            &mut rejected,
            "a domain in the HTTP-fetched rule-set should be rejected",
        )
        .await;

        // Anything else still routes normally.
        let mut allowed = server.connect_to_ipv4(echo.addr, b"allowed").await;
        let mut buf = vec![0u8; 16];
        let n = tokio::time::timeout(Duration::from_secs(5), allowed.read(&mut buf))
            .await
            .expect("read timeout")
            .unwrap();
        assert_eq!(&buf[..n], b"allowed");

        // Release both streams first: `stop()` waits out the graceful drain,
        // and a still-open connection holds it for the full timeout.
        drop(rejected);
        drop(allowed);
        server.stop().await;
    }

    /// Test: Rule-set from a file provider (Surge format).
    #[tokio::test]
    async fn test_rules_file_provider() {
        let echo = MockEchoServer::start();
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

        // Write a temporary rule-set file in Surge format
        let temp_dir = tempfile::tempdir().unwrap();
        let ruleset_path = temp_dir.path().join("block-domains.txt");
        fs::write(&ruleset_path, "DOMAIN,file-blocked.example.com\n").unwrap();

        let mut rule_providers = HashMap::new();
        rule_providers.insert(
            "block-set".to_string(),
            RuleProviderConfig {
                format: "surge".to_string(),
                behavior: Some("classical".to_string()),
                source: "file".to_string(),
                path: Some(ruleset_path.to_string_lossy().to_string()),
                url: None,
                interval: None,
            },
        );

        let rules = vec![
            rule_set_ref("block-set", "REJECT"),
            rule("IP-CIDR", Some("127.0.0.0/8"), "DIRECT"),
            rule("FINAL", None, "DIRECT"),
        ];

        let server =
            RulesTestServer::start(fallback.addr, HashMap::new(), rules, rule_providers).await;

        // Connection to blocked domain should be rejected
        let mut tls_stream = server
            .connect_to_domain("file-blocked.example.com", 443, b"")
            .await;

        assert_connection_rejected(
            &mut tls_stream,
            "File provider REJECT should close connection",
        )
        .await;

        // Connection to echo server (IP) should be relayed via DIRECT
        let mut tls_stream2 = server.connect_to_ipv4(echo.addr, b"allowed").await;

        let mut buf2 = vec![0u8; 1024];
        let n2 = tokio::time::timeout(Duration::from_secs(5), tls_stream2.read(&mut buf2))
            .await
            .expect("read timeout")
            .unwrap();

        assert_eq!(&buf2[..n2], b"allowed", "Non-blocked traffic should relay");

        server.stop().await;
    }

    /// Test: DOMAIN-SUFFIX rule matching.
    #[tokio::test]
    async fn test_rules_domain_suffix_reject() {
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

        let rules = vec![
            rule("DOMAIN-SUFFIX", Some("blocked.com"), "REJECT"),
            rule("FINAL", None, "DIRECT"),
        ];

        let server =
            RulesTestServer::start(fallback.addr, HashMap::new(), rules, HashMap::new()).await;

        // sub.blocked.com should match DOMAIN-SUFFIX
        let mut tls_stream = server.connect_to_domain("sub.blocked.com", 443, b"").await;

        assert_connection_rejected(
            &mut tls_stream,
            "DOMAIN-SUFFIX REJECT should close connection",
        )
        .await;

        server.stop().await;
    }

    /// Test: DOMAIN-KEYWORD rule matching.
    #[tokio::test]
    async fn test_rules_domain_keyword_reject() {
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

        let rules = vec![
            rule("DOMAIN-KEYWORD", Some("ads"), "REJECT"),
            rule("FINAL", None, "DIRECT"),
        ];

        let server =
            RulesTestServer::start(fallback.addr, HashMap::new(), rules, HashMap::new()).await;

        let mut tls_stream = server
            .connect_to_domain("tracker.ads.example.com", 443, b"")
            .await;

        assert_connection_rejected(
            &mut tls_stream,
            "DOMAIN-KEYWORD REJECT should close connection",
        )
        .await;

        server.stop().await;
    }

    /// Test: Multiple rules evaluated in order (first match wins).
    #[tokio::test]
    async fn test_rules_order_matters() {
        let echo = MockEchoServer::start();
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

        // IP-CIDR allows 127.0.0.0/8 DIRECT, but FINAL is REJECT.
        // The IP-CIDR rule should match first.
        let rules = vec![
            rule("DOMAIN", Some("should-not-match.example.com"), "REJECT"),
            rule("IP-CIDR", Some("127.0.0.0/8"), "DIRECT"),
            rule("FINAL", None, "REJECT"),
        ];

        let server =
            RulesTestServer::start(fallback.addr, HashMap::new(), rules, HashMap::new()).await;

        let mut tls_stream = server.connect_to_ipv4(echo.addr, b"order").await;

        let mut buf = vec![0u8; 1024];
        let n = tokio::time::timeout(Duration::from_secs(5), tls_stream.read(&mut buf))
            .await
            .expect("read timeout")
            .unwrap();

        assert_eq!(
            &buf[..n],
            b"order",
            "IP-CIDR rule should match before FINAL REJECT"
        );

        server.stop().await;
    }

    /// When a request routes through a named outbound and the outbound's
    /// `connect()` fails (here, ConnectionRefused on a closed port), the
    /// handler must shut down the inbound TLS stream so the client receives
    /// a clean `Ok(0)` close_notify rather than `UnexpectedEof`. Port 1 is
    /// reliably closed on the loopback interface, giving a deterministic
    /// connect failure without depending on DNS quirks.
    #[tokio::test]
    async fn test_rules_outbound_connect_refused_closes_cleanly() {
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

        let mut outbounds = HashMap::new();
        outbounds.insert(
            "intranet".to_string(),
            OutboundConfig {
                outbound_type: "direct".to_string(),
                addr: None,
                password: None,
                sni: None,
                bind: None,
            },
        );
        let rules = vec![rule("FINAL", None, "intranet")];

        let server = RulesTestServer::start(fallback.addr, outbounds, rules, HashMap::new()).await;

        let unreachable = SocketAddr::from(([127, 0, 0, 1], 1));
        let mut tls_stream = server.connect_to_ipv4(unreachable, b"").await;

        let mut buf = vec![0u8; 1024];
        let n = tokio::time::timeout(Duration::from_secs(5), tls_stream.read(&mut buf))
            .await
            .expect("read timeout")
            .expect("expected clean Ok(0) close_notify, not UnexpectedEof");
        assert_eq!(n, 0, "expected close_notify after outbound connect failure");

        server.stop().await;
    }

    /// Rules-path counterpart of `test_intranet_target_immediate_close_yields_eof`.
    /// When the request routes through a named outbound and the target
    /// accepts then immediately drops the connection (RST), the relay
    /// reunites its split halves and shuts down the inbound TLS cleanly.
    #[tokio::test]
    async fn test_rules_outbound_target_close_yields_clean_eof() {
        let silent = MockSilentServer::start();
        let fallback = MockHttpServer::start("HTTP/1.1 200 OK\r\n\r\nFallback");

        let mut outbounds = HashMap::new();
        outbounds.insert(
            "intranet".to_string(),
            OutboundConfig {
                outbound_type: "direct".to_string(),
                addr: None,
                password: None,
                sni: None,
                bind: None,
            },
        );
        let rules = vec![
            rule("IP-CIDR", Some("127.0.0.0/8"), "intranet"),
            rule("FINAL", None, "REJECT"),
        ];

        let server = RulesTestServer::start(fallback.addr, outbounds, rules, HashMap::new()).await;

        let mut tls_stream = server.connect_to_ipv4(silent.addr, b"hello").await;

        let mut buf = vec![0u8; 1024];
        let n = tokio::time::timeout(Duration::from_secs(5), tls_stream.read(&mut buf))
            .await
            .expect("read timeout")
            .expect("expected clean Ok(0) close_notify, not UnexpectedEof");
        assert_eq!(n, 0, "expected close_notify after relay error");

        server.stop().await;
    }
}
