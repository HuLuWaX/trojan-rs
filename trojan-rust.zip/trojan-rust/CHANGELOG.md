# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

## [0.18.0](https://github.com/trojan-rust/trojan-rust/compare/v0.17.0...v0.18.0) - 2026-10-19

### Breaking Changes

- Rust callers that construct `AgentConfig` with a struct literal must supply `node_state_grace_secs`. Existing TOML configurations use the 48-hour default.

### Bug Fixes

- Keep managed entry routing available after panel snapshots expire, with 48 hours of grace measured from snapshot generation by default. Reconnection and restart do not extend the deadline.
- Persist accepted snapshots atomically to `cache_dir/node-states.json` and load snapshots before cached services start. Managed entries can resume routing after an agent or host restart while the panel is unavailable.
- Retain the last known quota usage across billing-period rollover during grace. Unlimited nodes remain eligible; disabled, offline, depleted, and unsupported finite-quota nodes remain unavailable.

### Observability

- Export `trojan_agent_node_state_age_seconds` every second, including while disconnected. The value is `-1` before any snapshot is loaded or received.

### Upgrade Notes

- Set `node_state_grace_secs = 0` in the local Agent TOML to enforce strict snapshot expiry and billing-period boundaries.
- Preserve `cache_dir` on persistent storage. After the first upgrade, let the Agent receive and persist a panel snapshot before relying on offline restart recovery. Earlier versions do not create `node-states.json`.
- Finite quotas can be exceeded while disconnected because routing uses the last known remaining quota. Snapshot cache corruption and write failures stop the Agent explicitly.

See the [Agent configuration and offline routing behavior](https://github.com/trojan-rust/trojan-rust/blob/v0.18.0/crates/trojan-agent/README.md).

## [0.17.0](https://github.com/trojan-rust/trojan-rust/compare/v0.16.0...v0.17.0) - 2026-10-09

### Breaking Changes

- Rust library callers must await `init_metrics_server(listen, tls, extra_routes)` and drive the returned `MetricsServer` with `run_until(service_future)`. Keep recorder initialization before metric-handle creation. Metrics configuration structs now include an optional `tls` field, and startup errors propagate through `ServerError::Metrics` and `RelayError::Metrics`.

### Features

- Add optional metrics mTLS for standalone and Agent-managed server, relay, and entry nodes. Configure `metrics.tls.cert`, `key`, and `client_ca`; all listener routes require a trusted, valid client certificate. Existing HTTP configurations retain their behavior when `metrics.tls` is absent.
- Bound TLS handshakes to five seconds and metrics connections to 128 per listener. Certificate, key, client CA, recorder, and bind failures fail startup instead of silently falling back to HTTP.

### Bug Fixes

- Release entry rule listeners synchronously when the owning service is aborted, so immediate restarts cannot race a detached listener.
- Disable address reuse for the Windows proxy listener so a second service cannot bind the same address and bypass startup failure handling.
- Separate the process-wide Prometheus recorder from service-owned listeners. Service shutdown closes old listeners and metrics connections before an Agent restart can bind a replacement, including HTTP-to-mTLS transitions.
- Honor explicit Agent `restart_required=true` requests even when certificate paths are unchanged, and report service startup failures through the existing Agent error channel.

### Upgrade Notes

- Upgrade node binaries before enabling `metrics.tls`. Older binaries can ignore the new fields. Verify authenticated HTTPS succeeds and anonymous access fails before widening network exposure.
- Certificate and client CA changes require a service restart. Standalone nodes must stop and restart; server SIGHUP does not reload metrics certificates. For Agent-managed nodes, save the service JSON in Dashboard and restart the Agent, or use a supported `ConfigPush` with `restart_required=true`. Dashboard PATCH saves configuration for registration and does not automatically send `ConfigPush`.
- An Agent can start with cached HTTP configuration before registration. Confirm the active listener uses mTLS before changing firewall rules. Preserve Agent caches, traffic journals, and persistent state.
- Restarting interrupts scrapes and proxy connections. The server may drain proxy connections for up to 30 seconds; entry and relay tunnels close immediately. Use server certificates whose SAN matches the scrape address, and keep client-side server certificate verification enabled.

See [metrics configuration, Prometheus, curl, and restart examples](https://github.com/trojan-rust/trojan-rust/blob/v0.17.0/crates/trojan-metrics/README.md).

## [0.16.0](https://github.com/trojan-rust/trojan-rust/compare/v0.15.0...v0.16.0) - 2026-10-08

### Breaking Changes

- Library callers must account for `LbStrategy::TrafficAware`, `RuleConfig::routes`, and the route pool returned by `Router::resolve`. Every load-balancing strategy now excludes unhealthy backends and returns an error when none are available.

### Features

- Keep Agent protocol version 1. The WebSocket upgrade negotiates node accounting with `x-trojan-node-traffic: 1`; legacy agents and dashboards retain baseline service behavior. Previously enabled accounting cannot silently downgrade to a legacy dashboard.
- Persist node traffic independently of user accounting. Agents retain unacknowledged samples across reconnects and restarts; the dashboard deduplicates reports and assigns delayed samples to their original observation period.
- Configure monthly node quotas with a reset day and IANA timezone. Node APIs expose directional usage, remaining bytes, reset times, and availability. Resetting a quota preserves traffic history.
- Select complete relay paths and exits with `routes` and `strategy = "traffic_aware"`. Managed entries exclude disabled, offline, exhausted, and stale nodes, and finite-quota nodes without accounting support; live updates restore eligible routes without restarting services. Existing connections continue.
- Expose directional node throughput with heartbeat freshness and unknown-rate states. Add bounded node traffic history queries from the durable node ledger, separate from user traffic charts.
- Expose entry route selection, tunnel setup outcomes and duration, and actual failover attempts through Prometheus. Add agent accounting backlog and checkpoint diagnostics without changing protocol version 1.

### Bug Fixes

- Close and join service connections before checkpointing final node traffic. Count accepted writes even when a later write, flush, or cancellation interrupts forwarding.
- Release active-connection metrics when a session is cancelled or panics. Stop reporting semaphore capacity as TCP accept queue depth.

### Performance

- Buffer node traffic journal writes while preserving the existing file format, atomic replacement, and disk synchronization.
- Reuse billing calendars and batch expired quota-window rebuilds for node lists and scheduling snapshots.

## [0.15.0](https://github.com/trojan-rust/trojan-rust/compare/v0.14.0...v0.15.0) - 2026-10-08

### Breaking Changes

- Upgrade all relay nodes before upgrading entry nodes. New entry nodes require connection responses from every relay. New relay nodes still accept legacy entry handshakes.
- Library users must account for the new `HandshakeMetadata.ack` field and `RelayError::RemoteConnectFailed` variant.

### Bug Fixes

- Confirm each hop's target connection before forwarding client data. With `strategy = "failover"`, a failed exit connection switches to another destination within the same client connection.
- Keep intermediate relay failures, authentication failures, and missing responses from marking exit destinations unhealthy.
- Attempt each destination address at most once per client connection, even with zero cooldown. Never retry after payload forwarding starts.

## [0.14.0](https://github.com/trojan-rust/trojan-rust/compare/v0.13.0...v0.14.0) - 2026-10-07

### Bug Fixes

- percent-encode a password written into a subscription URL

- preserve node quotas after user updates

- preserve bound listeners during startup

- preserve service lifecycle and honor HTTP auth

- enforce authentication deadlines and UDP routing


### Chores

- ignore benchmark results


### Performance

- bound traffic reporting and coalesce cold lookups

- remove relay split locks and release handshake buffers

- bound destination metrics and unblock TCP and UDP scheduling


### Tests

- add real TCP and TLS performance baseline

## [0.13.0](https://github.com/trojan-rust/trojan-rust/compare/v0.12.0...v0.13.0) - 2026-08-12

### Bug Fixes

- validate on every start path, and put config enums in the type system


### Chores

- ignore Claude Code's transient state


### Documentation

- read the admin token from an environment file

## [0.12.0](https://github.com/trojan-rust/trojan-rust/compare/v0.11.0...v0.12.0) - 2026-08-12

### Bug Fixes

- keep the drive letter in sqlite connection URLs

- repair the Windows and interop jobs on master ([#54](https://github.com/trojan-rust/trojan-rust/pull/54))


### CI

- stop one platform's failure from hiding the others


### Documentation

- record how traffic is accounted for across the chain

- the settings and unit file a deployment needs

- record the lint runs CI actually makes


### Features

- account for the bytes entry and relay nodes carry

- speak PROXY protocol v2, with a TLV for the relay chain

- believe a trusted proxy about the client, and credit the chain

- report what the service actually carried

- serve the agent socket, so a node's reports have somewhere to go


### Refactoring

- rebuild the data layer on SeaORM, after the panel it replaces

- let each crate own the config it reads

## [0.11.0](https://github.com/trojan-rust/trojan-rust/compare/v0.10.1...v0.11.0) - 2026-08-12

### Bug Fixes

- send close_notify when rejecting a WebSocket upgrade

- send close_notify when the initial payload write fails

- saturate socket sizing instead of narrowing with as

- account for traffic when a connection ends in error

- deliver clean TLS close_notify on intranet failure paths

- make the ClickHouse writer actually work


### CI

- also run the C++ trojan client tests


### Chores

- add Nix dev shell pinned to the CI toolchain

- give every lint suppression a documented reason

- write the shell banner to stderr


### Features

- aggregate daily traffic for the dashboard chart

- populate the connection event, and stop skipping silently

- replace the Cloudflare Worker with a native service


### Performance

- reserve the header buffer so the trojan header arrives in one read

- enable TLS session resumption

- resolve relay counter handles once per session


### Refactoring

- give the HTTP auth protocol its own module

- convert counters once at the storage boundary


### Tests

- cover multi-worker reuse_port, half-close, and UDP framing

- cover the WebSocket transport end to end

- cover the server config surface end to end

- cover the metrics endpoint and the per_target knob

- cover resource limits and the ip-hash policy

- cover the HTTP auth backend against a mock worker

- cover the HTTP rule provider

- cover custom DNS nameserver resolution

- smoke-test the TCP socket options

- cover the Cloudflare DDNS updater

- cover stream integrity and TLS resumption end to end

- actually run the trojan-go client tests

- cover analytics delivery, and build non-default features in CI

- drive the SQL auth backend through a running server

- cover GeoIP routing with a generated database

## [0.10.1](https://github.com/trojan-rust/trojan-rust/compare/v0.10.0...v0.10.1) - 2026-04-28

### Build

- bump rust-dependencies group (hickory 0.26, sha2 0.11, ctor 0.10, clickhouse 0.15, tokio-tungstenite 0.29)


### Chores

- update Cargo.toml dependencies

## [0.10.0](https://github.com/trojan-rust/trojan-rust/compare/v0.9.1...v0.10.0) - 2026-04-28

### Bug Fixes

- satisfy clippy 1.95 lints in ws inspect/accept

- make traffic batching durable, accurate, and SWR-safe


### Features

- expose batch flush interval in HTTP auth config

## [0.9.1](https://github.com/trojan-rust/trojan-rust/compare/v0.9.0...v0.9.1) - 2026-02-28

### Chores

- update Cargo.lock dependencies


### Performance

- use batched traffic recording for HTTP backend

## [0.9.0](https://github.com/trojan-rust/trojan-rust/compare/v0.8.1...v0.9.0) - 2026-02-24

### Bug Fixes

- default WebSocket to disabled


### Features

- add dynamic DNS support with Cloudflare provider


### Performance

- use atomics for traffic deltas and add cache cleanup task

## [0.8.1](https://github.com/trojan-rust/trojan-rust/compare/v0.8.0...v0.8.1) - 2026-02-18

### Bug Fixes

- wire auth.record_traffic() so traffic data reaches auth-worker


### Performance

- defer flush until reader is idle and share TLS config

## [0.8.0](https://github.com/trojan-rust/trojan-rust/compare/v0.7.0...v0.8.0) - 2026-02-18

### Bug Fixes

- harden SWR and preserve DNS compatibility

- widen timing margins in stale cache tests to prevent flakiness


### Features

- add stale-while-revalidate cache for HTTP auth

- add trojan-dns crate with hickory-resolver for unified DNS resolution

## [0.7.0](https://github.com/trojan-rust/trojan-rust/compare/v0.6.1...v0.7.0) - 2026-02-17

### Features

- wire up HttpAuth backend via config

## [0.6.1](https://github.com/trojan-rust/trojan-rust/compare/v0.5.6...v0.6.1) - 2026-02-17

### Bug Fixes

- resolve broken intra-doc link in AuthCache::remove_negative


### Chores

- update Cargo.lock dependencies

- add auth-worker to monorepo, gitignore wrangler.toml

- slim down README, apply cargo fmt

- release v0.6.0 ([#14](https://github.com/trojan-rust/trojan-rust/pull/14))


### Features

- add node management, per-node traffic tracking, and admin panel


### Refactoring

- extract UserStore trait + StoreAuth<S> with cache-integrated traffic tracking


### deps

- upgrade sysinfo 0.33→0.38, rand 0.9→0.10, zip/clap/webpki-roots

## [0.6.0](https://github.com/trojan-rust/trojan-rust/compare/v0.5.6...v0.6.0) - 2026-02-17

### Chores

- update Cargo.lock dependencies

- add auth-worker to monorepo, gitignore wrangler.toml

- slim down README, apply cargo fmt


### Features

- add node management, per-node traffic tracking, and admin panel


### Refactoring

- extract UserStore trait + StoreAuth<S> with cache-integrated traffic tracking


### deps

- upgrade sysinfo 0.33→0.38, rand 0.9→0.10, zip/clap/webpki-roots

## [0.5.6](https://github.com/trojan-rust/trojan-rust/compare/v0.5.4...v0.5.6) - 2026-02-17

### Bug Fixes

- match Linux runner for cross-compilation tools install


### Chores

- update Cargo.lock dependencies

- release v0.5.5 ([#11](https://github.com/trojan-rust/trojan-rust/pull/11))


### Features

- enable all SQL drivers and TLS by default


### Refactoring

- remove trojan-server from release, only ship unified CLI

## [0.5.5](https://github.com/trojan-rust/trojan-rust/compare/v0.5.3...v0.5.5) - 2026-02-17

### Chores

- update Cargo.lock dependencies

- release v0.5.3 ([#10](https://github.com/trojan-rust/trojan-rust/pull/10))

## [0.5.4](https://github.com/trojan-rust/trojan-rust/compare/v0.5.2...v0.5.4) - 2026-02-17

### Bug Fixes

- use ubuntu-22.04 for Linux release builds


### Chores

- update Cargo.lock dependencies

- use plain version tag as GitHub release name

- release v0.5.3 ([#8](https://github.com/trojan-rust/trojan-rust/pull/8))

## [0.5.3](https://github.com/trojan-rust/trojan-rust/compare/v0.5.1...v0.5.3) - 2026-02-17

### Bug Fixes

- install rustls CryptoProvider at startup


### Chores

- update Cargo.lock dependencies

- release v0.5.2 ([#7](https://github.com/trojan-rust/trojan-rust/pull/7))

## [0.5.2](https://github.com/trojan-rust/trojan-rust/compare/v0.5.1...v0.5.2) - 2026-02-17

### Bug Fixes

- install rustls CryptoProvider at startup

## [0.1.8](https://github.com/trojan-rust/trojan-rust/compare/v0.1.4...v0.1.8) - 2026-01-28

### Bug Fixes

- suppress unused variable warning on Windows


### CI

- add git-cliff for automated release notes


### Chores

- update Cargo.lock dependencies

- release v0.1.5

- release v0.1.6

- adopt release-plz

- release v0.1.7 ([#4](https://github.com/trojan-rust/trojan-rust/pull/4))


### Documentation

- add changelog scaffold


### Features

- add self-signed certificate generation

- add TCP socket configuration options

## [0.1.7](https://github.com/trojan-rust/trojan-rust/compare/v0.1.4...v0.1.7) - 2026-01-28

### Bug Fixes

- suppress unused variable warning on Windows


### CI

- add git-cliff for automated release notes


### Chores

- update Cargo.lock dependencies

- release v0.1.5

- release v0.1.6

- adopt release-plz


### Documentation

- add changelog scaffold


### Features

- add self-signed certificate generation

- add TCP socket configuration options


## 0.1.6 - 2026-01-28

### <!-- 5 -->🎨 Styling

- apply cargo fmt to trojan-cert

## 0.1.5 - 2026-01-28

### <!-- 0 -->🚀 Features

- add self-signed certificate generation

- add TCP socket configuration options


### <!-- 3 -->📚 Documentation

- add changelog scaffold


### <!-- 7 -->⚙️ Miscellaneous Tasks

- add git-cliff for automated release notes

- release v0.1.5

## 0.1.4 - 2026-01-28

### <!-- 1 -->🐛 Bug Fixes

- add zip dependency for Windows builds


### <!-- 2 -->🚜 Refactor

- use workspace dependencies for internal crates


### <!-- 3 -->📚 Documentation

- add README and strict issue templates

- add badges to README


### <!-- 7 -->⚙️ Miscellaneous Tasks

- enhance .gitignore for better privacy protection

- bump version to 0.1.3 and add trojan-rs placeholder crate

- bump version to 0.1.4 and fix workspace dependencies

## 0.1.3 - 2026-01-28

### <!-- 1 -->🐛 Bug Fixes

- use cross for i686-unknown-linux-musl target

## 0.1.2 - 2026-01-28

### <!-- 1 -->🐛 Bug Fixes

- use rustls instead of native-tls for musl compatibility

## 0.1.1 - 2026-01-28

### <!-- 0 -->🚀 Features

- add SQL auth backend and unified CLI

- add authentication caching with TTL support

- add WebSocket transport with mixed/split modes

- add connection tracing, health endpoints, and latency metrics

- add criterion benchmarks for proto, auth, and core

- add criterion benchmarks

- rename crate trojan-rs to trojan and expand release targets

- add upgrade subcommand for self-update from GitHub releases

- add trojan-analytics crate for connection tracking


### <!-- 1 -->🐛 Bug Fixes

- resolve clippy warnings

- use aws-lc-rs backend for rcgen to match rustls

- increase server startup wait time for Windows CI

- use ECDSA P-256 for cross-platform certificate generation

- fix flaky TLS test on Windows by using unique temp dirs


### <!-- 10 -->💼 Other

- bump rust-dependencies group with 6 updates

- bump the github-actions group with 3 updates (#1)

- bump clap from 4.5.54 to 4.5.55 in the rust-dependencies group across 1 directory (#3)


### <!-- 2 -->🚜 Refactor

- split monolithic lib.rs into modular structure

- extract shared I/O and transport modules


### <!-- 4 -->⚡ Performance

- reduce allocations in hot paths


### <!-- 5 -->🎨 Styling

- apply cargo fmt formatting


### <!-- 7 -->⚙️ Miscellaneous Tasks

- add GitHub Actions workflows for CI and release

- add license file

## 0.1.0 - 2026-01-27

### <!-- 0 -->🚀 Features

- initial trojan-rs server implementation
