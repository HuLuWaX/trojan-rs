# Trojan Rust

[![Crates.io](https://img.shields.io/crates/v/trojan.svg)](https://crates.io/crates/trojan)
[![CI](https://github.com/trojan-rust/trojan-rust/actions/workflows/ci.yml/badge.svg)](https://github.com/trojan-rust/trojan-rust/actions/workflows/ci.yml)
[![License](https://img.shields.io/crates/l/trojan.svg)](https://github.com/trojan-rust/trojan-rust/blob/master/LICENSE)

A high-performance Rust implementation of the [Trojan](https://trojan-gfw.github.io/trojan/protocol) protocol.

## Documentation

See the full documentation at [trojan.rs](https://trojan.rs).

For multi-hop routing, destination failover, and relay upgrade ordering, see [trojan-relay](crates/trojan-relay/README.md).

For persistent node traffic accounting and monthly quotas, see [trojan-dash](crates/trojan-dash/README.md#node-quotas). Managed entries use live quota and health information to select relay paths and exits.

For node throughput and traffic history, see [node observability](crates/trojan-dash/README.md#node-observability). For Prometheus counters and route diagnostics, see [trojan-metrics](crates/trojan-metrics/README.md).

Agent-managed entries [cache node states](crates/trojan-agent/README.md) for offline routing across restarts, with 48 hours of grace by default. Set `node_state_grace_secs = 0` for strict snapshot expiry.

Server, relay, and entry nodes support optional [mutual TLS for metrics](crates/trojan-metrics/README.md#mutual-tls), including Agent-managed nodes. Existing HTTP configurations remain compatible. Upgrade the node binary before enabling `metrics.tls`.

## Shadowsocks Manager compatibility

The server can expose the management protocol used by [`ssmgr-trojan-client`](https://github.com/llc1123/ssmgr-trojan-client) and use the same Redis key format. Set these environment variables before starting `trojan server`:

```sh
export TROJAN_SSMGR_REDIS_URL='redis://:password@127.0.0.1:6379/0'
export TROJAN_SSMGR_KEY='use-the-same-key-configured-in-ssmgr'
export TROJAN_SSMGR_LISTEN='127.0.0.1:4001'
trojan server -c config.toml
```

Redis uses the keys `user:<id>` for password hashes and `<hash>` for `upload`/`download` counters; no schema setup is needed. Configure the ssmgr Trojan node to connect to the listen address and use the same key. The management endpoint implements `list`, `add`, `del`, `flow`, and `version`; traffic increments the upload counter and is drained when ssmgr requests `flow`. Bind the endpoint to a trusted network, since the protocol uses a shared key rather than TLS. This compatibility mode selects ssmgr authentication in place of `auth.passwords`, `auth.users`, or the HTTP backend.

## License

GPL-3.0-only
